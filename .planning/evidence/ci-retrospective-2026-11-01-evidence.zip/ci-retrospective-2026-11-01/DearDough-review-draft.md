# DearDough Process Findings

Source maintenance on 2026-10-28 retained collected evidence before shortening at Open Dough `32b5ae0b4414d755bcde4ef6cd822774d7450771:docs/maintainer/findings/`. The complete post-local source is `432ed9ec9c9e9954dd5bff0c9a7324d1d8a991a6:DearDough.md`; linked source records share that revision. Unknown execution releases and local facets remain qualified.

Reviewed 2026-10-28 (Asia/Singapore). Four shared process sources were
reviewed after local maintenance: Open Dough, Doughnut, Pygardon and Lizard.
Terry Talks skips shared collection because process retrospective is off.
Released responses await their specific ordinary-use observations; the
[watch list](docs/maintainer/near-term-watch-list.md) preserves its contrary
evidence. Source and catalog identities do not imply resolution.

- Highest allocated local number: 378. Removed numbers are never reused.
- Earlier cleanup recovery: `c76322764499936acd42328b5ef4f66f4df6bcf8:DearDough.md`.
- Project-owned DD-275/DD-309 and repaired DD-283/DD-290/DD-312 remain in [ProjectFindings.md](ProjectFindings.md). DD-288 retains the general planning lesson below. Occurrence history is partial.

## ODF-087 — Skipped preparation gates <a id="odf-087"></a>

Former local code: DD-089. Native execution can implement the requested outcome without the required checkout preparation and command check, while substitute actors and wording checks pass. [Evidence and current response](docs/maintainer/findings/ODF-087.md).

## ODF-059 — Interrupted agent handoffs <a id="odf-059"></a>

Former local code: DD-057. A host-terminated refactor agent leaves changes without a report, requiring recovery from the actual diff and unresolved proof. [Evidence and current response](docs/maintainer/findings/ODF-059.md).

Existing shared finding: [meaning and retained evidence](docs/maintainer/findings/ODF-059.md). This execution adds an occurrence under that established code; no new code or mapping is allocated.

### Occurrences

- Execution: SEED-189#expand-dashboard-diff-context / plan 416 / first related implementation `5c73925b9dcdffd763c20f5b81c5d1aa45413757`
  - Timestamp: unknown (2026-10-30; after slice-1 acceptance near `5c73925b` 14:40:51+08:00 and before resumed refactor Task that reported at ~14:39–14:50 +08)
  - Tool: Cursor
  - Open Dough release: 0.3.78
  - Evidence: coordinator transcript `1cd76bae-22c3-404c-b849-2df63d24fb85` L28 — “Resuming from the interrupted post-change refactor after slice 1 acceptance.” First refactor Task `a87536cb-6351-4c1d-9147-e23fe34639b9` (started 14:33 +08) ends after reading the skill and opening `git status`/`git diff` with no return; resumed Task `152e2811-3bad-4346-84e9-dc6a00f7ac76` completed `AdmittedFileDiff` → `AdmittedReviewedFile` rename/cohesion with no product behavior change.
  - Observed effect: one aborted post-change refactor with essentially no edits; one replacement refactor Task before slice-1 delivery; no work lost.
  - Inference: qualified recurrence of host-interrupted refactor without return (ODF-059). Empty-tree case made reconstruction cheap; host termination cause unestablished here. Distinct from ODF-229 (implementation Task) on the same execution.

## ODF-154 — Missing Cursor coordinator identity <a id="odf-154"></a>

Former local code: DD-095 (plan 126 Cursor occurrence only). Former local code: DD-231. Cursor’s first managed delivery lacks conversation/generation identity, requiring a manual observer start and registration. [Evidence and current response](docs/maintainer/findings/ODF-154.md).

## ODF-074 — Unverified planning premises <a id="odf-074"></a>

Former local code: DD-121. Former local code: DD-206. Former local code: DD-238. Former local code: DD-271. Former local code: DD-285. Former local code: DD-307. Concrete only-caller and host-state premises enter a plan without inspection, forcing a changed decision or stopped implementation when checked. [Evidence and current response](docs/maintainer/findings/ODF-074.md).

Existing shared finding: [meaning and retained evidence](docs/maintainer/findings/ODF-074.md). This execution adds an occurrence under that established code; no new code or mapping is allocated.

### Occurrences

Distinct executions, original timestamps/releases/tools, observed effects and qualified inferences are [retained at ODF-074](docs/maintainer/findings/ODF-074.md); rereading adds no occurrence.

- Execution: SEED-010#expose-codex-observer-identity / plan 372, first implementation `eac4f2083efe6c2909d6022a6ca0f5e699c8996b`
  - Timestamp: unknown (2026-10-29, Asia/Singapore; source-review acceptance before slice delivery)
  - Tool: Codex
  - Open Dough release: 0.3.75 (installed guidance at accepted Take `68014eebcf717ecac6330fb813a613b42a4fb947`; the native binding probe separately used modified source)
  - Evidence: coordinator inspected plan 371's `## Slice 1` / `Status: pending` layout, drafted plan 372 likewise and recorded ready/admitted it. Once source-review commitments required the full slice reader, three `story-obligations.mjs check --slice 1` refusals named missing `## Ordered slices`, unsupported `### Slice 1` instead of `### 1. name`, and unsupported `Status: pending` instead of `planned|done`; accepted plan at `eac4f208` contains the corrected layout.
  - Observed effect: three local repair rounds after implementation; the strict delivery check failed closed and no incorrect slice completion was published.
  - Inference: qualified recurrence of an unverified consuming-operation premise: another active plan's layout was treated as a usable template without exercising the reader that later consumes it. Checking that reader before readiness could catch the mismatch earlier; no escaping product defect or measured duration saving is claimed.

- Execution: SEED-202#consistent-shared-refresh / plan 428 / first related implementation `bd970ab3f9ce756d9a98681b7b846c70e8dd001a`
  - Timestamp: unknown (2026-10-31; slice 3 implementation before delivery `81abccbdb4b779a875820e26c78c73ef5e878c55` 20:49:24+08:00)
  - Tool: Cursor
  - Model: auto
  - Open Dough release: 0.3.79
  - Evidence: plan 428 Decisive premises and Finding 3 (`e01504b0` code read) inferred Cursor joiners could be labeled not running; slice 3 agent `8fdf20cc-39ae-4e66-9f88-a617aad90e21` and coordinator `0f28130b-4f06-4d23-a62a-b0a5632293f8` L43 — label miss did not reproduce under runner-then-records; own-read promise did; Learnings and `cursor-held-sessions-revision.spec.ts` record revision-key own-read proof.
  - Observed effect: no product rework of the planned revision-key fix; investigation cost while separating the unreproduced label symptom from the story's own-read obligation; plan learning updated; slice delivered on the verified promise.
  - Inference: qualified recurrence of an unverified host-state premise entering the plan from a prior code read without exercising the current join path; checking that path at planning time would have dropped the label claim earlier. No claim that the revision-key fix was unnecessary.

## ODF-110 — Incomplete readiness replays <a id="odf-110"></a>

Former local code: DD-124. Former local code: DD-213. Former local code: DD-228. Former local code: DD-274. Former local code: DD-282. Former local code: DD-284. A replay resolves the named readiness seam without exercising the rest of the slice's promised journey, leaving a later operation to force a scope stop. [Evidence and current response](docs/maintainer/findings/ODF-110.md).

## ODF-157 — Identifier-only conceptual searches <a id="odf-157"></a>

Former local code: DD-127. An identifier/permission-word sweep misses the same concept expressed in prose, allowing a removal's contradictory guidance to survive. [Evidence and current response](docs/maintainer/findings/ODF-157.md).

## ODF-158 — Disproportionate required reference reads <a id="odf-158"></a>

Former local code: DD-128. Startup boundary instructions require broad references for a small execution whose managed commands already own most of those paths. [Evidence and current response](docs/maintainer/findings/ODF-158.md).

## ODF-106 — Colliding plan numbers <a id="odf-106"></a>

Former local code: DD-155. Concurrent unpublished plan allocation produces two quick plans with the same numeric selector, making a number-only execution request ambiguous. [Evidence and current response](docs/maintainer/findings/ODF-106.md).

## ODF-141 — Fixed refactor cost on small accepted slices <a id="odf-141"></a>

Former local code: DD-192. Every small slice launches a fresh full refactor agent even when the accepted diff needs no further changes, creating substantial repeated cost. [Evidence and current response](docs/maintainer/findings/ODF-141.md).

### Occurrences

- Execution: SEED-162#keep-long-running-dashboard-sessions-responsive; before-cleanup `b0c9d8fc4290d39ce4ee23aff91fed648f915dd7:.planning/slice-plans/366-keep-long-running-dashboard-sessions-responsive/PLAN.md`; first related implementation commit `9bff183a`
  - Timestamp: 2026-10-28T21:34:58+08:00
  - Tool: Cursor
  - Open Dough release: 0.3.73
  - Evidence: coordinator transcript `526c01b7-1fb2-4f61-9a8a-64275b27fbb6` — six per-slice `dough-post-change-refactor` Task launches; slices 2, 3, and 5 returned “none — already clean”; slices 1, 4, and 6 made useful edits
  - Observed effect: three of six mandatory refactor agents edited nothing after reading the accepted slice diffs
  - Inference: same fixed per-slice refactor cost as ODF-141; mixed payoff on a six-behavior bounded-memory plan

- Execution: SEED-173#dashboard-ci-balance; first implementation `874ef52c0e99857feefde9b4058673c83029d875`, restored result `783d6bda38ab381e686bfb63500b97970dc8817f`
  - Timestamp: unknown (2026-10-29 execution conversation)
  - Tool: Codex
  - Open Dough release: unknown
  - Evidence: fresh `/root/refactor_ci_weights` and `/root/refactor_rejected_allocation` returns both report `none — already clean`, no edits/tests, approximately ten and seven active minutes respectively; the latter independently checked all four restored weight files against the baseline. Recoverable plan: `783d6bda38ab381e686bfb63500b97970dc8817f:.planning/slice-plans/375-dashboard-ci-balance/PLAN.md`.
  - Observed effect: two independent refactor handoffs made no changes on one data-only experiment and its explicit rejection; accepted proof remained applicable.
  - Inference: qualified recurrence of fixed review cost on small accepted changes. Durations are agent estimates, not stopwatch/token totals, and confirming restoration and proof boundaries may add confidence; no claim that either review was valueless or that skipping it would produce a measured saving.

- Execution: SEED-200#session-terminal-voice-input; first implementation `e352b41c20dc7dfb9655353a2a15cc5b967939f1`
  - Timestamp: unknown (2026-10-31 execution conversation)
  - Tool: Codex
  - Open Dough release: unknown
  - Evidence: `/root/ci_refactor` and `/root/geometry_refactor` returned “none — already clean,” no edits/tests, estimating seven and ten active minutes; `/root/refactor_2` shortened one documentation line and estimated six minutes. Related acceptance records are recoverable at `6c2d87444ac11423c250b5a301452edd0c561b77:.planning/slice-plans/426-session-terminal-voice-input/`.
  - Observed effect: two mandatory independent CI-repair refactor handoffs made no edits; the final slice pass changed only prose. The first slice's independent pass made useful attachment/status/helper refactors and renewed their affected proof.
  - Inference: qualified recurrence of fixed review overhead on small accepted repairs; durations are agent estimates, not measured wall/token totals. Proof correspondence adds confidence; no measured claim that omitting review would save the full estimates.

- Execution: SEED-204#attach-image-at-launch / plan 427 / first related implementation `59c47d4c2183cbb908d645f649a37bbde063abb0`
  - Timestamp: 2026-10-31T18:19:59+08:00 (slice 1 plan-only refactor before delivery `e26f8fb3`)
  - Tool: Cursor
  - Open Dough release: 0.3.79
  - Evidence: coordinator transcript `9b247773-9b4c-456b-9be3-4f21c7043f14`; mandatory per-slice `dough-post-change-refactor` Tasks after slices 1–7 and the dialog CI repair. Slice 1 Task `38f1be28-c09d-44b3-8e9b-376e9f53bfc2` reported `none — already clean` on the waived-probe plan-only diff; later slice/repair passes edited product or tests (for example slice 5 retired unused `launchAttachmentAccept`, CI-repair refactor dropped dead CSS positioning).
  - Observed effect: one of the mandatory refactor agents edited nothing after reading an accepted plan-only change; other passes on this seven-slice story made useful cohesion edits.
  - Inference: qualified recurrence of fixed per-slice refactor cost (ODF-141) with mixed payoff; durations unmeasured; no claim that omitting the clean pass would have saved a known token or wall-time total.

- Execution: SEED-202#consistent-shared-refresh / plan 428 / first related implementation `bd970ab3f9ce756d9a98681b7b846c70e8dd001a`
  - Timestamp: unknown (2026-10-31; three post-slice refactor Tasks before deliveries `bd970ab3`, `1bdb3420`, `81abccbd`)
  - Tool: Cursor
  - Model: auto
  - Open Dough release: 0.3.79
  - Evidence: coordinator transcript `0f28130b-4f06-4d23-a62a-b0a5632293f8`; mandatory `dough-post-change-refactor` Tasks `c1e687fe-b4ed-469e-8ccc-74d432795d8e` (slice 1) and `076fa213-15fe-4165-8237-85ada14f1818` (slice 3) returned `none — already clean`; slice 2 Task `ed47a427-669b-42ce-babe-01f8e1b61b34` extracted `machineDocumentsRevision.ts` for the 250-line file-size gate.
  - Observed effect: two of three mandatory refactor agents edited nothing after reading accepted slice diffs; one paid off on file size in the same store subsystem.
  - Inference: qualified recurrence of fixed per-slice refactor cost (ODF-141) with mixed payoff on a three-slice correction; durations/tokens unmeasured; no claim that omitting either clean pass would have saved a known total.

## ODF-204 — Interrupted delegated agent keeps running and publishes <a id="odf-204"></a>

Former local code: DD-215. After its call is interrupted, a delegated agent continues, commits and pushes its slice despite a no-commit delegation, leaving two writers in one checkout. [Evidence and current response](docs/maintainer/findings/ODF-204.md).

## ODF-205 — Execution starts on a red trunk unannounced <a id="odf-205"></a>

Former local code: DD-217. Startup does not report that the target trunk is already failing CI, so each branch publication re-raises a failure the execution does not own. [Evidence and current response](docs/maintainer/findings/ODF-205.md).

## ODF-152 — File-size gate conflicts with approved intermediate scope <a id="odf-152"></a>

Former local code: DD-219. An absolute changed-file size check conflicts with an approved staged decomposition and mechanical edits to pre-existing oversized callers. [Evidence and current response](docs/maintainer/findings/ODF-152.md).

## ODF-209 — Concurrent CI reproduction overloads slice proof <a id="odf-209"></a>

Former local code: DD-221. Asynchronous CI repair runs many-worker repetitions alongside a slice’s full suite on the same machine, producing load-only failures and slower proof. [Evidence and current response](docs/maintainer/findings/ODF-209.md).

## ODF-210 — Removal proof omits an existing user capability <a id="odf-210"></a>

Former local code: DD-234. A removal traces what a path displays but misses what it lets the user do, delivering a capability loss caught only by retrospective. [Evidence and current response](docs/maintainer/findings/ODF-210.md).

## ODF-211 — Admission is ambiguous for an unlanded story correction <a id="odf-211"></a>

Former local code: DD-237. An accepted retrospective correction is directed toward admission on remote trunk although it needs its active story branch’s unlanded code. [Evidence and current response](docs/maintainer/findings/ODF-211.md).

## ODF-217 — Unverified refactor proof effects <a id="odf-217"></a>

Former local code: DD-239. Former local code: DD-248. A refactor misclassifies or omits the proof effects of a change, leaving reached consumers unrun; some returns incorrectly call changed behavior identical or type-only. [Evidence and current response](docs/maintainer/findings/ODF-217.md).

## ODF-218 — Formatting invalidates a pre-format size check <a id="odf-218"></a>

Former local code: DD-241. The mandatory formatter expands a file after its independent size check, requiring a second refactor and formatter pass solely for layout. [Evidence and current response](docs/maintainer/findings/ODF-218.md).

## ODF-219 — Background coordinator implements outside the local-slice condition <a id="odf-219"></a>

Former local code: DD-245. Background coordinators implement tiny Structure or probe slices themselves despite delegation limiting local implementation to a single interactive slice. [Evidence and current response](docs/maintainer/findings/ODF-219.md).

## ODF-100 — Masked formatter failure <a id="odf-100"></a>

Former local code: DD-251 (plans 264 and 271 only). A formatter piped through tail returns the final pipeline stage's success, allowing subsequent delivery steps after formatter failure. [Evidence and current response](docs/maintainer/findings/ODF-100.md).

## ODF-097 — Publishing after a failed check <a id="odf-097"></a>

Former local code: DD-251 (plan 273 only). A failed formatter or verification result is visible but does not gate the next commit or publication step. [Evidence and current response](docs/maintainer/findings/ODF-097.md).

## ODF-222 — Post-commit managed delivery stalls at an unknown stage <a id="odf-222"></a>

Former local code: DD-253 (Cursor plan 273 only). Managed delivery remains alive after a successful commit while its remote story-branch tip remains behind; the blocking subprocess is not located. [Evidence and current response](docs/maintainer/findings/ODF-222.md).

## ODF-184 — Unbounded Git transport stalls managed delivery <a id="odf-184"></a>

Former local code: DD-253 (Claude Code plan 274 only). An SSH fetch or push has no time bound, leaving managed delivery waiting without a terminal failure while the remote tip remains unpublished. [Evidence and current response](docs/maintainer/findings/ODF-184.md).

## ODF-220 — Code-level planning findings become stale on trunk <a id="odf-220"></a>

Former local code: DD-254. Code observations were true during preparation but sibling delivery changes them before execution; document-basis change notices do not identify the stale code premises. [Evidence and current response](docs/maintainer/findings/ODF-220.md).

## ODF-221 — CI repair misses a sibling with the diagnosed cause <a id="odf-221"></a>

Former local code: DD-255. A CI repair fixes only the reported spec although a sibling written by the same slice has the diagnosed race, causing separate later CI failures and a second repair. [Evidence and current response](docs/maintainer/findings/ODF-221.md).

## ODF-224 — Native replay changes the retained acceptance checkpoint <a id="odf-224"></a>

Former local code: DD-258. A native acceptance replay constructs a fresh current-slice checkpoint instead of the historical accepted checkpoint and omits later ownership or preserved constraints, so the paid run exercises a different decision. [Evidence and current response](docs/maintainer/findings/ODF-224.md).

## ODF-150 — Implementation proof misses indirect consumers <a id="odf-150"></a>

Former local code: DD-259. Focused consumer selection misses indirect callers, contract comparisons or prose consumers, so named proof can pass while owned CI or a wider suite finds the omitted effect. [Retained occurrences and response](docs/maintainer/findings/ODF-150.md). All distinct execution evidence is retained in Open Dough `ccf309a69459284de3f1d45f2de813e9180c2971:docs/maintainer/findings/ODF-150.md`; the pre-compaction source is `f274a3d0c729504bf8ce00614bf3cd236b7e088b:DearDough.md`.

Existing shared finding: [meaning and retained evidence](docs/maintainer/findings/ODF-150.md). This execution adds an occurrence under that established code; no new code or mapping is allocated.

### Occurrences

- Execution: SEED-163#reliably-report-dashboard-wrap-up / plan 367 / first related implementation `938f2f1e9224eb6503654fec1b8a3b033ccdd64e`
  - Timestamp: 2026-10-28T14:19:12Z (CI failure on slice 3 SHA `242e5fe7`)
  - Tool: Cursor
  - Model: auto
  - Open Dough release: 0.3.73
  - Evidence: plan slice 3 accepted proof named `story-branch-landing-capture.spec.ts` / later-publication twin plus unit coverage; CI run 40704491019 job `dashboard (3/12)` failed `story-branch-retained-landing.spec.ts:43` (ZodError requiring `landing` on second integrate). Repair `804e7d7f` asserts `already-accepted` without a landing field after expectation clear. Coordinator transcript `3fc700d8-1e3b-486e-82de-cd7b0c5e26e7` stashed slice 4 for that repair.
  - Observed effect: one owned CI failure and one assertion repair before slice 4 delivery; the sibling retained-landing journey was not in the slice's focused proof.
  - Inference: recurrence of focused-neighbor selection missing an existing consumer of the same second-integrate / no-landing contract after open-expectation clear.
- Execution: SEED-199#mobile-session-screen / plan 425 / first related implementation `eaa0237881d704ee46711d8bc4fb188401b6ec94`
  - Timestamp: 2026-10-31T13:07:38+08:00 (repair commit `a8ff15c2`; CI run 41165181622 attempt 1 on slice-1 SHA `eaa02378`)
  - Tool: Cursor
  - Open Dough release: 0.3.78
  - Evidence: plan Decisive premises listed header-UUID consumers (`agent-terminal*`, touch/session-management/sidebar) and slice-1 accepted proof included `final-report-touch*` but not `session-workspace-retirement.spec.ts` or board-paging / stacking look specs. CI failed Final-report UUID asserts and `expectNoSidewaysScrollAndWholeText` ellipsis reads. Repair `a8ff15c2` updated those consumers and added title-toggle negative margin; coordinator transcript `363e0b94-67d5-49d4-b77d-48deec743aed` stashed in-progress slice 2 for the repair, then removed the clipping margin during slice-2 acceptance (`533e9750`).
  - Observed effect: one owned CI repair commit before slice 2 delivery, plus follow-on title-toggle CSS correction after the repair’s margin clipped expanded titles; slice-2 work was stashed and restored around the repair.
  - Inference: recurrence of focused consumer selection missing existing Final-report header and look-spec consumers of the same compact-header contract after local owner proof passed.
- Execution: SEED-204#attach-image-at-launch / plan 427 / first related implementation `59c47d4c2183cbb908d645f649a37bbde063abb0`
  - Timestamp: 2026-10-31T10:45:36Z (CI failure run 41194050673 on slice-2 SHA `59c47d4c`)
  - Tool: Cursor
  - Open Dough release: 0.3.79
  - Evidence: slice 2 accepted proof named `agent-launch-ad-hoc-attachments.spec.ts` and `boundary/developer-part.spec.ts`. CI run 41194050673 failed existing launch-dialog layout/model consumers (tab order / sideways scroll) and exact instruction-byte expectations after Attach images changed `LaunchDialog` and `developerPart`. Repair `752504ff` hid the file input from tab order, constrained attachment layout overflow, and restored exact-byte `developerPart`. Coordinator transcript `9b247773-9b4c-456b-9be3-4f21c7043f14` stashed in-progress slice 3 around that repair. Distinct from later unrelated Recently-done WebSocket mock flake repair `305513aa` on slice-3 SHA.
  - Observed effect: one owned CI failure and one dialog/first-input consumer repair before slice 3 delivery; layout and exact-byte consumers were outside the slice's focused attachment proof.
  - Inference: recurrence of focused consumer selection missing existing LaunchDialog layout and `developerPart` byte consumers after local owner proof passed (ODF-150).

- Execution: SEED-198#responsive-project-header / plan 424 / first related implementation `1554cd81d83386549eead40df7abdbc1bf00698b`
  - Timestamp: unknown (2026-10-31 Asia/Singapore; after slice-3 header proof green and during full `npm run test:dashboard`, before publish `c5927db4` 17:29 +08)
  - Tool: Cursor
  - Open Dough release: 0.3.78
  - Evidence: coordinator transcript `5220567c-77df-404c-a6d2-7abf6ccb5d69` L90–L94 — focused header/touched proof green; full suite then failed phone-width journeys that still clicked hidden project radios; coordinator fixed callers onto `chooseProject` / `expectProjectChoice` / `shownProjectControl` before delivery. Published with those helpers in `c5927db4`.
  - Observed effect: no owned CI failure from this miss (caught locally by the wider suite before publish); extra repair loop on phone-width selection consumers already in the suite.
  - Inference: qualified recurrence of focused/owning-surface proof missing indirect callers of the changed project-selection contract once the tab radios hide at ≤400px.
- Execution: SEED-205#logo-sidebar-toggle / plan 430 / first related implementation `63c7699e57ce9ec57112e30434df07e944d3eaea`
  - Timestamp: 2026-10-31T23:13:50+08:00 (repair commit `539b192b`; CI run 41212447397 on slice-1 SHA `63c7699e`)
  - Tool: Cursor
  - Open Dough release: 0.3.79
  - Evidence: slice 1 accepted proof named banner/Sessions/passive-mark specs (`dashboard-header*`, `frame-sessions-look`, `frame-board-look`, `system-settings-look`, `sessions-sidebar`). CI failed many shards on `expectNoSidewaysScrollAndWholeText` without `compactProjectSelectCut` after designed compact-title truncation, and `source-navigation.spec.ts` treated Sessions' decorative `img.product-mark` (`alt=""`) as injected content. Repair `539b192b`. Later owned CI also failed `preparation-legend.spec.ts` at high zoom against banner geometry (repairs `d470063c`/`5f9ca93c`/`d62f0a66`; separate iterative-repair note DD-377). Coordinator transcript `1bca2eeb-150d-41d1-ab95-a929db66954e` stashed in-progress slice 2 for the truncation repair.
  - Observed effect: one multi-shard owned CI failure and one consumer/locator repair before slice 2 resumed; later banner-geometry consumers of the same one-line banner change failed separately in prep-legend.
  - Inference: recurrence of focused owning-surface proof missing page-wide whole-text and decorative-mark consumers of the changed compact banner contract after local owner proof passed (ODF-150).

## ODF-225 — Repair stash invalidates a still-running proof <a id="odf-225"></a>

Former local code: DD-260. Repair quiescence checks only writers, so stashing an interrupted agent’s checkout while read-only tests still observe it invalidates the proof. [Evidence and current response](docs/maintainer/findings/ODF-225.md).

## ODF-121 — Transient transport failure ends observation <a id="odf-121"></a>

Former local code: DD-261. A reported GitHub transport failure ends observation and leaves later revisions without notification coverage. [Evidence and current response](docs/maintainer/findings/ODF-121.md).

Existing shared finding: [meaning and retained evidence](docs/maintainer/findings/ODF-121.md). This execution adds an occurrence under that established code; no new code or mapping is allocated.

### Occurrences

- Execution: SEED-162#keep-long-running-dashboard-sessions-responsive; before-cleanup `b0c9d8fc4290d39ce4ee23aff91fed648f915dd7:.planning/slice-plans/366-keep-long-running-dashboard-sessions-responsive/PLAN.md`; first related implementation commit `9bff183a`
  - Timestamp: unknown (around slice-5 accept near `c467f720` 2026-10-28T22:07:05+08:00)
  - Tool: Cursor
  - Open Dough release: 0.3.73
  - Evidence: coordinator transcript `526c01b7-1fb2-4f61-9a8a-64275b27fbb6` L56–L57 — `CI_MONITOR_UNAVAILABLE` (GitHub unreachable); continued; later attached `/tmp/dough-ci-501/watch-gFrx9R`
  - Observed effect: lost observation coverage once mid-execution; re-attach restored coverage for later publications including accepted tip `0d1672f7`
  - Inference: same transient-transport ending as ODF-121; managed re-attach limited the gap to already-published revisions

- Execution: SEED-163#reliably-report-dashboard-wrap-up / plan 367 / first related implementation `938f2f1e9224eb6503654fec1b8a3b033ccdd64e`
  - Timestamp: unknown (coordinator noted lost coverage after slice 2 publish `c2aa41dd` at 2026-10-28T22:00:03+08:00 and before slice 3 publish `242e5fe7` at 2026-10-28T22:17:11+08:00)
  - Tool: Cursor
  - Model: auto
  - Open Dough release: 0.3.73
  - Evidence: coordinator transcript `3fc700d8-1e3b-486e-82de-cd7b0c5e26e7` L75 — “Noting lost CI coverage once (GitHub unreachable) and continuing slice 3 acceptance.” Supplied execution limitations name `CI_MONITOR_UNAVAILABLE`. Later mailbox `/tmp/dough-ci-501/watch-UB2SnZ` retains CI_FAILURE for `c2aa41dd` (OVER BUDGET) and `242e5fe7` (retained-landing); the unavailable event payload itself is not in that mailbox.
  - Observed effect: coordinator reported lost coverage once and continued; slice 2’s hosted OVER BUDGET failure was not classified in the same turn; coverage resumed for later publications on a subsequent observer.
  - Inference: qualified recurrence of transport-ending observation loss. Exact `gh`/TLS error text is unrecovered from the dead observer; distinct from eight-hour budget expiry (ODF-259).

- Execution: SEED-174#optimize-dashboard-test-feedback / plan 376 / first related implementation `692d90320ebb6e6d0a96f61a52e0597717a982e4`
  - Timestamp: unknown (2026-10-29 Asia/Singapore; two finished observers left `CI_MONITOR_UNAVAILABLE` event files dated ~18:19 and ~19:11 +08)
  - Tool: Cursor
  - Open Dough release: 0.3.76
  - Evidence: `/tmp/dough-ci-501/watch-dzWNZd/events/000000000001.json` — `CI_MONITOR_UNAVAILABLE` reason “gh did not answer within the request's time limit”; `/tmp/dough-ci-501/watch-lDWSLx/events/000000000001.json` — same type, reason “GitHub is unreachable”; both for branch `cursor/reduce-dashboard-test-feedback-time-with-measure`. Coordinator transcript `5473d3e9-6f21-4fad-9a6f-c38bde1e1b81` noted lost coverage once mid-slice-2 and continued. Later observer `/tmp/dough-ci-501/watch-1xJHW1` retained coverage for tip `f5d22bce` as `not_required` with basis `a1703fdd` `success`.
  - Observed effect: two transport-ended observers on this execution; coordinator continued without claiming CI success; tip observation remains pending/possibly gapped relative to those dead mailboxes.
  - Inference: qualified recurrence of ODF-121 transient-transport ending (gh timeout and unreachable); distinct from eight-hour budget expiry (ODF-259) and from wrong-`--repo` 404 (ODF-256).

- Execution: SEED-189#expand-dashboard-diff-context / plan 416 / first related implementation `5c73925b9dcdffd763c20f5b81c5d1aa45413757`
  - Timestamp: unknown (2026-10-30; during slice-2 acceptance before tip publish `c9ada8b1` 15:13:13+08:00)
  - Tool: Cursor
  - Open Dough release: 0.3.78
  - Evidence: plan 416 Accepted proof note — “CI observer reported `CI_MONITOR_UNAVAILABLE` (gh failed) during slice 2 acceptance — lost coverage noted once”; coordinator transcript `1cd76bae-22c3-404c-b849-2df63d24fb85` wrote that note into `.planning/slice-plans/416-expand-dashboard-diff-context/PLAN.md`. Later observer `/tmp/dough-ci-501/watch-XRpiZS` retains tip `c9ada8b1181558efb5f2d6d075fee2ad3ff3a171` as `pending`; the unavailable event payload itself is not in that mailbox.
  - Observed effect: lost observation coverage noted once mid-slice-2; coordinator continued without claiming CI success; tip CI remains pending under a later observer.
  - Inference: qualified recurrence of ODF-121 transient-transport ending (`gh failed`); exact `gh`/TLS error text unrecovered from the dead observer; distinct from eight-hour budget expiry (ODF-259) and wrong-`--repo` 404 (ODF-256).

## ODF-226 — Proof reporter override weakens the configured verdict <a id="odf-226"></a>

Former local code: DD-262. A focused proof overrides a configured reporter that owns failure policy, making local passing assertions insufficient evidence for the project’s actual verdict. [Evidence and current response](docs/maintainer/findings/ODF-226.md).

Existing shared finding: [meaning and retained evidence](docs/maintainer/findings/ODF-226.md). This execution adds an occurrence under that established code; no new code or mapping is allocated.

### Occurrences

- Execution: SEED-163#reliably-report-dashboard-wrap-up / plan 367 / first related implementation `938f2f1e9224eb6503654fec1b8a3b033ccdd64e`
  - Timestamp: 2026-10-28T13:45:25Z (CI failure on slice 1 SHA `938f2f1e`)
  - Tool: Cursor
  - Model: auto
  - Open Dough release: 0.3.73
  - Evidence: plan accepted proof for slice 1 used `--reporter=line`; CI run 40698951934 jobs `dashboard (12/12)` and `(6/12)` reported “passed but wrote output” from `plantTrackedClosureRepository`’s bare `git init` printing default-branch advice under configured `quietReporter`. Repair `2ba5950d` switches to `git init -b main`.
  - Observed effect: local focused proof accepted; hosted quietReporter rejected the same green assertions; one fixture repair and stash of in-flight slice 2 work.
  - Inference: recurrence of reporter override hiding the project’s configured output-failure policy; the fixture noise was the proximate print, not a separate finding.

## ODF-227 — Repair delegation deletes the only regression proof <a id="odf-227"></a>

Former local code: DD-263. A coordinator explicitly requests a temporary reproduction to delete, so product repairs return without a permanent regression test and require another delegation round. [Evidence and current response](docs/maintainer/findings/ODF-227.md).

## ODF-228 — Long proof starts without checking shared-host headroom <a id="odf-228"></a>

Former local code: DD-264. A long repeated full-suite probe starts and continues on an overloaded shared host without checking load or swap, consuming hours without completing its planned evidence. [Evidence and current response](docs/maintainer/findings/ODF-228.md).

## ODF-229 — Interrupted Cursor implementation loses its proof return <a id="odf-229"></a>

Former local code: DD-265. An interrupted Cursor implementation Task leaves edits but no agent return; the coordinator must reconstruct proof and acceptance from the checkout. [Evidence and current response](docs/maintainer/findings/ODF-229.md).

Existing shared finding: [meaning and retained evidence](docs/maintainer/findings/ODF-229.md). This execution adds an occurrence under that established code; no new code or mapping is allocated. Matching uncertainty: the interrupted Task left no edits (clean tree), so the original “edits without return” symptom is absent; the decisive interrupted-without-return recovery still applied.

### Occurrences

- Execution: SEED-174#optimize-dashboard-test-feedback / plan 376 / first related implementation `692d90320ebb6e6d0a96f61a52e0597717a982e4`
  - Timestamp: unknown (2026-10-29 Asia/Singapore; after slice-1 delivery `692d9032` 18:15 +08 and before slice-2 delivery `a1703fdd` 18:32 +08)
  - Tool: Cursor
  - Open Dough release: 0.3.76
  - Evidence: coordinator transcript `5473d3e9-6f21-4fad-9a6f-c38bde1e1b81` — first slice-2 Task (“Slice 2 agent-launch optimize”) interrupted with no return; coordinator followed interrupted-delegation recovery, found clean working tree at `692d9032`, then launched fresh Task “Slice 2 optimize retry” which delivered `a1703fdd`.
  - Observed effect: one aborted implementation Task with no product edits; full recovery + fresh agent before acceptance; no work lost or dual-writer conflict.
  - Inference: qualified recurrence of interrupted Cursor implementation without return; empty-tree case made reconstruction cheap but still required a replacement writer. Host termination cause (watchdog vs other) is unestablished here.

- Execution: SEED-189#expand-dashboard-diff-context / plan 416 / first related implementation `5c73925b9dcdffd763c20f5b81c5d1aa45413757`
  - Timestamp: unknown (2026-10-30; after slice-2 Task start ~14:42 +08 and before repair Task `68cac5fa` at 14:55 +08)
  - Tool: Cursor
  - Open Dough release: 0.3.78
  - Evidence: coordinator transcript `1cd76bae-22c3-404c-b849-2df63d24fb85` L43–L48 — interrupted slice-2 delegation left substantial uncommitted work; interrupted-delegation recovery; focused proof then failed scroll preservation; delegated repair Task `68cac5fa-79f3-4b9a-985b-493c6431566f`. Interrupted implementer `65ee0ea4-d220-4b05-83e4-e9df676660e4` ends mid-tool-use (consumer-trace / git status) with no proof return.
  - Observed effect: one aborted implementation Task with uncommitted product/test edits; coordinator re-established proof from the checkout, then one repair round (detached-node scroll adjust plus Playwright `scrollIntoView` measurement pollution) before acceptance; no dual-writer publish.
  - Inference: qualified recurrence of interrupted Cursor implementation without return; edits-present case required checkout reconstruction and renewed focused proof before a replacement writer. Host termination cause unestablished. Distinct from ODF-059 refactor interrupt on the same execution.

- Execution: SEED-198#responsive-project-header / plan 424 / first related implementation `1554cd81d83386549eead40df7abdbc1bf00698b`
  - Timestamp: unknown (2026-10-31; after slice-3 Task start following `576ef4c9` 13:53 +08 and before developer resume 16:09 +08)
  - Tool: Cursor
  - Open Dough release: 0.3.78
  - Evidence: coordinator transcript `5220567c-77df-404c-a6d2-7abf6ccb5d69` L66–L71 — Task “Implement slice 3 compact selector” launched; next user turn is `resume` with no agent return; coordinator found slice-3 WIP present, classified intervening slice-2 CI as infrastructure-only, then re-established proof from the checkout. Interrupted implementer `ff760ded-80b5-4762-895e-2f682813455c` ends mid-work (preview-server cleanup) with no proof return.
  - Observed effect: one aborted implementation Task with uncommitted compact-selector edits; coordinator recovered from the checkout and completed focused/wider proof (later catching ODF-150 phone callers) before publish `c5927db4`; no dual-writer publish.
  - Inference: qualified recurrence of interrupted Cursor implementation without return; edits-present case required checkout reconstruction and renewed proof. Host termination cause unestablished.

## ODF-230 — Planned proof relies on a forbidden shared installation <a id="odf-230"></a>

Former local code: DD-266. Planning settles proof through a temporary mutable dependency link even though execution setup forbids linking another checkout’s installation. [Evidence and current response](docs/maintainer/findings/ODF-230.md).

## ODF-231 — Setup gate misses the project’s exact runtime pin <a id="odf-231"></a>

Former local code: DD-267. Readiness resolves package-lock installation and typecheck but omits the project’s runtime pin and authoritative setup checker, allowing all delivery on a different runtime. [Evidence and current response](docs/maintainer/findings/ODF-231.md).

## ODF-187 — Planned observations cannot detect regressions <a id="odf-187"></a>

Former local code: DD-268. Planning prescribes an observation whose claimed discrimination was reasoned rather than demonstrated; executing the proposed proof can pass on the unfixed behavior or conflict with the project’s proof policy. [Evidence and current response](docs/maintainer/findings/ODF-187.md).

## ODF-232 — Acceptance publishes an explicitly unobserved host fact <a id="odf-232"></a>

Former local code: DD-270. A return explicitly reports native host behavior unobserved, yet acceptance publishes that behavior as factual guidance and records only pending native evidence. [Evidence and current response](docs/maintainer/findings/ODF-232.md).

## ODF-233 — A plan forbids the representation its promised behavior needs <a id="odf-233"></a>

Former local code: DD-272. A correction’s boundary forbids new record/schema data while its behavior requires a fact the existing entrypoint or record does not supply, leaving a background coordinator to reinterpret scope. [Evidence and current response](docs/maintainer/findings/ODF-233.md).

## ODF-234 — Journey acceptance omits the next state its own guidance promises <a id="odf-234"></a>

Former local code: DD-273. Acceptance proves a correction’s first successful rerun but omits subsequent or adjacent states produced by the same journey, including explicitly listed untested record states. [Evidence and current response](docs/maintainer/findings/ODF-234.md).

## ODF-223 — A gap disposition substitutes reasoning for its actual guided path <a id="odf-223"></a>

Former local code: DD-277. Structured story obligations are marked no user cost or proved from a return’s narrow explanation or a helper’s behavior without tracing/running the paths the published guidance directs into that state. [Evidence and current response](docs/maintainer/findings/ODF-223.md).

## ODF-235 — New candidate ownership leaves old failure cleanup unreviewed <a id="odf-235"></a>

Former local code: DD-281. A slice changes a rebuildable candidate into irreplaceable hand-resolved work but does not trace existing failure exits that abandon it, dropping that resolution to the reflog. [Evidence and current response](docs/maintainer/findings/ODF-235.md).

## ODF-236 — Refactoring removes a deliberate caller behavior difference <a id="odf-236"></a>

Former local code: DD-286. A refactor deletes a caller override to unify a rule despite knowing it changes that caller’s preserved edge behavior, reporting the choice after editing instead of preserving it. [Evidence and current response](docs/maintainer/findings/ODF-236.md).

## ODF-237 — Unattached launch planning assumes an incompatible capture contract <a id="odf-237"></a>

Former local code: DD-289. Planning promises landing context for an unattached launch without observing that the capture schema and admission path require a story identity. [Evidence and current response](docs/maintainer/findings/ODF-237.md).

<a id="dd-288"></a>

## ODF-238 — A planned native proof depends on a future release <a id="odf-238"></a>

Former local code: DD-288. A final native observation depends on a deployment or release path unavailable before landing; planning must distinguish the actual delivery prerequisite. [Retained occurrences and response](docs/maintainer/findings/ODF-238.md). All distinct execution evidence is retained in Open Dough `ccf309a69459284de3f1d45f2de813e9180c2971:docs/maintainer/findings/ODF-238.md`; the pre-compaction source is `f274a3d0c729504bf8ce00614bf3cd236b7e088b:DearDough.md`.

### Occurrences

Distinct executions, original timestamps/releases/tools, observed effects and qualified inferences are [retained at ODF-238](docs/maintainer/findings/ODF-238.md); rereading adds no occurrence.

## ODF-248 — Refactor reruns unchanged consumer proof <a id="odf-248"></a>

Former local code: DD-292. A refactor repeated the accepted thirty-spec terminal consumer command although only a subset of its observations moved. Existing guidance requires reusing proof whose boundaries remain unchanged. [Evidence and current response](docs/maintainer/findings/ODF-248.md).

## ODF-249 — Whole-suite proof runs before the refactor that invalidates it <a id="odf-249"></a>

Former local code: DD-293. An implementation agent ran the changed surface's whole suite before the independent refactor pass, and the refactor then moved the measured code, so the suite had to run again on the final state. [Evidence and current response](docs/maintainer/findings/ODF-249.md).

## ODF-250 — A plan's proof table omits an answer state its story scopes in <a id="odf-250"></a>

Former local code: DD-294. The story's required behavior named three launch answer states; the plan's proof table and slice proof named two, so the implementation return listed the third untested and the coordinator returned the slice for it. [Evidence and current response](docs/maintainer/findings/ODF-250.md).

## ODF-251 — An open Story Branch execution has no guided path to queue a correction it discovers <a id="odf-251"></a>

Former local code: DD-298. An execution whose story must stay open found discrepancies that needed bounded corrections queued on trunk before it could finish. Its own records reach trunk only at wrap-up, and the launch's landing context is bound to its own worktree, so the coordinator improvised a second worktree and a direct publication. [Evidence and current response](docs/maintainer/findings/ODF-251.md).

## ODF-252 — A story recorded ready still needs developer choices and fixtures before its first slice <a id="odf-252"></a>

Former local code: DD-299. The plan left "the developer names the observation project, fixture stories, models and time budget at execution setup" and was assessed ready. No configured project held a usable fixture story, so execution's first turn ended in a question and five fixture stories were authored and published mid-execution. [Evidence and current response](docs/maintainer/findings/ODF-252.md).

## ODF-253 — The start command's guidance names the trunk branch but not its flag <a id="odf-253"></a>

Former local code: DD-300. A native session following the one-shot start instructions passed `--trunk master`, was refused with `missing target`, searched the installed script for the option name, and retried with `--target`. [Evidence and current response](docs/maintainer/findings/ODF-253.md).

## ODF-254 — Accepted proof let a test setup step perform an action the story requires of the product <a id="odf-254"></a>

Former local code: DD-301. A slice 3 journey made an unknown-ancestry case pass by running `git fetch origin` in the test before expecting completion. The coordinator accepted it as a covered case, although story key example 2 needs completion without anyone fetching another writer's snapshot. The limitation surfaced only when slice 5 listed it as a gap. That cost a returned slice and rewritten lifecycle cases. [Evidence and current response](docs/maintainer/findings/ODF-254.md).

## ODF-255 — A slice's refactor widens a seam that a later slice of the same plan removes <a id="odf-255"></a>

Former local code: DD-304. In slice 2, the refactor pass moved a shared rule into the records module and re-exported it through coverage, the module whose records re-export slice 5 was planned to drop. The refactor brief carried only the current slice, so the pass could not see that plan direction. Slice 5 then repointed the added names too, and the plan's slice 5 text had to be revised. [Evidence and current response](docs/maintainer/findings/ODF-255.md).

## ODF-256 — Managed delivery accepts a `--repo` that does not match the workspace's remote <a id="odf-256"></a>

Former local code: DD-305. The coordinator passed `--repo nerds-odd-e/open-dough` for a checkout whose `origin` is `terryyin/open-dough`. It had inferred the repository from the other project in the same task. `deliver` published to `origin` and attached an observer for the named repository. That observer then reported `CI_MONITOR_UNAVAILABLE` (HTTP 404 on `ci.yml`). Nothing compared the supplied repository with the remote the push used. [Evidence and current response](docs/maintainer/findings/ODF-256.md).

## ODF-169 — Stale replay base includes sibling commits <a id="odf-169"></a>

Former local code: DD-306. A managed-delivery retry carries the old published base instead of its newly reconciled suffix base and replays sibling commits into conflicts. [Evidence and current response](docs/maintainer/findings/ODF-169.md).

## ODF-139 — Reported defect dismissed without checking the story <a id="odf-139"></a>

Former local code: DD-308. A named gap contradicts the story goal, but acceptance judges it against the plan's narrower scope and delivers it. [Evidence and current response](docs/maintainer/findings/ODF-139.md).

### Occurrences

Distinct executions, original timestamps/releases/tools, observed effects and qualified inferences are [retained at ODF-139](docs/maintainer/findings/ODF-139.md); rereading adds no occurrence.

## ODF-257 — Test runs leave detached product children after timed-out teardowns, and the developer found them first <a id="odf-257"></a>

Former local code: DD-310. Timed-out journeys whose cleanup was abandoned left the product's detached Cursor runners and fake-host clients idling for hours under deleted temp HOMEs; no step of the execution looked for leftovers after proof runs until the developer reported the machine out of memory. [Evidence and current response](docs/maintainer/findings/ODF-257.md).

## ODF-258 — A re-plan decision flagged by the first slice reached the developer only with the last <a id="odf-258"></a>

Former local code: DD-311. Slice 1's own threshold said a saving under 30 % means re-planning the measured target with the developer; the coordinator recorded it as a decision for the next checkpoint and delivered eight more slices before presenting it. [Evidence and current response](docs/maintainer/findings/ODF-258.md).

## ODF-259 — The CI observer's budget expires inside a long execution <a id="odf-259"></a>

Former local code: DD-313. The execution observer ends after its eight-hour budget; an execution running longer loses coverage between the expiry and the next managed delivery, which starts a new observer. [Evidence and current response](docs/maintainer/findings/ODF-259.md).

## ODF-260 — A nine-slice story ran about twenty hours without a split <a id="odf-260"></a>

Former local code: DD-314. The plan started with eight slices and gained a ninth; execution took about twenty hours of wall time with the developer asleep for most of it, and the plan grew past 1,100 lines, while the resplit guidance triggers only above fifteen slices. [Evidence and current response](docs/maintainer/findings/ODF-260.md).

## ODF-261 — Focused test filter matches the execution checkout path <a id="odf-261"></a>

Former local code: DD-315. A Playwright file regex intended to select review specs also matched the execution worktree's directory name. A successful-looking invocation therefore started a much broader suite before the collected selection was checked. [Evidence and current response](docs/maintainer/findings/ODF-261.md).

## ODF-262 — Permission-only probes split a human click journey <a id="odf-262"></a>

Former local code: DD-316. Two read-only permission probes each required a human notification click before separate callback probes exercised the operation consuming that permission. Combining consent with a minimal safe operation may reduce manual rounds when permission inspection resolves no independent risk. [Evidence and current response](docs/maintainer/findings/ODF-262.md).

## ODF-263 — Phase artifact capture overwrites newer recovery evidence <a id="odf-263"></a>

Former local code: DD-317. A native-proof artifact copy retained the older partial context over the completed recovery context. This is a general evidence-retention lesson; no defect in the combined maintenance wrapper or shared publication helper is established. [Evidence and current response](docs/maintainer/findings/ODF-263.md).

## ODF-303 — Native JSON hid an existing source-only reviewer <a id="odf-303"></a>

Former local code: DD-318. The retained Codex CLI JSON did not expose child-review calls. Acceptance treated
that visibility gap as missing invocation evidence and paid for a revised run
before recovering the first run's existing native child lineage and commitments.

[Retained evidence and current assessment](docs/maintainer/findings/ODF-303.md).

## ODF-304 — Coordinator behavior edits after the refactor pass skipped independent review <a id="odf-304"></a>

Former local code: DD-321. After a native run, the coordinator diagnosed a misclassification and added an observer field, assessor branch and rejection control to the slice's harness itself, after the independent refactor pass, then committed the slice without another refactor or delegated return. Wrap-up allows the coordinator only mechanical formatting and lint repairs at that point.

[Retained evidence and current assessment](docs/maintainer/findings/ODF-304.md).

## ODF-305 — A new cross-host action's focused proof missed the spec pinning the other hosts' entries <a id="odf-305"></a>

Former local code: DD-322. Slice 2 offered a separate Stop from the host `stop` fact alone, which also gave Claude/Codex entries a duplicate Stop beside their stopping Mark as done. The slice's focused proof ran the Cursor stop and existing done specs but not `recently-done-story-sessions.spec.ts`, which pins those entries; CI caught it and a two-file repair (`fa05f9ec`) narrowed the offer to hosts whose Done does not already stop.

[Retained evidence and current assessment](docs/maintainer/findings/ODF-305.md).

## ODF-264 — Broad startup reads lose required context to truncation <a id="odf-264"></a>

Broad reference/metadata batches omit required passages and force repeated retrieval despite existing targeted-reading guidance. Distinct executions and unknown provenance remain at the [authoritative owner](docs/maintainer/findings/ODF-264.md); repeated calls within one execution add no occurrence.

### Occurrences

- Execution: SEED-186#document-dashboard-product-intent / plan 416, first implementation `85e1d6caeca4b573fb7daae6ae0c67dc378bcd2a`
  - Timestamp: unknown (2026-10-30 Codex execution; before execution-complete handoff)
  - Tool: Codex
  - Open Dough release: unknown; installed guidance at claim `cba3aa43858318729018af6ab75f13a98e63c13a`
  - Evidence: dashboard launch `4939d524-d621-4b33-b7a2-32fc33d6105b`, coordinator startup tool results reported truncation at 12,177 and 14,937 original tokens while batching source/setup/ADR/publication reads; later calls retrieved ADR 0008 and ADR 0002 passages separately. This execution's retrospective repeated the same issue in a 12,453-token combined finding-history read.
  - Observed effect: required or selected passages were omitted from oversized responses, followed by narrower retrieval; no elapsed or total token saving is measured.
  - Inference: recurrence under existing boundary/targeted-retrieval guidance. Per-command token settings did not bound the aggregate functions.exec result; inspect aggregate size and retrieve only decision-relevant sections.

## ODF-306 — A delegated native probe ended a pending consent prompt and recorded a refusal <a id="odf-306"></a>

Former local code: DD-323. An implementation agent probing a new macOS notification identity ended the
sending process while the system's first-use permission prompt was still
waiting. macOS recorded Denied for that identity, so a promised first-use
consent observation became a human recovery round instead.

[Retained evidence and current assessment](docs/maintainer/findings/ODF-306.md).

## ODF-307 — Coordinator screen probes competed with the developer's live desktop <a id="odf-307"></a>

Former local code: DD-324. To observe system UI, the coordinator repeatedly brought System Settings and a
test browser to the front and resized windows on the developer's own desktop,
while the developer was also working there and answering its questions.

[Retained evidence and current assessment](docs/maintainer/findings/ODF-307.md).

## ODF-322 — A projected delivery result drops the running command's handle <a id="odf-322"></a>

Former local code: DD-325. The coordinator reduced a guarded delivery call to its output text, dropping the live command's session handle; the terminal receipt was recovered through checkout inspection and an exact-candidate resume. [Evidence and current response](docs/maintainer/findings/ODF-322.md).

## ODF-324 — Native checks keep asking the developer after attribution is established <a id="odf-324"></a>

Former local code: DD-327. Former branch-local code: DD-325 for SEED-144#branded-alert-click-automation only. Native acceptance kept requesting interactive developer rounds after attribution was established, including a full replay for a message-only change, until the developer withdrew. [Evidence and current response](docs/maintainer/findings/ODF-324.md).

## ODF-323 — A caller-written plan-status mutation survives a later delivery refusal <a id="odf-323"></a>

Former local code: DD-328. Former branch-local code: DD-326 for SEED-144#branded-alert-click-automation only. A guarded delivery's caller-written status update stayed applied after a later preparation refusal; its unbounded retry advanced the next slice. Related DD-326 (a failed updater contained before publication) is retained there as counterevidence. [Evidence and current response](docs/maintainer/findings/ODF-323.md).

## ODF-325 — Coordinator launched an empty agent while waiting on delegated work

Former local code: DD-329. A coordinator starts a no-op agent solely to stay active while real delegated work is pending, despite an existing waiting rule.

[Retained evidence and current response](https://github.com/terryyin/open-dough/blob/main/docs/maintainer/findings/ODF-325.md). Original occurrence provenance and distinct effects are recoverable in Open Dough `ccf309a69459284de3f1d45f2de813e9180c2971:docs/maintainer/findings/ODF-325.md` and this project's source snapshot `f274a3d0c729504bf8ce00614bf3cd236b7e088b:DearDough.md`. Name adoption is not resolution.

## ODF-326 — A second source-only review repeated unchanged inputs

Former local code: DD-331. The mandatory per-slice source-only review repeats unchanged inputs; available repeat and reuse observations do not settle its marginal benefit or independence.

[Retained evidence and current response](https://github.com/terryyin/open-dough/blob/main/docs/maintainer/findings/ODF-326.md). Original occurrence provenance and distinct effects are recoverable in Open Dough `ccf309a69459284de3f1d45f2de813e9180c2971:docs/maintainer/findings/ODF-326.md` and this project's source snapshot `f274a3d0c729504bf8ce00614bf3cd236b7e088b:DearDough.md`. Name adoption is not resolution.

Existing shared finding: this execution adds a reuse occurrence under that established code; no new code or mapping is allocated.

### Occurrences

Distinct executions, original timestamps/releases/tools, observed effects and qualified inferences are [retained at ODF-326](docs/maintainer/findings/ODF-326.md); rereading adds no occurrence.

## ODF-327 — Preparation left an evaluation's criteria for execution while the evaluated run was imminent

Former local code: DD-332. Preparation schedules evaluation criteria as later execution while the observed event can start first, making the resulting assessment exploratory.

[Retained evidence and current response](https://github.com/terryyin/open-dough/blob/main/docs/maintainer/findings/ODF-327.md). Original occurrence provenance and distinct effects are recoverable in Open Dough `ccf309a69459284de3f1d45f2de813e9180c2971:docs/maintainer/findings/ODF-327.md` and this project's source snapshot `f274a3d0c729504bf8ce00614bf3cd236b7e088b:DearDough.md`. Name adoption is not resolution.

## ODF-328 — A fresh delivery refused the obligation its own plan update would close

Former local code: DD-333. A coordinator leaves an obligation disposition for a plan update that guarded delivery runs only after its obligation check; the existing gate correctly refuses.

[Retained evidence and current response](https://github.com/terryyin/open-dough/blob/main/docs/maintainer/findings/ODF-328.md). Original occurrence provenance and distinct effects are recoverable in Open Dough `ccf309a69459284de3f1d45f2de813e9180c2971:docs/maintainer/findings/ODF-328.md` and this project's source snapshot `f274a3d0c729504bf8ce00614bf3cd236b7e088b:DearDough.md`. Name adoption is not resolution.

## ODF-329 — Implementation returns failed the delivery formatter's lint

Former local code: DD-334. Delegation forbids the hook-owned lint command without settling a read-only check of authored files, so coordinator formatting first exposes lint defects after refactoring.

[Retained evidence and current response](https://github.com/terryyin/open-dough/blob/main/docs/maintainer/findings/ODF-329.md). Original occurrence provenance and distinct effects are recoverable in Open Dough `ccf309a69459284de3f1d45f2de813e9180c2971:docs/maintainer/findings/ODF-329.md` and this project's source snapshot `f274a3d0c729504bf8ce00614bf3cd236b7e088b:DearDough.md`. Name adoption is not resolution.

Existing shared finding: this execution adds an occurrence under that established code; no new code or mapping is allocated.

### Occurrences

Distinct executions, original timestamps/releases/tools, observed effects and qualified inferences are [retained at ODF-329](docs/maintainer/findings/ODF-329.md); rereading adds no occurrence.

## ODF-330 — Hand-built preparation input dropped the plan from ownedPaths

Former local code: DD-335. A hand-built owned-path list trims significant porcelain status spacing and corrupts a path; the input guard contains the mistake before project commands.

[Retained evidence and current response](https://github.com/terryyin/open-dough/blob/main/docs/maintainer/findings/ODF-330.md). Original occurrence provenance and distinct effects are recoverable in Open Dough `ccf309a69459284de3f1d45f2de813e9180c2971:docs/maintainer/findings/ODF-330.md` and this project's source snapshot `f274a3d0c729504bf8ce00614bf3cd236b7e088b:DearDough.md`. Name adoption is not resolution.

### Occurrences

Distinct executions, original timestamps/releases/tools, observed effects and qualified inferences are [retained at ODF-330](docs/maintainer/findings/ODF-330.md); rereading adds no occurrence.

<a id="dd-337--preparation-recorded-measured-allocations-without-their-full-sort-key"></a>

## ODF-355 — Preparation recorded measured allocations without their full sort key

Former local code: DD-337.

Plan 353's story and plan quoted after-run totals from a scratch reconstruction (599.2 / 599.5 / 596.6 and a rename's 621.7 / 591.8 / 581.8) whose order among jobs of equal recorded seconds was never written down; no implementation could reproduce them.

### Occurrences

Distinct executions, original timestamps/releases/tools, observed effects and qualified inferences are [retained at ODF-355](docs/maintainer/findings/ODF-355.md); rereading adds no occurrence.

<a id="dd-338--a-direct-formatter-command-in-fresh-delivery-lacked-the-packages-binaries"></a>

## ODF-356 — A direct formatter command in fresh delivery lacked the package's binaries

Former local code: DD-338.

The guarded fresh delivery runs each preparation operation directly without a shell, so `node scripts/lint.mjs --fix` found neither `eslint` nor `prettier` on PATH and the first delivery attempt of slice 1 failed; the same operation as `npm run format` succeeded.

### Occurrences

Distinct executions, original timestamps/releases/tools, observed effects and qualified inferences are [retained at ODF-356](docs/maintainer/findings/ODF-356.md); rereading adds no occurrence.

- Execution: SEED-191#optimize-dashboard-test-feedback / plan 419 (`0bb810742a61e7ded6b51989b26a5eb9df8f8a43:.planning/slice-plans/419-optimize-dashboard-test-feedback/PLAN.md`), first implementation `544f6790543f810c9f1d946712600d1271a1ec65`
  - Timestamp: 2026-10-30T16:39:28+08:00 (first slice 2 fresh delivery attempt before accepted `544f6790` at 16:40:04+08:00)
  - Tool: Cursor
  - Model: gemini-4-argon
  - Open Dough release: modified; revision `7225da81df32e6fc59debf9b2943f3166335c9f5`; base 0.3.77
  - Evidence: coordinator transcript `08443b87-04c2-43dc-88a7-1a9d6107338c` — first `execution-increment-delivery.mjs fresh` for slice 2 passed `["node","scripts/lint.mjs","--fix"]` in `formatting`, which returned `preparation-failed` (`eslint: not found on PATH ... prettier: not found on PATH`); retry with `["npm","run","format"]` succeeded (`544f6790`).
  - Observed effect: one refused preparation attempt and a second guarded request; no commit or publication harm.
  - Inference: recurrence of ODF-356 when reading `"format": "node scripts/lint.mjs --fix"` from `package.json` without wrapping it in `npm run format` so `node_modules/.bin` is on PATH.

- Execution: SEED-206#explicit-reread-freshness / plan 431, first implementation `2010301f933b951b34e37c6538c957658a545080`
  - Timestamp: 2026-10-31T23:00:00+08:00 (approx.; first slice 1 fresh delivery refused before accepted `2010301f`)
  - Tool: Cursor
  - Open Dough release: 0.3.79
  - Evidence: coordinator session for plan 431 — first `execution-increment-delivery.mjs fresh` for slice 1 passed `["node","scripts/lint.mjs","--fix"]` in `formatting`, which returned `preparation-failed` (`eslint: not found on PATH` / `prettier: not found on PATH`); retry with `["npm","run","format"]` published `2010301f`.
  - Observed effect: one refused preparation attempt and a second guarded request; no commit or publication harm.
  - Inference: recurrence of ODF-356; prefer `npm run format` as the selective formatter operation so `node_modules/.bin` is on PATH.

<a id="dd-340--preparation-observations-recorded-results-their-own-commands-contradict"></a>

## ODF-357 — Preparation observations recorded results their own commands contradict

Former local code: DD-340.

Plan 354's "Preparation observations" quoted command results that the same commands, rerun at the same revision, do not give: a premise grep's file list, a "differs only in" comparison, and a key example's file count.

### Occurrences

Distinct executions, original timestamps/releases/tools, observed effects and qualified inferences are [retained at ODF-357](docs/maintainer/findings/ODF-357.md); rereading adds no occurrence.

<a id="dd-341--coordinator-wrote-subagent-completion-notices-in-its-own-turn"></a>

## ODF-358 — Coordinator wrote subagent completion notices in its own turn

Former local code: DD-341.
Former local code: DD-337 on the claude/accept-original-source-promises-when-a-plan-narr branch at `f29e9fff5daed9d384bee60b9edbd34b6ea65157`; reassigned during integration to resolve a concurrent local-code collision.
After launching background agents and saying it would wait, the coordinator emitted text formatted as `<task-notification>` results inside its own assistant turn: once an invented reviewer return and an invented implementer report (claimed files and passing tests), once a premature completion notice for a still-running native round.

### Occurrences

Distinct executions, original timestamps/releases/tools, observed effects and qualified inferences are [retained at ODF-358](docs/maintainer/findings/ODF-358.md); rereading adds no occurrence.

<a id="dd-342--a-developer-run-observation-inside-a-slices-proof-cannot-be-delivered-with-that-slice"></a>

## ODF-359 — A developer-run observation inside a slice's proof cannot be delivered with that slice

Former local code: DD-342.
Former local code: DD-338 on the claude/accept-original-source-promises-when-a-plan-narr branch at `f29e9fff5daed9d384bee60b9edbd34b6ea65157`; reassigned during integration to resolve a concurrent local-code collision.
Plan 354 put its paid baseline round in slice 1's proof and made slice 2 depend on its result. Guarded fresh delivery marks the delivered slice `done`, so the credential-free part could be delivered only after the plan moved the round to slice 2 as a pre-change prerequisite.

### Occurrences

Distinct executions, original timestamps/releases/tools, observed effects and qualified inferences are [retained at ODF-359](docs/maintainer/findings/ODF-359.md); rereading adds no occurrence.

<a id="dd-344--a-new-installed-command-assumed-a-writable-system-temp-directory-that-host-sandboxes-refuse"></a>

## ODF-360 — A new installed command assumed a writable system temp directory that host sandboxes refuse

Former local code: DD-344.

A command added for coordinators to run (`source-freshness.mjs`) made its scratch directory with `mkdtemp(os.tmpdir())`. Every credential-free proof ran unsandboxed, so the first paid Codex round found that its workspace-only sandbox refuses the system temp directory and `/tmp`; the round failed and a fix plus a retry followed.

### Occurrences

Distinct executions, original timestamps/releases/tools, observed effects and qualified inferences are [retained at ODF-360](docs/maintainer/findings/ODF-360.md); rereading adds no occurrence.

<a id="dd-348--an-implementation-agent-met-a-file-line-limit-by-joining-wrapped-lines"></a>

## ODF-361 — An implementation agent met a file line limit by joining wrapped lines

Former local code: DD-348.

A slice told to bring two skill files to 250 lines moved some detail but
reached the limit by joining four wrapped paragraphs onto over-long lines; the
project formatter preserves prose wrapping, so nothing would have reflowed them.

### Occurrences

Distinct executions, original timestamps/releases/tools, observed effects and qualified inferences are [retained at ODF-361](docs/maintainer/findings/ODF-361.md); rereading adds no occurrence.

<a id="dd-349--post-change-refactor-compressed-planmd-story-obligations-under-the-file-size-gate"></a>

## ODF-362 — Post-change refactor compressed PLAN.md Story obligations under the file-size gate

Former local code: DD-349.

The post-change refactor pass treats the executable plan as an ordinary changed
file subject to the 250-line limit, then rewrites or shortens `## Story
obligations` so structured dispositions no longer match the plan format the
delivery gate expects; the coordinator must restore the section before fresh
delivery.

### Occurrences

Distinct executions, original timestamps/releases/tools, observed effects and qualified inferences are [retained at ODF-362](docs/maintainer/findings/ODF-362.md); rereading adds no occurrence.

## DD-363 — Coordinator source-review hard-breaks fail fresh delivery

Coordinator-authored `source-review.md` used Markdown hard-break trailing spaces
that the fresh-delivery preparation refused; selective `npm run format` does not
cover Markdown, so the defect reached the first guarded delivery.

### Occurrences

- Execution: SEED-157#check-stalled-delegated-verification; plan and source-review recoverable at before-cleanup `e8e841c8e15d23db9f8d9e4d86923d134294992b` (`.planning/slice-plans/363-check-stalled-delegated-verification/`); first related implementation commit `cd30010f9044cf703596a58e98a494e610cc6f2d`
  - Timestamp: unknown (2026-10-28; first fresh-delivery attempt before accepted `cd30010` at 16:19:23+08:00)
  - Tool: Cursor
  - Open Dough release: 0.3.73
  - Evidence: coordinator transcript `3bd97cc2-93e0-4e61-bca4-b477e0d7b5f4` — after writing/updating `source-review.md` and running `npm run format`, first `execution-increment-delivery.mjs fresh` failed; repair removed trailing hard-break spaces on the Launch/Input/Reviewer header lines; retry published `cd30010`. Distinct from ODF-329 (implementer ESLint under a lint-forbidden delegation brief).
  - Observed effect: one refused fresh-delivery attempt and a mechanical coordinator repair before the accepted publish.
  - Inference: qualified one-off. Coordinator Markdown artifacts need a pre-delivery whitespace check or must avoid hard-break trailing spaces; format alone does not cover them.

## DD-364 — Source-only review launched without the full seed examples

A coordinator's first source-only review prompt omitted Key examples 3–4, so
the reviewer returned incomplete commitments and a second complete-seed launch
was required before acceptance.

### Occurrences

- Execution: SEED-158#publish-awaiting-hosted-proof
  - Timestamp: 2026-10-28T16:22:00+08:00
  - Tool: Cursor
  - Model: auto
  - Open Dough release: modified; revision 67fad4e0; base 0.3.73
  - Evidence: before-cleanup `1223cddb7bd75f7f56d4668ebd46930e28326491:.planning/slice-plans/364-publish-awaiting-hosted-proof/source-review.md` Launch note ("first launch's coordinator prompt omitted examples 3–4"); coordinator transcript relaunch; subagents `a0e1094e` (incomplete seed) then `8dd2f633` (complete seed)
  - Observed effect: one discarded source-only review, then a second launch that recovered examples 3–4 before commitment allocation
  - Inference: distinct from ODF-326 (unchanged-input repeat); here the first inputs were incomplete, so the second launch was corrective rather than redundant

## DD-365 — Commit-specific preparation approval repeats after safe reconciliation

Approval named one preparation commit, then a metadata-only rebase changed its
SHA while retaining the reviewed story, plan and backlog link. Automatic
approval review required another human approval before publication.

### Occurrences

- Execution: SEED-164#dashboard-ci-time; first implementation `7eda0986bafe78cbf6088df514bb6b088edf9333`
  - Timestamp: unknown
  - Tool: Codex
  - Open Dough release: unknown
  - Evidence: execution conversation; approval of preparation `3c5f3ded`, reconciliation onto another chat's metadata as `aeff46decceb5fef150962b5ce72db259d866382`, then explicit approval of preparation-only changes and safe reconciliation. Seed/plan bytes and the sole backlog plan-link edit were checked unchanged before publication.
  - Observed effect: publication paused for a second human approval although the reviewed preparation change was unchanged.
  - Inference: qualified one-off; requesting approval for the concrete change scope plus safe reconciliation can avoid a SHA-only authorization becoming stale. This differs from ODF-262's permission-only UI probes.

## DD-366 — Story-branch increment publish blocked by trunk-targeted open first-landing expectation

A dashboard launch plants an open first-landing expectation whose landing
context targets trunk (`main`). Story-branch increment publication auto-resolves
that expectation and refuses because the publish target is the story branch, not
trunk. Fresh delivery commits then stops; resume without landing context accepts
the story-branch candidate.

### Occurrences

- Execution: SEED-166#handle-stale-worktree-bundles; plan at before-cleanup `d3bfd15b60526de1430ca12da7c3acb1a12447ee:.planning/slice-plans/369-handle-stale-worktree-bundles/PLAN.md`; first related implementation commit `0bb02d31c8e9c6c995bfcc41c0e9685ab387e8ea`
  - Timestamp: unknown (2026-10-29; after slice-1 commit `0bb02d31`, through execution-complete publish)
  - Tool: Cursor
  - Open Dough release: 0.3.74
  - Evidence: coordinator transcript `a56ca4f1-4b16-4f30-a9c3-ee4138c9c1e5` — each `execution-increment-delivery.mjs fresh` commit succeeded then refused with “Publication does not match the supplied landing context”; open first-landing expectation keyed by workspace+branch named landing-context.json targeting `refs/heads/main`; `execution-increment-resume.mjs resume` of the same candidate then accepted on the story branch without supplying `--landing-context`
  - Observed effect: every story-branch fresh publish interrupted on trunk-targeted landing retain; resume without landing context accepted the candidate
  - Inference: distinct from ODF-251 (second worktree for trunk corrections). Planted trunk first-landing expectation and story-branch publish target collide on the same launch workspace; auto-resolve should not apply trunk landing to execution-branch increments

## DD-367 — Delegated dashboard proof omitted its required sandbox wrapper

The coordinator handed off dashboard proof without carrying the established
escalated socket/process-inspection wrapper. Two sandboxed diagnostic runners
hung in teardown when process inspection was denied; precise termination and
cleanup attribution were needed before usable proof could continue.

### Occurrences

- Execution: SEED-167#cheap-isolated-fixtures; first implementation `8c55a30c56d324100cc44cbb105123aa8ebfc823`
  - Timestamp: unknown (2026-10-29, Asia/Singapore; slice-1 diagnostic attempts)
  - Tool: Codex
  - Open Dough release: 0.3.74
  - Evidence: coordinator/implement_origin_preparation conversation; diagnostic runners12117/17810 ended143 after denied ps teardown; slice1-proof.md, slice1-quiescence.json and aborted-owned-paths.json in `/private/tmp/cheap-isolated-fixtures-167`; final escalated guard runs ended0.
  - Observed effect: two attempts supplied no complete pass; owned processes required termination and four generic temporary directories were retained because ownership was uncertain.
  - Inference: carry the known runtime wrapper in each proof handoff before launch; an omitted permission boundary can invalidate teardown evidence even when test bodies run. No duration saving is inferred.

## DD-368 — A CI log excerpt hides an earlier failed test in the same job

The default CI diagnostic keeps lines around GitHub error markers. With the quiet dashboard reporter, the process-exit marker follows only the last test failure; an earlier failure can be omitted without a complete failed-test inventory. This differs from ODF-221's same-cause sibling repair omission: here the first diagnosis did not expose the sibling failure at all.

### Occurrences

- Execution: SEED-169#compact-session-entry; first implementation `c036dbd73a6f58949356b3b7de497085642bd1fc`
  - Timestamp: unknown
  - Tool: Codex
  - Open Dough release: unknown; installed diagnostic at `c036dbd73a6f58949356b3b7de497085642bd1fc:.agents/skills/dough-execute-plan/scripts/ci-github-diagnostic.mjs`
  - Evidence: [run 40817756668, dashboard12](https://github.com/terryyin/open-dough/actions/runs/40817756668/job/123262746829), 2026-10-29 UTC logs, has FAIL lines for agent-launch-attention.spec.ts and sessions-sidebar-navigation-cases.spec.ts. The diagnostic excerpt showed only navigation. After its repair `76d61616d6e74866024a3091a2ec7040d2b9791e`, [run 40819519249, dashboard12](https://github.com/terryyin/open-dough/actions/runs/40819519249/job/123268443339) retained only the unchanged attention failure. Full logs were read through the same CI GitHub source to verify both inventories.
  - Observed effect: the coordinator published the navigation-only repair before discovering that readiness comparison had already failed in the first job; another CI cycle repeated that known-but-unseen failure.
  - Inference: bounded per-failure inventory before repair publication could have avoided at least that extra cycle; retain bounded excerpts without treating a tail as the complete failed-test list.

## DD-369 — Source-review put obligation IDs in the Slice column

Coordinator-authored `source-review.md` placed disposing obligation ids in the
Commitments table's Slice column, and the first Story obligations `Reported`
lines lacked the required `slice N — "…"` quote shape. `story-obligations.mjs
check` refused until both were rewritten to the consuming reader's shapes.

### Occurrences

- Execution: SEED-182#standardize-test-optimization-candidates / plan 414, first implementation `ca65ffdfc73dc0adfabbf917abc6989fc8831793`
  - Timestamp: unknown (2026-10-30; source-review and obligation acceptance before `ca65ffdf` at 12:45:07+08:00)
  - Tool: Cursor
  - Open Dough release: modified; revision `e46170ee1d19e03290ff7cbcbf68932bcc5cb20c` Take base; VERSION 0.3.77
  - Evidence: coordinator transcript `9235c917-6cb2-43bc-88ee-d439f170ed9a` — first Write of `source-review.md` row 4 used `| … | G1 | |` (obligation id in Slice); first Story obligations block used multi-line `Reported: slice 1 acceptance — …` without the quoted form; after inspecting reader-expected shapes, rewritten with `|  | G1 |` and `Reported: slice 1 — "…"`, then check passed before publish `ca65ffdf`. Spent plan/source-review recoverable at before-cleanup `e53e4aa5975b71eaf9e584040fc5910fbfc81692:.planning/slice-plans/414-standardize-test-optimization-candidates/`
  - Observed effect: one local repair round on planning records before the first accepted increment; no product rework and no incorrect slice completion published
  - Inference: qualified recurrence of writing to a consuming reader's format without exercising it first (same class as the plan-layout ODF-074 occurrence on plan 372). Checking `story-obligation-source-review` / Reported shapes before the first write would avoid the repair; no escaping product defect claimed

- Execution: SEED-186#document-dashboard-product-intent / plan 416, first implementation `85e1d6caeca4b573fb7daae6ae0c67dc378bcd2a`
  - Timestamp: unknown (2026-10-30 Codex execution; before execution-complete handoff)
  - Tool: Codex
  - Open Dough release: unknown; installed guidance at claim `cba3aa43858318729018af6ab75f13a98e63c13a`
  - Evidence: same launch, first G1 write in plan 416 used unquoted `Reported: slice 1 — implementation consumer inspection...`; `story-obligations.mjs check --slice 1` returned `malformed-reported`. The coordinator added the required quoted form; the next check accepted 1 obligation and 225 commitments before implementation publication. The final record is retained at `85e1d6ca:.planning/slice-plans/416-dashboard-product-intent-documentation/PLAN.md#story-obligations`.
  - Observed effect: one local planning-record repair and repeat check; no product rework or incorrectly published completion.
  - Inference: recurrence of the Reported-shape part of DD-369, not its Slice-column error. Use the supplied record shape at first write; the refusal successfully prevented accepting malformed evidence.

- Execution: SEED-190#keep-running-cursor-sessions / plan 418, first related implementation `0921f1f71ab86f870b8adf8d686cb7889256e900`
  - Timestamp: unknown (2026-10-30; coordinator source-review writes between source-only return ~15:23+08:00 and obligation re-check before resume ~15:25+08:00)
  - Tool: Cursor
  - Open Dough release: 0.3.78
  - Evidence: coordinator transcript `51bb7763-bed4-4bd1-a5fa-bf7e58d7132b` — first `source-review.md` Write placed commitment ids `8`/`9`/`10` in the Slice column for exclusions; rewrite placed obligation ids `G3`/`G4`/`G5` there (`| … | G3 | G3 |`); StrReplace rewrote those rows to `| … | slice 1 | G3 |` (and G4/G5) and quoted the matching Story obligations `Reported:` lines before `story-obligations.mjs` check accepted and increment `0921f1f7` published
  - Observed effect: local planning-record repair before acceptance; no product rework and no incorrect slice completion published
  - Inference: Slice-column recurrence of DD-369 (same class as the SEED-182 occurrence). Checking the consuming reader's Slice/`Reported` shapes before the first write would avoid the repair round

- Execution: SEED-206#explicit-reread-freshness / plan 431, first implementation `2010301f933b951b34e37c6538c957658a545080`
  - Timestamp: 2026-10-31T22:55:00+08:00 (approx.; source-review / obligation check before slice 1 delivery)
  - Tool: Cursor
  - Open Dough release: 0.3.79
  - Evidence: coordinator session for plan 431 — first `source-review.md` deferred rows used `| … | G1 | G1 |` (obligation id in Slice) and Story obligations `Reported: source review — …` without `slice N — "…"`; `story-obligations.mjs check --slice 1` returned `malformed-commitment` / `malformed-reported`; rewrite to empty Slice + obligation in Observation and `Reported: slice 1 — "…"` then check passed before `2010301f`.
  - Observed effect: one local planning-record repair before the first accepted increment; no product rework and no incorrect slice completion published
  - Inference: Slice-column and Reported-shape recurrence of DD-369. Exercise the consuming reader's shapes before the first write.

## DD-370 — New Markdown docs with trailing blank EOF fail staged whitespace

Post-change refactor extracted new maintainer timing Markdown files that ended
with an extra blank line. Selective format does not rewrite that Markdown
whitespace, so the first guarded fresh delivery failed at `git diff --check`
(`new blank line at EOF`) after the plan status mutation.

### Occurrences

- Execution: SEED-180#optimize-dashboard-touch-viewport-tests; plan 413; first related implementation `483f66b483a9046e0c790bc12bcc57489aa2a503`
  - Timestamp: 2026-10-30T14:11:00+08:00 (approx.; first slice-6 fresh delivery refused before accepted `2f800b3f`)
  - Tool: Cursor
  - Open Dough release: 0.3.76
  - Evidence: fresh `preparation-failed` / `operation: "staged whitespace"` naming `docs/maintainer/dashboard-installed-start-fixture-timings.md:83` and `docs/maintainer/dashboard-touch-family-timings.md:73`; repair stripped trailing blank EOF; retry published `2f800b3f`. Distinct from DD-363 (hard-break trailing spaces on source-review lines). Code renumbered from colliding DD-369 at trunk merge.
  - Observed effect: one refused preparation after status mutation; mechanical EOF fix and second guarded delivery succeeded
  - Inference: new Markdown created under the file-size split needs an EOF whitespace check before staging; format alone does not catch it

## DD-371 — Delivery typecheck first catches exactOptionalPropertyTypes after green proof

Focused Playwright proof and post-change refactor returned green, yet the
first slice-2 delivery/commit failed on TypeScript
`exactOptionalPropertyTypes` when an optional prop was passed as an explicit
`undefined` instead of omitted. A one-line conditional spread fixed it; retry
published. Local code was DD-370 on the story branch; renumbered to DD-371 at
trunk merge where DD-370 already named the Markdown EOF finding.

### Occurrences

- Execution: SEED-189#expand-dashboard-diff-context / plan 416 / first related implementation `5c73925b9dcdffd763c20f5b81c5d1aa45413757`
  - Timestamp: unknown (2026-10-30; after green slice-2 proof/refactor and before tip `c9ada8b1` 15:13:13+08:00)
  - Tool: Cursor
  - Open Dough release: 0.3.78
  - Evidence: coordinator transcript `1cd76bae-22c3-404c-b849-2df63d24fb85` L56–L58 — “Fixing the TypeScript exactOptionalPropertyTypes error that blocked the commit, then retrying delivery”; edited `dashboard/src/StoryReviewFileDiff.tsx` from `textProblem={…}` (could be `undefined`) to conditional `{...(cond ? { textProblem } : {})}`; republished as `c9ada8b1`. Distinct from ODF-329 (ESLint/formatter under a lint-forbidden brief).
  - Observed effect: one failed delivery attempt and one coordinator type fix before successful publish; no product behavior change beyond satisfying the typecheck gate.
  - Inference: qualified one-off that delivery/commit typecheck was the first gate for this optional-prop shape after green journey proof. Implementer/refactor briefs that forbid independent lint/typecheck leave that class of defect to the delivery hook; no claim that a earlier read-only `tsc` would have been cheaper than the observed retry.

## DD-372 — First-pass helper-gone proof used address drift instead of a deleted wire helper

A Behavior return claimed same-build survival after “helper gone” while focused
proofs only drifted the recorded `spawnHelper` path and left the answering
runner’s wire helper file on disk; copy-from-install onto a missing wire path
and an explicit stop-one-of-several were self-reported gaps. Source-only review
returned those obligations and a second implementation pass added wire-delete /
production-retirement fixtures and stop-several proof before delivery. Local
code was DD-371 on the story branch; renumbered to DD-372 at trunk merge where
DD-371 already named the typecheck finding.

### Occurrences

- Execution: SEED-190#keep-running-cursor-sessions / plan 418, first related implementation `0921f1f71ab86f870b8adf8d686cb7889256e900`
  - Timestamp: unknown (2026-10-30; first implementer return before source-only review ~15:23+08:00; G1/G2 resume from ~15:25+08:00)
  - Tool: Cursor
  - Open Dough release: 0.3.78
  - Evidence: implementer subagent `601f21c0-cc39-46fd-a4b7-263994c68126` first return Gaps (“Copy-from-install onto a missing wire helper path has no separate focused assertion (address-drift repair is what the specs hit)”; stop-one-session not freshly asserted); coordinator source-review/`PLAN.md` obligations G1/G2; resume closed wire-delete via `OPEN_DOUGH_CURSOR_SPAWN_HELPER_PROOF` and stop-several before publish `0921f1f7`. Distinct from ODF-314 (omitted named plan proof rows that then exposed a product defect) and ODF-187 (plan-prescribed nondiscriminating observation): here the story/plan helper-gone condition was substituted by a weaker fixture that still exercised repair.
  - Observed effect: one extra implementation round before acceptance; wire-delete and stop-several entered focused proof; no escaped product defect
  - Inference: qualified. Source-review comparison to the story’s deleted-checkout example was the decisive catch; preferring the production retirement fixture (delete the wire helper the runner still reports) on the first pass would avoid the resume. No measured token or duration saving claimed.

## DD-373 — Bounded failed-job tails omit earlier failing test identities

The CI diagnostic retains a bounded tail around GitHub error markers. When a
job reports several failed tests before its final process-exit marker, that
tail can expose only the last failure despite other tests already failing in
the same attempt. A complete failure-name summary is needed before selecting
the repair scope; long raw logs need not enter coordinator context.

### Occurrences

- Execution: SEED-200#session-terminal-voice-input; first implementation `e352b41c20dc7dfb9655353a2a15cc5b967939f1`
  - Timestamp: unknown (2026-10-31 CI repair, run 41166733510 attempt 1)
  - Tool: Codex
  - Open Dough release: unknown
  - Evidence: installed `ci-github-diagnostic.mjs::failedLogExcerpt` keeps at most80 lines and favors the latest error tail. Short diagnostics for jobs124435809061 and124435809098 omitted actual failures in `boundary/agent-terminal-codex.spec.ts` and `cursor-session-recovery.spec.ts`; a subsequent full seven-job `FAIL:` inventory recovered thirteen failed tests before repair publication. Inventory and disposition are retained in `6c2d87444ac11423c250b5a301452edd0c561b77:.planning/slice-plans/426-session-terminal-voice-input/ci-repair-evidence.md`.
  - Observed effect: initial bounded repair selection covered four stale-date specs; reading complete failure identities added two already-failing specs and one additional focused selection. No failure was silently accepted and the combined repair was published once.
  - Inference: tool-output completeness issue, distinct from ODF-221's repair leaving a known same-cause sibling until a later run. Consider returning every failed test identity alongside bounded diagnostic excerpts; token/time savings are unmeasured.

## DD-374 — Delegation brief softened the project's failing-test policy to "fix or report"

The coordinator's implementation brief told the agent that a locally failing or
flaky test was "a defect to fix or report". This project's policy is to fix
such tests so local and CI results match, even when the failure predates the
change. The agent reported an intermittent regression-suite failure that was
already on trunk and left it unfixed, so the coordinator had to send it back
for a second round.

### Occurrences

- Execution: SEED-192#open-development-intent-frame; first implementation `9913a6d40006e3de9980ab8d97e0e2f3197b5f0d`
  - Timestamp: 2026-10-31 (Asia/Singapore; exact time unknown)
  - Tool: Claude Code
  - Model: claude-opus-5-5
  - Open Dough release: 0.3.79
  - Evidence: slice 1 implementation return listed `sessions-sidebar-navigation-cases.spec.ts` "a story on no card…" as failing 1 in 4 on clean `22eb4b3e` and "did not fix it". A coordinator follow-up then found the cause (a reveal-count test race with keep-in-view after a Side panel press) and fixed it (`revealsAtClick`, 8 of 8 passing repeated); see `72ce39b109d5352b43dd093c68b9257b564a1bdc:.planning/slice-plans/424-development-intent-frame/PLAN.md` Current decisions.
  - Observed effect: one extra delegation round (about 5 minutes, 9 tool uses). The fix landed in the same increment.
  - Inference: the coordinator's wording, not the shared guidance, caused this; delegation already says a discovered failure keeps the project's failure policy. Pass the project's policy verbatim instead of paraphrasing it.

## DD-375 — A deletion-only story amendment mid-execution forced a full source re-review and re-allocation

When trunk amends the selected story during execution, the accept-proof rule
requires a fresh source-only review, replacing `source-review.md` and
re-allocating every id. An amendment that only deletes an exclusion sentence,
pointing at a sibling story that was dropped, changes no promise. The fresh
reviewer still numbers the commitments differently, so every row and every
earlier observation has to be remapped by hand.

### Occurrences

- Execution: SEED-202#bounded-dashboard-refresh; first related implementation `bd5a9094e88fb9d0ca30c0539a4c306d768bf342`
  - Timestamp: 2026-10-31T17:56:08+08:00 (trunk amendment `82a35ccf`, found at slice 2's source-freshness check)
  - Tool: Claude Code
  - Model: claude-opus-5-5
  - Open Dough release: 0.3.79 (installed guidance in the execution checkout)
  - Evidence: `source-freshness.mjs check` returned `amended` for the story. The change removed two lines of its Deferred promises (the sibling-story deferral). The second reviewer's ids differed from the first's (89 → 87 rows; for example `1.10.1`→`1.9`, `4.4.1`+`4.4.3`→`4.6`, `R5`→`X6`). Replacement record: `.planning/slice-plans/426-bounded-dashboard-refresh/source-review.md` at `218b8d92`.
  - Observed effect: one extra reviewer run (about 43k subagent tokens), a hand-written id remap carrying slice 1–2 observations, and one failed remap attempt, all before slice 2 could be delivered. No commitment changed.
  - Inference: for an amendment that only removes or narrows an exclusion, keeping the existing review and settling the affected row would avoid the remap. Asking reviewers for stable ids would also reduce it. Neither is measured.

## DD-377 — CI layout repair iterates successive assertions without one full-journey check

A CI repair for a banner-related dialog layout fixes the reported assertion
(Close overlap, then content viewport ratio, then End scroll) without verifying
the whole owned high-zoom journey in that pass, so the same dialog fails again
on the next assertion and needs another repair.

Distinct from ODF-221 (sibling specs sharing a race) and from ODF-150 (initial
focused proof missing consumers): here the miss is inside cause-driven repair
of one product surface across successive owned CI failures.

### Occurrences

- Execution: SEED-205#logo-sidebar-toggle / plan 430 / first related implementation `63c7699e57ce9ec57112e30434df07e944d3eaea`
  - Timestamp: 2026-10-31T23:25:54+08:00 (first prep-legend repair `d470063c`)
  - Tool: Cursor
  - Open Dough release: 0.3.79
  - Evidence: after mark-as-Sessions banner change, owned CI failed `preparation-legend.spec.ts` three times in sequence — run 41213869876 (dialog not visible / Close over banner at 200% zoom) → `d470063c` pinned under `--banner-height`; run 41214826618 (explanation viewport ratio ~0.99 at 400% zoom) → `5f9ca93c` dropped vertical centering and flexed content; run 41216028080 (End leaves explanation ~0.93) → `d62f0a66` used near-full height and lighter bottom padding. Coordinator transcript `1bca2eeb-150d-41d1-ab95-a929db66954e` L67–L85; repair agents `b74c60f9`, `68aa0863`, `400716f4`.
  - Observed effect: three owned CI repair commits and three repair agents on the same `preparation-legend.css` before Close-off-banner and End-to-last-line both held together.
  - Inference: each repair matched the failing assertion rather than replaying the full zoomed prep-legend journey (open, Close clear of banner controls, scroll End shows last explanation) once; that single check would likely have collapsed the loop.

## DD-378 — Planning treats pre-existing failures as exclusions from completion

An execution-ready plan turned correct regression attribution into an instruction to report and leave known failing tests. That instruction propagated into repair briefs and an unfinished completion stop, conflicting with Terry's established Open Dough failing-test policy; later resume repaired the failures.

### Occurrences

- Execution: SEED-199#mobile-session-screen; first implementation eaa0237881d704ee46711d8bc4fb188401b6ec94
  - Timestamp: unknown (2026-10-31; initial stop preceded the 14:01 +08 follow-up)
  - Tool: Cursor
  - Open Dough release: unknown
  - Evidence: f601fcbd:.planning/slice-plans/425-mobile-session-screen/PLAN.md, Decisive premises 3, says the retirement failures are not owned and should be reported. Coordinator transcript 363e0b94-67d5-49d4-b77d-48deec743aed L48 and L114 carry that exclusion; L126 reverses it and repairs registered revisions. Detailed CI/story analysis: docs/maintainer/ci-retrospective-2026-11-01.md.
  - Observed effect: execution stopped unfinished and requested a fix-or-waive decision for known failures; repeated resume and fixture repairs were needed before green integration. This is distinct from DD-374's softened implementation brief: the exclusion originated in the prepared plan. Another active repair owner's files still require preservation; pre-existing origin alone is not that ownership evidence.
