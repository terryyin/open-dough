import pathlib,json,re,csv,collections
p=pathlib.Path('/tmp/open-dough-ci-retro-20261101');es=json.loads((p/'failure-inventory.json').read_text());cases=[]
for e in es:
 raw=re.sub(r'\x1b\[[0-9;]*m','',(p/f"log-{e['jobId']}.txt").read_text());ll=[re.sub(r'^\d{4}-\d\d-\d\dT\S+\s','',l) for l in raw.splitlines()]
 starts=[n for n,l in enumerate(ll) if l.startswith('FAIL:')]
 for i,n in enumerate(starts):
  end=starts[i+1] if i+1<len(starts) else next((k for k in range(n+1,len(ll)) if ll[k].startswith(('Kept:','##[error]'))),len(ll))
  block=ll[n:end];focus=[l.strip() for l in block[1:] if re.search(r'Error:|Expected:|Received:|unexpected value|Expected pattern|Expected substring|Received string|Infrastructure setup:',l)]
  cases.append({**{k:e[k] for k in ['run','attempt','job','jobId','sha','branch','url']},'logLine':n+1,'test':block[0],'signals':focus[:10],'block':'\n'.join(block)})
(p/'failure-cases.json').write_text(json.dumps(cases,indent=2))
with (p/'failure-cases.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=['run','attempt','job','jobId','sha','branch','url','logLine','test','signals']);w.writeheader();w.writerows({k:v for k,v in c.items() if k!='block'} for c in cases)
print('cases',len(cases),'distinct identities',len(set(c['test'] for c in cases)))
for run in [3311,3314,3316,3324,3333,3334,3345,3346,3352,3355,3357,3359,3362,3369,3377,3385,3387,3388,3389,3392,3394,3395,3401,3402]:
 cc=[c for c in cases if c['run']==run];seen=set()
 print('\nRUN',run)
 for c in cc:
  file=c['test'].split(' › ')[0]
  if file in seen:continue
  seen.add(file)
  if run in [3311,3314,3324,3355,3385] and len(seen)>4:continue
  print(file, '; '.join(c['signals'])[:550])
