# Slice 4 native workflow comparison

Status: incomplete. G3 and G6 remain pending. No matched comparison or observed
improvement is claimed. This assessment records the prospective protocol and
failed setup honestly while the coordinator selects further paid work.

## Prospective decision and authority

Origin: SEED-324's consumer waiting on a known paused supplier, reconstructed as
one neutral invoice task in a disposable Node/Git project. The reusable example
is `Distribution/tests/blocked-execution-workflow-native.mjs`; its project,
invoice journey, accounting, history, observation and ownership helpers keep
this one case runnable.
The earlier `blocked-execution-native.mjs` remains a distinct command-level proof.

Use complete managed payloads installed by each revision's real `install.sh`:

- Baseline `91f32d39061d16793a190c5d9d9f2a6b26534fc7`.
- Candidate `0bc39b172c9a99bf8b627c0a1d527e3c8983ee61`.

The managed source diff contains only this feature's declaration, shared skill /
delegation / overdue guidance, blocked runtime and shared native connection.
Tests are not installed. Both pins include the same Distribution layout and
upstream changes. No later guidance edit silently substitutes the candidate pin.
The no-model full-installer smoke verified all installed bytes against the
actual declaration: 365 baseline files, 376 candidate files.

The assignment explicitly invokes the installed `$dough-execute-plan --one-shot`
from an established one-shot start, preserving the original partial work and
accepted proof. It requests subtotal, taxRate, taxAmount, total, currency and
supplierEvidence. Both arms receive the same task, fixture, exact host-provided
native coordinates, proof requirements and prohibition on commit/publication,
supplier/verifier edits, model changes, capacity purchases or scope expansion.
The fixture supplies no report, retained hold or automatic invoice continuation.

The common first judgment is an actual native `check-supplier.mjs` false result,
including checks from verified descendants. Producer events are unchanged paused
evidence, ready/unchecked evidence, ready/checked evidence, and repeated qualifying
meaning. Negative gates inspect actual handler fingerprints or native check
output; an ended baseline is a truthful unavailable-handler boundary. If the
baseline stays active without observing an event or ending within its cap, stop
the comparison rather than change its task or invent polling. Candidate delivery
must wait for the original native turn to finish before one same-thread resume.

After qualifying evidence, only an ended baseline lacking a report may receive
one neutral manual evidence notification. Count it as one baseline rescue;
candidate receives none. Assess report 125 SGD, rate .08, tax 10, total 135 and
supplier provenance R8, preserved work/verifier/authority hashes, same revision
and native settings, actual local proof, and unchanged publication/CI decisions.
A baseline with zero idle requests leaves C65 unmet on a tie. Outcome or recovery
improvement cannot substitute for that separate commitment or establish C68.

One separate candidate attention case removes the real signal after workflow
enrollment, observes a completed same-thread actionable attention turn, restores
the source, executes the exact retained owner recovery argv, and qualifies the
same work. Count that deliberate recovery command separately from the pair's
rescue result. It proves neither recovery after host exit nor a real quota reset.

## Native environment, caps and ownership

Actual local CLI and daemon: 0.169.0. Native start confirmed gpt-6.1-sol, xhigh,
approval never, dangerFullAccess, service tier default. No settings override.
The current generated native schema confirms `collabAgentToolCall` with
`tool: spawnAgent`, `senderThreadId` and `receiverThreadIds`; exact descendants,
not newest threads or copied ancestor usage, belong to aggregate accounting.

Initial admission at 13:38 Singapore on 2026-11-14: AC 100%, no Sleep/Wake log
entries from the maintained query, natural load 14.08 / 11.95 / 10.91, about
3.4 GB free plus 13.8 GB inactive memory. The coordinator reported no competing
owned proof. Each long command uses `caffeinate -s -i`; this is not admission
for later attempts without reconsidering actual conditions.

Initial bounds were 20 minutes / 1.5 million total / 25,000 output per arm,
with 10 minutes / 600,000 total / 12,000 output for the separate attention case.
After the failed startup and independent repairs, root authorized one matched
retry with the same 20-minute / 25,000-output limits and a common 2-million-total
guard. The 13-response startup cost shows the original total guard may censor
an otherwise complete workflow; no completed comparative outcome informed this
pre-run adjustment. Prior failed spend remains separate. G6 release is pending.
Stop on the first cap, refusal or invalid comparison; no automatic paid retry.
Counters are observed
after responses, so an in-flight response can cross a ceiling before stopping.

Count native `token_usage_record.payload.usage` once per exact owning thread
and response ID. Do not sum cumulative token_count, CLI turn totals or duplicated
app-server token snapshots. Missing counters stay unknown; observed partial sums
are lower bounds. Whole execution/coordinator/implementation-agent usage remains
unknown and native-only totals do not substitute for total implementation cost.
Slice 2 already records roughly an hour of work including two failed three-minute
checks; Slice 3 has qualitative effort only. This slice adds example, evaluation
and startup-race maintenance cost, with no benefit established yet.

Follow [the failing/flaky-test policy](../../../AGENTS.md#failing-and-flaky-tests)
as written. Root owns Git publication, PLAN/source-review and the existing CI
observer; this evaluator does not touch them.

## Failed native setup and paid observation

Literal first launch, terminal session 46123:

`PATH=/opt/homebrew/bin:$PATH caffeinate -s -i node Distribution/tests/blocked-execution-workflow-native.mjs --native baseline /tmp/seed345-workflow-baseline-20261114-1338 91f32d39061d16793a190c5d9d9f2a6b26534fc7`

Thread `01a1d891-25f9-7ba1-b35f-303bfdeac43f`: an empty-thread full history read
refused `list_turns is not supported yet` before initial input/turn submission.
No per-response usage is recorded; counters remain unknown. A second pre-turn
setup, session 20837, directory suffix `-b`, thread
`01a1d893-28ff-7e20-a09b-e6ba75dd96c1`, failed watching the future rollout path
before the file existed. Its initial input/turn were likewise never submitted.
Both daemon threads and setup records remain untouched.

Authorized first paid observation, terminal session 26065, same command with
results directory `/tmp/seed345-workflow-baseline-20261114-1338-c`, created thread
`01a1d894-24af-7281-918c-0e0ca1ad1fc3`. The runner inspected history immediately
after accepted turn/start, before session metadata had persisted, and stopped on
the empty-rollout error. Its cleanup wrongly depended on that unavailable history.
The native writer continued after observation detached. The evaluator discovered
this promptly in the exact rollout and recovered its ownership through native
history, interrupting turn `01a1d894-27c8-7330-8ac7-9b6c8f951e5b` and observing
its actual interrupted terminal event. No descendant was spawned.

`post-error-owner-recovery.json` and `post-error-native-events.jsonl` under that
directory retain exact history, interruption, terminal observation and usage.
Direct own-response cost: **13 requests, 553,984 input tokens (502,400 cached),
1,399 output tokens, 555,383 total tokens**, including 223 reasoning output.
This is failed evaluation cost, not a matched baseline. Initial reports of a
pre-turn refusal were corrected after the actual rollout proved acceptance.

The 13 responses read the actual skill, established-start, execution-location,
one-shot, native context, accepted proof and project; ran exactly one supplier
check, which returned false with initial paused fingerprint `141ec966…`; then
read completion/delegation/supplier guidance and searched for supported hold /
continuation facilities. There were 18 read-only command executions, no partial
or verifier edits, report, hold enrollment, claim, commit or publication. The
first-check milestone occurred, but the dead producer applied no supplier events.
No recurring supplier checks were observed. This interrupted run proves no
comparative result, native attention or zero-rescue outcome.

## Nonpaid correction and proof

The example now persists every accepted native turn identity immediately before
follow-up reads. Exact ownership survives unavailable history. Full history reads
wait for a complete, matching session_meta record at that exact native path;
missing/partial startup records defer observation without arbitrary delays.
Future rollout paths use their existing parent directory until the file appears.
Only the known empty-history refusal is deferred; unrelated host errors stop.
Cleanup interrupts every verified known active turn directly and waits for its
actual terminal event, without depending on a full history read first.

Proof: `PATH=/opt/homebrew/bin:$PATH node --test Distribution/tests/blocked-execution-workflow-native.test.mjs`
passed two cases. The accounting counterexample observes exact own-response
deduplication, ancestor exclusion, cumulative-snapshot exclusion, unknown missing
usage, partial trailing records and failure on malformed completed records.
The controlled startup regression observes an actual future-file event, incomplete
then complete matching metadata, no early native history request, persisted accepted
identity, direct exact-turn interruption while history is unavailable, actual
terminal notification, and a later successful history read. It uses no model work,
sleep or timeout override. Syntax checks pass for the entry and helpers.

### Independent-review assessor repairs

The fresh structural pass retained both preservation milestones through one
`assertPreservedInvoiceWork` project helper. Its separate behavior findings were
repaired without native calls; [the review](slice4-refactor.md) retains their
original attribution and [consumer trace](slice4-consumer-trace.md) dispositions.

Before correction, the controlled suite passed its two original cases
and failed three new cases: parent-only accounting reported true instead of false;
an actual terminal notification followed by RPC refusal aborted remaining cleanup;
and disconnect left accepted-interrupt completion pending. A separately selected
admission-order case failed undefined instead of completed for an already-retained
child terminal event. Literal red command:
`PATH=/opt/homebrew/bin:$PATH node --test Distribution/tests/blocked-execution-workflow-native.test.mjs`.
Admission red selected `--test-name-pattern='child admission'` on that same file.

All six now pass. The aggregate case observes requests unknown with an admitted
child lacking a path, still unknown with a path but no usage, then complete only
after the exact child's own log supplies usage. The refusal case keeps the exact
terminal event and interrupts the next known child. The disconnect case observes
settled unconfirmed cleanup, unchanged nonterminal identities, no second interrupt
on a dead route, and persisted remaining identities plus exact-history recovery.
The admission case replays prior matching start/completed events, excludes an
unrelated thread, and keeps an admitted child with no turn evidence explicitly
unknown even after all known turns are confirmed terminal. No refusal, disconnect
or missing record is itself terminal evidence.

Maintained focused green command:
`PATH=/opt/homebrew/bin:$PATH OPEN_DOUGH_TEST_JOBS=1 npm test -- Distribution/tests/blocked-execution-workflow-native.test.mjs`.
Direct six-case `node --test` and changed helper/entry syntax checks also pass.
The tests use controlled notifications, promises and an event-loop checkpoint,
without wall-clock sleeps or timeout overrides. No new native observation ran.

The failed paid baseline used 555,383 tokens before producer events or a final
outcome. That cost cannot predict a complete arm reliably; the existing 1.5-million
arm ceiling may still stop a valid workflow. No cap increase is inferred here.
Root decides whether to release one additional matched pair and snapshots the
evaluator source closure first. G6 cost/shape waits for actual primary-arm cost.
Fresh-session persistence, actual descendant delivery/terminal observation,
complete workflow, comparative outcome and attention remain native premises.

The final owned-tree counterexample then failed before correction: a retained
child spawn before its own admission left `grandchild` absent (undefined rather
than child). Admission now recursively replays exact retained spawn events only
when both the notification thread and native sender identify the verified parent.
Repeated admission is idempotent and cannot reparent ownership. The same guard
applies to live spawn notifications. The seventh controlled case preserves the
grandchild's earlier active turn, exposes its missing usage, excludes foreign /
copied-ancestor spawn evidence, and interrupts that exact turn once without history.
Direct and maintained focused suites now pass seven cases; observation syntax
passes. No native call, model spend, candidate substitution or cap change occurred.

### Formatted example reorganization

Root formatting exposed 349-line entry, 450-line test and 394-line observation
files; prior raw-size checks were insufficient. The independent refactor moved
invoice event/attention sequencing, response accounting and exact native history
into focused invoice helpers, unified live/replayed event interpretation, and
placed the same seven unchanged test bodies in three purposeful files. Both
preservation milestones and independent final-history/report/settings/proof
judgments remain. [The refactor record](slice4-refactor.md) gives raw/formatted
counts and [consumer dispositions](slice4-consumer-trace.md).

Renewed proof passed:
`PATH=/opt/homebrew/bin:$PATH OPEN_DOUGH_TEST_JOBS=1 npm test -- Distribution/tests/blocked-execution-workflow-native.test.mjs Distribution/tests/blocked-execution-invoice-accounting.test.mjs Distribution/tests/blocked-execution-invoice-admission.test.mjs`.
Changed source syntax passed. This preserves deterministic promises and adds no
actual native outcome; G3/G6/comparison and attention remain with the paused native
implementer after root release. The failed baseline's 13 requests/555,383 tokens
remain evaluation cost. No new model spend or cap/pin change occurred.

## Shared behavior review

Codex invocation requires authorized blocked work with no running verification;
the current project supplies exact condition, owner, proof, authority and native
handle. A qualifying checked supplier event invites the retained consumer's
judgment; attention preserves uncertainty and recovery. Native complete-workflow
and attention outcome observations remain pending here.

Cursor and Claude use the same retained-state rule with explicit manual recovery,
not an invented automatic binding. A small post-pin prose clarification now names
usable `host: cursor` / `host: claude` input and omission of unavailable handles.
The existing store validation and usage fallback tests already exercise this
runtime contract. The clarification changes no Codex path or pinned comparison.
The examples require the executing project's own context and name a missing signal
usefully. Claude open-session waiting and optional reset fields remain documented
possibilities, not an observed current reset. No new Cursor/Claude adapter, real
quota induction, session-exit recovery or per-host native gate is claimed.
