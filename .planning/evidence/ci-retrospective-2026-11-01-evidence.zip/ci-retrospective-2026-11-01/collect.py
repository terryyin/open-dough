import concurrent.futures,json,pathlib,subprocess
p=pathlib.Path('/tmp/open-dough-ci-retro-20261101');runs=json.loads((p/'runs.json').read_text())
def fetch(r):
 f=p/f"jobs-{r['id']}.json"
 if not f.exists():
  z=subprocess.run(['gh','api','--paginate',f"repos/terryyin/open-dough/actions/runs/{r['id']}/jobs?filter=all&per_page=100"],capture_output=True,text=True)
  if z.returncode:return (r['run_number'],z.stderr)
  f.write_text(z.stdout)
 return (r['run_number'],'ok')
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 results=list(pool.map(fetch,runs))
print('job inventories',len(results),'errors',[r for r in results if r[1]!='ok'])
jobs=[]
for r in runs:
 raw=(p/f"jobs-{r['id']}.json").read_text();dec=json.JSONDecoder()
 while raw.strip():
  o,n=dec.raw_decode(raw.lstrip());raw=raw.lstrip()[n:]
  for j in o['jobs']:j['run_number']=r['run_number'];j['run_sha']=r['head_sha'];j['run_branch']=r['head_branch'];jobs.append(j)
(p/'jobs-all.json').write_text(json.dumps(jobs,indent=2))
failed=[j for j in jobs if j['conclusion'] not in ('success','skipped',None)]
def log(j):
 f=p/f"log-{j['id']}.txt"
 if not f.exists():
  z=subprocess.run(['gh','api',f"repos/terryyin/open-dough/actions/jobs/{j['id']}/logs"],capture_output=True)
  if z.returncode:return (j['id'],z.stderr.decode(errors='replace'))
  f.write_bytes(z.stdout)
 return (j['id'],'ok')
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool: results=list(pool.map(log,failed))
print('jobs',len(jobs),'non-success',len(failed),'log errors',[r for r in results if r[1]!='ok'])
