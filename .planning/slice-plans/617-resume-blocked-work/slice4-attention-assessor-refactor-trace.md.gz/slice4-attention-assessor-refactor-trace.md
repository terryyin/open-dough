# Consumer trace

## Effect terms searched

| Term | Origin |
| --- | --- |
| `Distribution/tests/blocked-execution-invoice-attention.test.mjs` | changed path |
| `blocked-execution-invoice-attention.test.mjs` | basename of `Distribution/tests/blocked-execution-invoice-attention.test.mjs` |
| `Distribution/tests/support/blocked-execution-invoice-history.mjs` | changed path |
| `blocked-execution-invoice-history.mjs` | basename of `Distribution/tests/support/blocked-execution-invoice-history.mjs` |
| `Distribution/tests/support/blocked-execution-invoice-journey.mjs` | changed path |
| `blocked-execution-invoice-journey.mjs` | basename of `Distribution/tests/support/blocked-execution-invoice-journey.mjs` |
| `completedInvoiceAttention` | supplied |
| `observedAttention` | supplied |
| `attention-delivered` | supplied |

## Scope

Whole checkout at `fcb358a645bd`, including uncommitted and untracked files: 6492 tracked and untracked non-ignored files searched with fixed-string, case-insensitive matching.

Changed files not searched: `Distribution/tests/blocked-execution-invoice-attention.test.mjs`, `Distribution/tests/support/blocked-execution-invoice-history.mjs`, `Distribution/tests/support/blocked-execution-invoice-journey.mjs`.

## Located consumers

Kinds are path hints for inspection; each file appears once. Fill every Disposition with `run`, `reused` or `excluded: <reason the effect does not reach its boundary>`.

### Production

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `.planning/slice-plans/617-resume-blocked-work/slice4-after-yield-baseline/record.json` | `Distribution/tests/support/blocked-execution-invoice-history.mjs`, `blocked-execution-invoice-history.mjs`, `Distribution/tests/support/blocked-execution-invoice-journey.mjs`, `blocked-execution-invoice-journey.mjs` | 158: `"Distribution/tests/support/blocked-execution-invoice-history.mjs": "bd4ddcc8866d225b00a9c6a316112e3e3856b272971d1af98185d32b8d4193ec",` | excluded: immutable historical evaluator hash index, not executable |
| `Distribution/src/skills/dough-execute-plan/scripts/blocked-execution-delivery.mjs` | `attention-delivered` | 33: `? "attention-delivered"` | excluded: runtime phase writer does not consume the invoice assessor; runtime unchanged |
| `Distribution/src/skills/dough-execute-plan/scripts/blocked-execution.mjs` | `attention-delivered` | 84: `!["continued", "attention-delivered"].includes(previous.phase) &&` | excluded: runtime recovery/rearm rules do not consume the invoice assessor; runtime unchanged |

### Test

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `Distribution/src/skills/dough-execute-plan/scripts/blocked-execution-attention.test.mjs` | `attention-delivered` | 49: `(state) => state.phase === "attention-delivered" && state.worker.ended,` | reused: accepted Slice3 runtime attention proof; no imported assessor or changed runtime |
| `Distribution/src/skills/dough-execute-plan/scripts/blocked-execution-loss.test.mjs` | `attention-delivered` | 70: `(state) => state.phase === "attention-delivered" && state.worker.ended,` | reused: accepted Slice3 loss/recovery proof; no imported assessor or changed runtime |
| `Distribution/src/skills/dough-execute-plan/scripts/blocked-execution-usage.test.mjs` | `attention-delivered` | 90: `(state) => state.phase === "attention-delivered" && state.worker.ended,` | reused: accepted Slice3 usage proof; no imported assessor or changed runtime |
| `Distribution/tests/blocked-execution-invoice-session.test.mjs` | `blocked-execution-invoice-history.mjs` | 13: `import { retainFinalInvoiceSessions } from "./support/blocked-execution-invoice-history.mjs";` | reused: accepted eleven-case wrapper; final saved-session reader behavior unchanged |
| `Distribution/tests/blocked-execution-workflow-native.mjs` | `blocked-execution-invoice-history.mjs`, `blocked-execution-invoice-journey.mjs` | 13: `import { runInvoiceJourney } from "./support/blocked-execution-invoice-journey.mjs";` | reused: caller setup, proof and settings guards unchanged; corrected attention boundary has controlled and saved-real-history proof; remaining qualification is root-owned native observation |

### Test support or stand-in

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `Distribution/tests/support/blocked-execution-workflow-observation.mjs` | `blocked-execution-invoice-history.mjs` | 6: `import { readInvoiceHistory } from "./blocked-execution-invoice-history.mjs";` | reused: exact history/event ownership and startup behavior unchanged; accepted eleven-case proof applies |

### Journey or feature

none found

### Guidance reader

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `.planning/slice-plans/617-resume-blocked-work/slice3-assessment.md` | `attention-delivered` | 132: `node .agents/skills/dough-execute-plan/scripts/consumer-trace.mjs --checkout /Users/terryyin/git/open-dough/.worktrees/resume-blocked-work-when-it-can-advance …` | excluded: nonexecuting historical runtime proof record |
| `.planning/slice-plans/617-resume-blocked-work/slice4-consumer-trace.md` | `Distribution/tests/support/blocked-execution-invoice-history.mjs`, `blocked-execution-invoice-history.mjs`, `Distribution/tests/support/blocked-execution-invoice-journey.mjs`, `blocked-execution-invoice-journey.mjs` | 15: `--path Distribution/tests/support/blocked-execution-invoice-history.mjs \` | excluded: nonexecuting proof/consumer record |
| `.planning/slice-plans/617-resume-blocked-work/slice4-native-acceptance.md` | `completedInvoiceAttention`, `attention-delivered` | 74: `The frozen assay waited for attention-delivered/currentaccepted instead of this` | excluded: nonexecuting actual native evidence and remaining-proof record |
| `Distribution/src/skills/dough-execute-plan/references/blocked-execution.md` | `attention-delivered` | 90: `` `attention-delivered` records completion of an attention turn, without claiming `` | excluded: product guidance is unchanged by the invoice assessor correction |

## Direct changed-consumer review and proof effect

`completedInvoiceAttention` is one native-history observation seam. It selects
current/latest archived purpose=attention acceptance, matches the exact admitted
thread and native turn, requires normal completion evidence, rejects failed or
interrupted evidence, and preserves the current record/recovery. The journey
consumes `observedAttention` rather than inventing current accepted status.
No runtime rule, assignment, payload, native setting or protected proof changed.

The regression at `blocked-execution-invoice-attention.test.mjs:6` now explicitly
uses current `accepted:null`/`pending:null`, matching the actual rearm record;
its success assertions retain archived generation/turn identity, null current
acceptance, original recovery and read-only observation. Foreign/wrong/failed
events, wrong purpose and live worker reject; normal current receipt and exact
saved-history completion pass. This test-fixture fidelity edit is the only
independent refactor edit, and invalidates only that case's earlier setup proof.

Replacement proof: `PATH=/opt/homebrew/bin:$PATH OPEN_DOUGH_TEST_JOBS=1 npm test -- Distribution/tests/blocked-execution-invoice-attention.test.mjs`, exit0.
Other ten accepted cases and saved native initial/attention facts are reused.
No full suite, native call or model request ran during this review. Formatting
preview only (no mutation) gives history177, journey180, test130 lines; root
owns formatting. Workspace/index whitespace checks pass. No rename, extraction,
split or deletion was introduced. No uncovered structural consumer remains.
Native qualification/recovery/final completion remain explicitly unobserved and
root-owned; any further paid action needs its separately selected prospective
bound, not a repeat of the frozen assay.
