# Consumer trace

## Effect terms searched

| Term | Origin |
| --- | --- |
| `Distribution/tests/native-comparison/paused-supplier/case.bash` | changed path |
| `case.bash` | basename of `Distribution/tests/native-comparison/paused-supplier/case.bash` |
| `Distribution/tests/native-comparison/paused-supplier/owned-proof.mjs` | changed path |
| `owned-proof.mjs` | basename of `Distribution/tests/native-comparison/paused-supplier/owned-proof.mjs` |
| `Distribution/tests/support/native-codex-owned-proof.test.mjs` | changed path |
| `native-codex-owned-proof.test.mjs` | basename of `Distribution/tests/support/native-codex-owned-proof.test.mjs` |
| `case_agent_proof` | supplied |
| `ownedWorkerProof` | supplied |
| `turn-4-agent-proof` | supplied |

## Scope

Whole checkout at `2517383f7226`, including uncommitted and untracked files: 6506 tracked and untracked non-ignored files searched with fixed-string, case-insensitive matching.

Changed files not searched: `Distribution/tests/native-comparison/paused-supplier/case.bash`, `Distribution/tests/native-comparison/paused-supplier/owned-proof.mjs`, `Distribution/tests/support/native-codex-owned-proof.test.mjs`.

## Located consumers

Kinds are path hints for inspection; each file appears once. Fill every Disposition with `run`, `reused` or `excluded: <reason the effect does not reach its boundary>`.

### Production

none found

### Test

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `Distribution/tests/native-comparison-doughnut-title-precedence.sh` | `case.bash` | 15: `source "${case_path}/case.bash"` | excluded: different case; generic basename match, no paused-supplier proof caller |
| `Distribution/tests/native-comparison-incomplete.sh` | `Distribution/tests/native-comparison/paused-supplier/case.bash`, `case.bash` | 160: `'  return 1' '}' >> "${work}/source/Distribution/tests/native-comparison/paused-supplier/case.bash"` | run: focused incomplete family passed; unchanged shared refusal/retention paths, new owned-proof behavior covered directly by Node counterexamples |
| `Distribution/tests/native-comparison-paused-supplier.sh` | `turn-4-agent-proof` | 120: `unproved-continuation proof turn-4-agent-proof: none \| lacks slice 3's passing proof` | run: full credential-free paused-supplier journey and all rejected cases passed against the changed case |
| `Distribution/tests/native-comparison.md` | `case.bash` | 14: `` fixture and observer `case.bash`, and the separate assessor `assess.bash`, `` | excluded: descriptive case contract; no executable consumer or changed public runner interface |
| `Distribution/tests/native-comparison/doughnut-title-precedence/assess.bash` | `case.bash` | 4: `# and thread, and case.bash's fields from the recorded test runs and the final` | excluded: separate case assessor, no changed proof-observation call |
| `Distribution/tests/native-comparison/doughnut-title-precedence/case.md` | `case.bash` | 74: `` `case.bash` fetches the revision into the arm's `workspace`, a fresh `` | excluded: separate case documentation |
| `Distribution/tests/native-comparison/doughnut-title-precedence/comparisons/20261114T045440-26b0.txt` | `case.bash` | 16: `case-input-hash: d19754c834249cda4677bf3f2a2b3daff87fce3157d13e8d7d7177b5766ab8f9 tests/native-comparison/doughnut-title-precedence/case.bash` | excluded: immutable historical record for another case |
| `Distribution/tests/native-comparison/paused-supplier/assess.bash` | `case.bash`, `turn-4-agent-proof` | 4: `# thread, and case.bash's turn-N fields. Turns 1–3 follow the supplier's` | run: existing rejected-case proof passed; unchanged assessor on separately derived saved baseline/candidate observations passed both arms |
| `Distribution/tests/native-comparison/paused-supplier/case.md` | `case.bash` | 53: `` `case.bash` materializes `remote.git` and the execution checkout `` | reused: origin, task, event sequence and quality promises unchanged; agent proof now includes legitimate delegation |
| `Distribution/tests/native-comparison/paused-supplier/comparisons/20261114T045440-40bf.txt` | `case.bash` | 27: `case-input-hash: 48229315c6fa3762cd0f876555ad8068c50c99b7f638234433386985552d8668 tests/native-comparison/paused-supplier/case.bash` | excluded: immutable historical comparison, never rewritten |
| `Distribution/tests/native-comparison/paused-supplier/comparisons/20261114T102744-1921.txt` | `Distribution/tests/native-comparison/paused-supplier/case.bash`, `case.bash` | 26: `case-input-hash: 4aee26c648f88dab7fdd692d1f1e3f5f4fea60c46b03e621887b6d8a7dafe055 Distribution/tests/native-comparison/paused-supplier/case.bash` | excluded: immutable actual comparison, original hash verified unchanged; corrected observation is separate audit |
| `Distribution/tests/native-family-layers.md` | `case.bash` | 70: `` and observer in `case.bash` and its assessor in `assess.bash`, with rejected `` | excluded: descriptive guidance, no changed family boundary |

### Test support or stand-in

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `Distribution/tests/support/native-comparison-pair.sh` | `case.bash` | 97: `{ read -r events && read -r empty_events; } < <(source "${case_path}/case.bash" \` | run: focused pair/refusal/refresh family passed; case-file enumeration automatically includes owned-proof.mjs |
| `Distribution/tests/support/native-comparison-preflight.sh` | `case.bash` | 28: `if [[ ! -f ${case_path}/case.bash ]]; then` | reused: unchanged Node/session prerequisites and case identity protocol; focused family still passes |
| `Distribution/tests/support/native-comparison-run.sh` | `case.bash` | 28: `# A case's case.bash defines case_events (its event names in order; those in` | run: changed case exercised through maintained paused-supplier credential-free runner; no runner/host adapter edit |

### Journey or feature

none found

### Guidance reader

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `.planning/slice-plans/621-close-native-comparison-harness-gaps/PLAN.md` | `case.bash` | 26: `` server (`case_database_start`, `case.bash` 110) before `migrateTestDB` `` | excluded: another execution planning record; its cleanup/turn-facts changes are not this proof repair |

## Direct changed consumers and proof

- `case.bash:case_agent_proof` retains root CLI success/failure. Only `none` with an explicit authorized session root reaches the new case-only helper.
- `owned-proof.mjs` reuses `codexSessionSettings` native lineage, current root turn and current workspace. Own token-usage turn IDs exclude copied fork history; static sequential exec calls pair with structured terminal receipts. Unsupported/unresolved evidence stays unknown; stdout cannot impersonate a receipt.
- `native-codex-owned-proof.test.mjs` exercises the actual shell observer plus foreign parent, wrong workspace, stale root turn, copied history, failure, unresolved output, receipt-shaped stdout, root failure and absent session authority.
- Exact native saved-record audit: old baseline observation `none`, new owned observation `passed`; candidate stays `passed`. Separate derived observations pass unchanged `assess.bash` for both arms. Original pair SHA256 `f568a2998474c1b97d4e96f6e10de223a83cf86f18347f8aa88cec758f78cd5a` remains unchanged.
- No agent-facing task, wake, fixture, event or native host setting changed; no new paid/API action.

Commands (all terminal exit 0):

```sh
PATH=/opt/homebrew/bin:$PATH OPEN_DOUGH_TEST_JOBS=1 npm test -- Distribution/tests/support/native-codex-owned-proof.test.mjs Distribution/tests/native-comparison-paused-supplier.sh
PATH=/opt/homebrew/bin:$PATH OPEN_DOUGH_TEST_JOBS=1 npm test -- Distribution/tests/native-comparison.sh Distribution/tests/native-comparison-pairs.sh Distribution/tests/native-comparison-refresh.sh Distribution/tests/native-comparison-incomplete.sh
PATH=/opt/homebrew/bin:$PATH node scripts/test-shares.mjs preview --split-count 4
```

Preview: 664 jobs, maximum 505.9 predicted job-seconds versus 694. Whitespace passed. Raw sizes helper97/case232/test82; formatting belongs to root.

PFE: native host stream remains the CLI command reader; it cannot own forked saved records. Existing `native-codex-session.mjs` owns descendant identity and is reused directly. The bounded case helper fills only the observed delegated-proof gap; no general tool parser/accounting framework was added.
