# Slice 4 native workflow comparison

Status: **incomplete**. The authorized matched retry stopped at its baseline's
observed token guard. Candidate and G6 were not launched. No completed matched
comparison, C65 savings or C68 improvement is claimed.

## Historical protocol and unchanged source pins

Origin: SEED-324's paused-supplier consumer, reconstructed as one invoice decision
in a disposable Node/Git project. The reusable example is
`Distribution/tests/blocked-execution-workflow-native.mjs`; its focused invoice
journey/accounting/history, observation, ownership and project helpers retain
this context. The earlier command-level native example is separate evidence.

The real installer uses complete managed inventories from these pinned sources:

- Baseline `91f32d39061d16793a190c5d9d9f2a6b26534fc7`.
- Candidate `0bc39b172c9a99bf8b627c0a1d527e3c8983ee61` (not run in this retry).

Their managed diff varies this blocked-wait feature only; common Distribution /
upstream changes are shared. No-model installer smoke verified 365/376 managed
files. No later fallback prose or evaluator edit silently substitutes a pin.

Both arms would receive the same installed `$dough-execute-plan --one-shot`
assignment and established start, accepted partial proof, exact native coordinates,
fixture and authority. The requested fields are subtotal, taxRate, taxAmount,
total, currency and supplierEvidence. No commit/publication, supplier/verifier
edit, model switch, capacity purchase, scope expansion or proof waiver is allowed.
The fixture supplies no report, hold enrollment or automatic continuation.

Producer sequence: actual initial false supplier judgment, unchanged paused
notice, ready/unchecked evidence, ready/checked evidence and qualifying replay.
The frozen gate accepts a handler fingerprint, completed checker output containing
its exact SHA, or ended baseline. Only an ended baseline after qualification may
receive one neutral evidence notification, counted as rescue; candidate gets none.
Expected completed result is 125 SGD subtotal, rate .08, tax 10, total 135,
provenance R8, preserved work/proof/settings, unchanged publication decisions.
A real idle tie leaves C65 unmet; completion alone does not settle C68.

Root initially allowed 20 minutes / 1.5M total / 25,000 output tokens per arm.
Before this retry it set the same common guard to **2M total**, retaining time /
output limits, because 555k failed startup spend could censor a complete workflow.
No completed comparative outcome informed that change. Counters can cross once
before observation stops them. G6 remains unreleased; its cost/shape is deferred.
No cap, route, source or prompt was adjusted during the retry.

## Frozen evaluator and admission

`/tmp/seed345-slice4-frozen-evaluator.json` pins all ten formatted source/test files,
the two payload revisions and pair limits. All ten hashes matched before baseline
and after stopping; copies and the post-run verification are under
`/tmp/seed345-pair-20261114-1436/baseline/`. No evaluator source changed during run.

Local admission at 14:35 Singapore on 2026-11-14: AC 100%, no maintained sleep-log
Sleep/Wake entries, natural load 4.35 / 4.37 / 6.82, approximately 1.14 GB free plus
14.3 GB inactive memory, and no competing owned heavy proof. The command used
`caffeinate -s -i`. Actual CLI and daemon 0.169.0; native start confirmed
`gpt-6.1-sol`, xhigh, approval never, dangerFullAccess and default service tier.
No model, policy, permission or effort override was supplied.

## Matched retry: baseline stopped, candidate withheld

Literal command, terminal session 34897:

`PATH=/opt/homebrew/bin:$PATH caffeinate -s -i node Distribution/tests/blocked-execution-workflow-native.mjs --native baseline /tmp/seed345-pair-20261114-1436/baseline/run 91f32d39061d16793a190c5d9d9f2a6b26534fc7`

Native thread `01a1d8c5-6a29-7e52-ab88-4e3406c479c8`, initial turn
`01a1d8c5-6a56-7971-824f-1e5af2adafb7`. Acceptance was retained immediately;
persisted full history worked. There were no descendants or duplicate native turns.
The baseline read its actual installed skill and applicable references, ran local
proof and supplier checks, explored native continuation facilities and cleaned its
disposable generated protocol files. A proxy metadata read timed out, so it
reported delivery unavailable rather than inventing success.

Actual first false judgment and unchanged-event check were observed. After the
producer's ready/unchecked event, the baseline read that evidence and reported
that checked proof remained missing, then started a bounded non-model supplier
watch. Its initial output contained the exact new checker SHA, but the enclosing
command was still running. The frozen gate consumed completed command items only;
it did not acknowledge that partial output or the earlier cat/prose observation.
Qualification and replay therefore were never delivered. This is a protocol /
exposure limitation, not an observed complete baseline or candidate defect.

The evaluator stopped on `Approved native aggregate token ceiling exceeded`, exit 1.
Its exact turn was observed **interrupted**, duration 253,423 ms.
`native-cleanup-status.json` records confirmed-terminal, remaining=[] and
unknownThreads=[]. A post-stop read of the exact native history confirms the
non-model wait, native command session 44160, completed exit 0 at
1794638432427, 118 ms after the native interruption. Its terminal output remained
ready/unchecked followed by blocked. No owned native turn, descendant or command
remains live. No replacement, candidate or further paid attempt was started.

## Observations, quality and cost

All records below are in the baseline run directory named above:

Portable decisive artifacts are compressed in [slice4-baseline-retry](slice4-baseline-retry/record.json),
with original-byte hashes and exact own-response records. Global/account notices
are excluded from its own-thread event stream; the original stream remains in `/tmp`.

- `payload-basis.json` / `installation.json`: actual pinned installer and all
  365 source-to-installed hashes. Post-stop audit reconfirmed all installed bytes.
- `native-start.json`, `initial-acceptance.json`, `owned-native-turns.json` and
  `native-events.jsonl`: exact identity/settings, acceptance and native activity.
- `initial-judgment-history.json`, event files, accounting snapshots and
  `post-stop-native-history.json`: actual judgments, incomplete event sequence,
  native terminal status and completed command 44160.
- `native-interruption.json` / `native-cleanup-status.json`: exact terminal event,
  no remaining known or unknown ownership, and retained recovery instructions.
- `post-stop-quality-audit.json`: all four accepted work/verifier/authority hashes
  preserved, accepted HEAD `6fcca07a4be543280cd2a9f39554df330462efbf` unchanged,
  actual `node verify-local.mjs` exit 0. No final report exists; Git status contains
  only the producer's supplier-evidence edit. No commit/publication/CI receipt.

Direct own-response usage, deduplicated by exact thread and response ID:
**27 requests, 2,086,340 input tokens (1,997,440 cached), 6,400 output tokens,
2,092,740 total tokens**, including 3,037 reasoning output. Cumulative token
snapshots and turn counts were not used. These are directly observed records;
unreported canceled/in-flight usage and whole implementation cost remain unknown.

The raw stream also contained 64,386 identical deprecation notices from full-history
hydration. The observer wakes on notices while its wait predicate reads history;
this is consistent with a notification/read feedback loop and material non-model
evaluation overhead. `observation-notification-audit.json` preserves the exact
notice. Notice counts are not model requests. No frozen source fix was attempted.

`idle-response-evidence.json` retains three immediately preceding sole
`write_stdin` calls for supplier-wait session 44160, their actual per-response
records and empty/aborted outputs: **3 idle-only retrieval requests, 310,806
observed tokens**. They neither supplied new supplier evidence nor handled a
completed deadline in those model responses. The final retrieval was aborted by
the evaluator guard. Transport-probe waits and combined reference-read calls are
excluded. This narrow action classification supplies no candidate comparison or
savings; necessary verification/liveness/deadline work keeps its own meaning.

Baseline manual evidence notifications: **0**, because qualification never arrived.
That is not a completed zero-rescue outcome. One evaluator safety interruption is
recorded separately. Candidate requests/tokens/idle/rescues, useful result,
publication/proof equivalence and comparative improvement are **unobserved**.

## Prior failures and total effort limits

Exact pre-retry assessment bytes were archived before this condensation at
`slice4-assessment-before-matched-retry.md.gz`, decompressed SHA-256
`60fb08a24eb7d664ab731c3b8c6765415e0fb62cdf1108e961f8789e5dda43d4`.
It preserves original commands, admission, decisions, technical attribution and
controlled red/green history; the existing refactor/consumer trace retain current
proof and structural dispositions.

Pre-turn setups `/tmp/seed345-workflow-baseline-20261114-1338` and suffix `-b`,
terminal sessions 46123 / 20837, threads
`01a1d891-25f9-7ba1-b35f-303bfdeac43f` /
`01a1d893-28ff-7e20-a09b-e6ba75dd96c1`, failed before initial input/turn submission
on empty-history / future-file startup assumptions. Missing usage stays unknown.
Their threads and artifacts remain untouched.

The first paid failed setup, suffix `-c`, session 26065, thread
`01a1d894-24af-7281-918c-0e0ca1ad1fc3`, lost observation after acceptance before
session persistence. Exact native recovery interrupted turn
`01a1d894-27c8-7330-8ac7-9b6c8f951e5b` and observed terminal status, with no child.
Its post-error recovery records retain **13 requests, 553,984 input (502,400
cached), 1,399 output, 555,383 total tokens**, including 223 reasoning output.
Initial pre-turn attribution was corrected when actual history proved acceptance.

These two paid failed observations total **40 recorded responses / 2,648,123
observed tokens**. They are evaluation cost, not matched outcomes. Whole execution,
coordinator and implementation-agent model effort remains unknown. Slice 2 already
records roughly an hour including two failed three-minute checks; Slice 3 has
qualitative effort only. This slice additionally required evaluator implementation,
multiple controlled defect repairs and independent structural reviews, with no
benefit established. No native-only total substitutes for that maintenance cost.

## New prospective protocol: changes after the initial yield

Root selected this different protocol after the failed retry; that failure is
never relabeled as a matched observation of this protocol. Assignment, fixture,
payload pins, native settings, proof and publication authority stay unchanged.
Before **any** producer event both arms must have an actual normally completed
initial native turn. Candidate also needs its workflow-owned held receipt;
baseline may retain manual fallback. The initial actual false supplier judgment
remains mandatory, with one history snapshot. `initial-yield-boundary.json` records
the actual terminal event and boundary time; next native proof must compare those
coordinates with the first producer event timestamp, not infer yield from elapsed time.

Only then deliver unchanged, insufficient, qualifying and replay evidence.
Candidate negative acknowledgments inspect actual held-record fingerprints;
baseline is already ended and needs no live handler or checker-format gate.
After qualification baseline may receive its one neutral evidence notification;
candidate gets none. Initial enrollment races reuse applicable Slice 2 evidence.
History/discovery now run at actual milestones/final inspection/cleanup, never
inside wait predicates. This observation targets after-yield continuation.

The observer's shared notification handler counts global notices in memory before
stream writes or wakes. It retains thread-scoped pre-admission evidence, replays
exact verified children, and directly wakes waiters only for admitted events.
Global native errors and disconnect remain failures. Generic filesystem observation
is retained; extra filesystem wakes cannot issue history queries from wait predicates.
Final success/failure records expose scalar `nativeNotices` audit counts.

A controlled history-read notice first reproduced three queries rather than one.
After correction it causes no requery/file growth, retains unadmitted child turn
evidence, and actual own terminal progress wakes and settles the wait. All eight
cases pass direct and maintained three-file commands; changed syntax passes.
No model/native call ran during repair, and no cap was changed or paid run released.
The historical three retrievals remain non-comparative failed-run cost.
After this repair and independent review, root authorizes one prospective
post-yield pair with common guards of 20 minutes / 3M observed total tokens /
25,000 output per arm. The old 2.09M interruption before final work motivated
this pre-run bound; no completed comparative result informed it. G6 is unreleased.
Actual new-protocol timestamps and outcomes remain unobserved.

## Maintained proof, shared guidance and remaining obligations

The ten frozen files passed the current seven controlled cases, maintained focused
runner, syntax, formatting and whitespace before release; see
[slice4-refactor.md](slice4-refactor.md) and [consumer trace](slice4-consumer-trace.md).
No source changed during this observation, so those deterministic checks remain
applicable. The actual native run is failed/incomplete despite those passes.
Follow [AGENTS.md's failure policy](../../../AGENTS.md#failing-and-flaky-tests) as
written. Root-only PLAN/source-review, Git/index/publication and CI observer were
untouched.

| Commitments | Actual observation / remaining gap |
| --- | --- |
| C01, C04; G3 | Actual full skill invocation and preserved partial work/proof observed. No complete blocked-to-qualified outcome; G3 remains open. |
| C41, C63, C64 | Prospective baseline ran incompletely; candidate and matched useful outcome/publication/proof decisions remain unobserved. |
| C65, C66, C68; Q20 | Three narrow idle-only baseline retrievals and zero manual notifications observed in an incomplete run. No comparable savings, rescue-equivalent outcome or improvement claim. |
| C42-C45 | Shared behavior review remains applicable: executing project supplies exact context; Codex uses its verified binding, Cursor/Claude explicit retained/manual fallback. No native automatic Cursor/Claude or current quota-reset claim. |
| Q21, Q22 | Local proof preserved; no CI receipt manufactured. No running proof was treated as supplier pause. Bounded non-model wait command's actual terminal result retained separately. |
| Q23, X01-X07 | Scope and authority remain unchanged; no rollout, reset/session-exit recovery, scheduler or general accounting framework was added. |
| G6 | Actual native attention/recovery observation remains pending and unreleased. |

Only the explicitly approved post-yield pair may now run. No automatic retry,
source adjustment, cap increase or attention case is inferred.
