// Private one-off analysis of the already-authorized paused-supplier pair.
// Reads retained evidence only. No host/API calls, case mutations or cumulative subtraction.
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { resolve, join, dirname } from "node:path";
import { createHash } from "node:crypto";
import { responseAccounting } from "/Users/terryyin/git/open-dough/.worktrees/resume-blocked-work-when-it-can-advance/Distribution/tests/support/blocked-execution-invoice-accounting.mjs";

const [pairPath, outputPath] = process.argv.slice(2);
if (!pairPath || !outputPath) throw new Error("node PRIVATE_SCRIPT PAIR_RECORD OUTPUT_JSON");
const coordinates = JSON.parse(readFileSync("/tmp/seed345-ab-run-coordinates.json", "utf8"));
const resultsRoot = resolve(coordinates.results);
const fields = (text) => new Map(text.split("\n").filter((line) => line.includes(": "))
  .map((line) => [line.slice(0, line.indexOf(": ")), line.slice(line.indexOf(": ") + 2)]));
const pair = fields(readFileSync(pairPath, "utf8"));
const phases = ["initial-hold", "unchanged-wake", "nonqualifying-new-evidence", "qualifying-continuation"];
const numeric = ["input_tokens", "cached_input_tokens", "cache_write_input_tokens", "output_tokens", "reasoning_output_tokens", "total_tokens"];
const sum = (records) => Object.fromEntries(numeric.map((key) => [key,
  records.every((record) => Number.isFinite(record.usage?.[key]))
    ? records.reduce((n, record) => n + record.usage[key], 0) : null]));
function jsonLines(text) {
  const rows = [], errors = [];
  for (const [index, line] of text.split("\n").entries()) {
    if (!line.trim()) continue;
    try { rows.push(JSON.parse(line)); } catch { errors.push(index + 1); }
  }
  return { rows, errors };
}
function ownRecord(path, expectedId, expectedParent) {
  if (!existsSync(path)) return { path, threadId: expectedId, available: false, reason: "missing exact retained record" };
  const text = readFileSync(path, "utf8"), parsed = jsonLines(text);
  const meta = parsed.rows.find((row) => row.type === "session_meta")?.payload;
  if (meta?.id !== expectedId || (expectedParent && meta.source?.subagent?.thread_spawn?.parent_thread_id !== expectedParent))
    return { path, threadId: expectedId, available: false, reason: "retained identity/parent mismatch" };
  const accounting = responseAccounting(text, expectedId);
  const responses = accounting.records ?? [];
  const ownIds = new Set(responses.map((response) => response.turn_id).filter(Boolean));
  const starts = parsed.rows.filter((row) => row.type === "event_msg" && row.payload?.type === "task_started")
    .map((row) => row.payload.turn_id).filter((id) => ownIds.has(id));
  const contexts = parsed.rows.filter((row) => row.type === "turn_context").map((row) => row.payload.turn_id)
    .filter((id) => ownIds.has(id));
  const turnIds = [...new Set([...starts, ...contexts])];
  const complete = new Set(parsed.rows.filter((row) => row.type === "event_msg" && row.payload?.type === "task_complete")
    .map((row) => row.payload.turn_id));
  const aborted = new Set(parsed.rows.filter((row) => row.type === "event_msg" && row.payload?.type === "turn_aborted")
    .map((row) => row.payload.turn_id));
  const opaque = new Set();
  for (const row of parsed.rows) {
    const value = row.payload ?? {};
    // Never inspect reasoning, encrypted content, account/session envelopes or tool catalogs.
    if (row.type !== "response_item" || !["function_call_output", "custom_tool_call_output", "message", "agent_message"].includes(value.type)) continue;
    const publicText = JSON.stringify(value.output ?? value.content ?? value.text ?? "");
    for (const match of publicText.matchAll(/(?:task_name|agent_name)\\?"\s*:\s*\\?"(\/root\/[^"\\\s]+)/g)) opaque.add(match[1]);
    if (/FINAL_ANSWER|Message Type: MESSAGE/.test(publicText))
      for (const match of publicText.matchAll(/(?:Task name|Sender):\s*(\/root\/[A-Za-z0-9_./-]+)/g)) opaque.add(match[1]);
  }
  const spawnedPath = meta.source?.subagent?.thread_spawn?.agent_path;
  return { path, threadId: expectedId, identityVerified: true, agentPath: meta.agent_path,
    agentPathEvidence: { topLevel: meta.agent_path, spawnMetadata: spawnedPath,
      explicitMatch: Boolean(meta.agent_path && meta.agent_path === spawnedPath) },
    available: accounting.available, requests: accounting.requests,
    usage: accounting.usage, responses, turnIds, opaqueHostTasks: [...opaque],
    completeForOwnRecordedTurns: accounting.available && !accounting.partialLastRecord && !parsed.errors.length
      && responses.every((response) => response.turn_id) && turnIds.every((id) => complete.has(id) && !aborted.has(id)),
    parseErrors: parsed.errors, publicRows: parsed.rows };
}
function safeSummary(value) {
  const { responses, publicRows, ...safe } = value;
  return safe;
}
function underResults(relative) {
  const path = resolve(resultsRoot, relative);
  if (!path.startsWith(`${resultsRoot}/`)) throw new Error("An arm path escapes the explicit retained results root");
  return path;
}
const arms = {};
for (const arm of ["baseline", "candidate"]) {
  const relative = pair.get(`${arm}-attempt`);
  if (!relative || relative === "none retained") {
    arms[arm] = { available: false, reason: "pair record names no retained arm" }; continue;
  }
  const directory = underResults(relative), record = fields(readFileSync(join(directory, "record"), "utf8"));
  const thread = record.get("thread"), own = ownRecord(join(directory, "codex-session.jsonl"), thread);
  const observations = fields(readFileSync(join(directory, "observations.txt"), "utf8"));
  const streams = phases.map((phase, i) => {
    const path = join(directory, `events-turn-${i + 1}.jsonl`);
    if (!existsSync(path)) return { phase, available: false, reason: "stream absent" };
    const parsed = jsonLines(readFileSync(path, "utf8"));
    const completed = parsed.rows.filter((row) => row.type === "turn.completed");
    return { phase, path, threadIds: [...new Set(parsed.rows.filter((row) => row.type === "thread.started").map((row) => row.thread_id))],
      streamCompleted: completed.length === 1 && !parsed.errors.length,
      cliUsage: completed.length === 1 ? completed[0].usage : null };
  });
  const mappingKnown = own.available && own.turnIds.length === 4 && streams.every((stream) =>
    stream.streamCompleted && stream.threadIds?.length === 1 && stream.threadIds[0] === thread);
  const phaseRows = phases.map((phase, i) => {
    if (!mappingKnown) return { phase, known: false, reason: "four sequential own turns and completed same-thread CLI streams are not all established" };
    const id = own.turnIds[i], responses = own.responses.filter((response) => response.turn_id === id), usage = sum(responses);
    const cliUsage = streams[i].cliUsage;
    const throughTurn = sum(own.responses.filter((response) => own.turnIds.slice(0, i + 1).includes(response.turn_id)));
    const checked = ["input_tokens", "cached_input_tokens", "output_tokens"].filter((key) => Number.isFinite(cliUsage?.[key]));
    const consistent = checked.length === 3 && checked.every((key) => throughTurn[key] === cliUsage[key]);
    return { phase, turnId: id, known: responses.length > 0, requests: responses.length, usage,
      allocation: "explicit own payload.turn_id, ordered by own native task_started; sequential same-thread runner streams",
      cliCumulativeMatchesDirectRecordsThroughTurn: consistent, cliCumulativeUsage: cliUsage,
      requestCountSource: "deduplicated own response_id records, not turn count or token_count snapshots" };
  });
  const edges = readFileSync(join(directory, "record"), "utf8").split("\n")
    .filter((line) => line.startsWith("codex-worker: ")).map((line) => {
      const match = /^codex-worker: (\S+) parent=(\S+) file=/.exec(line);
      return match ? { id: match[1], parent: match[2] } : null;
    }).filter(Boolean);
  const admitted = new Set([thread]), workers = [], pending = [...edges];
  while (pending.length) {
    const index = pending.findIndex((edge) => admitted.has(edge.parent));
    if (index < 0) break;
    const edge = pending.splice(index, 1)[0];
    const worker = ownRecord(join(directory, `codex-worker-${edge.id}.jsonl`), edge.id, edge.parent);
    if (worker.identityVerified) admitted.add(edge.id);
    const workerPhases = phases.map((phase, i) => {
      if (!mappingKnown || !worker.available) return { phase, known: false };
      const rows = worker.responses.filter((response) => response.root_turn_id === own.turnIds[i]);
      return { phase, attributedRequests: rows.length, usage: rows.length ? sum(rows) : null,
        attribution: "only explicit worker response root_turn_id equal to coordinator turn_id; no timestamp inference" };
    });
    const unallocated = worker.responses?.filter((response) => !(own.turnIds ?? []).includes(response.root_turn_id)) ?? [];
    workers.push({ ...safeSummary(worker), parent: edge.parent, phases: workerPhases,
      unallocatedRequests: worker.available ? unallocated.length : null,
      unallocatedUsage: unallocated.length ? sum(unallocated) : null });
  }
  const allRecords = [own, ...workers], named = [...new Set(allRecords.flatMap((value) => value.opaqueHostTasks ?? []))];
  const namedNativeWorkers = Object.fromEntries(workers.filter((worker) => worker.identityVerified && worker.agentPathEvidence.explicitMatch)
    .map((worker) => [worker.agentPath, { threadId: worker.threadId, parent: worker.parent, evidence: worker.agentPathEvidence }]));
  const opaque = named.filter((name) => !namedNativeWorkers[name]);
  const knownRecords = allRecords.filter((value) => value.available);
  const recordedTreeComplete = own.completeForOwnRecordedTurns && !pending.length
    && workers.every((worker) => worker.completeForOwnRecordedTurns);
  const phasesComplete = mappingKnown && recordedTreeComplete && workers.every((worker) => worker.unallocatedRequests === 0);
  const nativePhaseRows = phases.map((phase, i) => {
    if (!phasesComplete) return { phase, known: false, reason: "captured native-tree phase attribution incomplete" };
    const coordinatorPhase = phaseRows[i], workerRows = workers.map((worker) => worker.phases[i]);
    return { phase, known: true, requests: coordinatorPhase.requests + workerRows.reduce((n, value) => n + value.attributedRequests, 0),
      usage: Object.fromEntries(numeric.map((key) => [key, Number.isFinite(coordinatorPhase.usage[key])
        && workerRows.every((value) => value.attributedRequests === 0 || Number.isFinite(value.usage?.[key]))
        ? coordinatorPhase.usage[key] + workerRows.reduce((n, value) => n + (value.usage?.[key] ?? 0), 0) : null])),
      scope: "coordinator plus exact retained native workers; explicit response root_turn_id attribution" };
  });
  arms[arm] = { directory, assessment: observations.get("assessment-status"),
    coordinator: safeSummary(own), phases: phaseRows, workers, unmatchedWorkerEdges: pending,
    recordedNativePhases: nativePhaseRows, namedNativeWorkers,
    resolvedHostTaskNames: named.filter((name) => namedNativeWorkers[name]),
    opaqueHostTasks: opaque, opaqueHostWorkerRequests: opaque.length ? null : "none identified by public-result scan",
    opaqueHostWorkerSettings: opaque.length ? "unknown" : "none identified by public-result scan",
    observedNativeRequests: knownRecords.reduce((n, value) => n + value.requests, 0),
    observedNativeUsage: Object.fromEntries(numeric.map((key) => [key, knownRecords.every((value) => Number.isFinite(value.usage?.[key]))
      ? knownRecords.reduce((n, value) => n + value.usage[key], 0) : null])),
    completeForRetainedNativeTree: recordedTreeComplete,
    allWorkerAggregateKnown: recordedTreeComplete && !opaque.length,
    allWorkerAggregateScope: "coordinator plus explicitly metadata-identified retained native workers; unobserved host census is not excluded",
    opaqueAudit: opaque.length ? "identified host tasks without native counters" : "none identified by public-result scan; this is not proof of a complete host-worker census",
    scopeLimit: "native copies and identified public host-worker names only; unobservable host-worker usage/settings never count as zero" };
}
const quality = pair.get("verdict") === "preserved" && arms.baseline?.assessment === "pass" && arms.candidate?.assessment === "pass";
const parentComplete = [arms.baseline, arms.candidate].every((arm) => arm?.coordinator?.completeForOwnRecordedTurns && arm.phases?.every((phase) => phase.known && phase.cliCumulativeMatchesDirectRecordsThroughTurn));
const result = { pair: resolve(pairPath), pairVerdict: pair.get("verdict"), qualityPassedBoth: quality,
  schema: "Own token_usage_record.usage only, deduplicated by response_id; explicit turn_id/root_turn_id. CLI turn.completed.usage is cumulative and only crosschecked against direct records through that turn, never summed. turn_token_usage/thread_token_usage and token_count ignored.",
  forcedWakeLimit: "Both arms were forced through four CLI turns; two blocked-state wakes. Equal forced-turn count is not avoided-wake evidence. Nonqualifying publication brings new evidence and is reported separately from unchanged state.",
  arms, matchedCoordinatorComparison: null, conditionalEstimates: null };
if (quality && parentComplete) {
  const base = arms.baseline, candidate = arms.candidate;
  result.matchedCoordinatorComparison = { requestsDelta: candidate.coordinator.requests - base.coordinator.requests,
    usageDelta: Object.fromEntries(numeric.map((key) => [key, Number.isFinite(candidate.coordinator.usage?.[key]) && Number.isFinite(base.coordinator.usage?.[key])
      ? candidate.coordinator.usage[key] - base.coordinator.usage[key] : null])),
    scope: "coordinator component only; worker differential may change whole-task result" };
}
if (parentComplete) {
  const base = arms.baseline, candidate = arms.candidate;
  const cost = base.phases[1].usage.total_tokens;
  const delta = candidate.phases[0].usage.total_tokens - base.phases[0].usage.total_tokens;
  const overhead = Math.max(0, delta);
  result.conditionalEstimates = { estimationBasis: "completed unchanged-wake coordinator unit only; not a whole-task outcome-equivalent comparison",
    wholeTaskQualityPassedBoth: quality,
    nonblockedTasks: "approximately zero avoided-wake saving; extra guidance overhead remains possible",
    unchangedWakeCoordinatorTokens: cost, observedInitialCoordinatorDelta: delta, conservativeInitialOverheadProxy: overhead,
    rows: [2, 5, 10].map((wakes) => ({ avoidedUnchangedWakes: wakes, estimatedCoordinatorTokensSaved: wakes * cost - overhead })),
    assumptions: ["The supported daemon binding avoids these future unchanged wakes; this CLI pair does not observe their elimination.",
      "The CLI initial-phase delta is only a startup-overhead proxy, not measured daemon enrollment overhead.",
      "Worker differential, model/session variability and task distribution are unmeasured; these are conditional estimates, not a population mean.",
      "Input includes cached input; cached tokens are a subset, not added again. Tokens are not billing cost."],
    populationMean: null, implementationBreakEven: "Use known implementation-token lower bound divided by positive net savings only as a lower-bound task count; full implementation/worker cost remains unknown." };
}
writeFileSync(outputPath, `${JSON.stringify(result, null, 2)}\n`, { mode: 0o600 });
console.log(JSON.stringify({ output: resolve(outputPath), qualityPassedBoth: quality,
  coordinatorComparisonAvailable: result.matchedCoordinatorComparison !== null,
  scriptSha256: createHash("sha256").update(readFileSync(new URL(import.meta.url))).digest("hex") }));
