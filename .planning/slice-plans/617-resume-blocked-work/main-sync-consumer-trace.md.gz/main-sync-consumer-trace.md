# Consumer trace

## Effect terms searched

| Term | Origin |
| --- | --- |
| `Distribution/src/skills/dough-execute-plan/scripts/codex-rpc.mjs` | changed path |
| `codex-rpc.mjs` | basename of `Distribution/src/skills/dough-execute-plan/scripts/codex-rpc.mjs` |
| `dashboard/src/SidePanelHeader.tsx` | changed path |
| `SidePanelHeader.tsx` | basename of `dashboard/src/SidePanelHeader.tsx` |
| `dashboard/src/pageStorySelection.tsx` | changed path |
| `pageStorySelection.tsx` | basename of `dashboard/src/pageStorySelection.tsx` |
| `dashboard/tests/support/codexObservation.ts` | changed path |
| `codexObservation.ts` | basename of `dashboard/tests/support/codexObservation.ts` |
| `native_comparison_turn` | supplied |
| `continuingInCodex` | supplied |
| `shownSessionsButton` | supplied |
| `toggleOnEmptyArea` | supplied |

## Scope

Whole checkout at `764c4e0fe0ce`, including uncommitted and untracked files: 6500 tracked and untracked non-ignored files searched with fixed-string, case-insensitive matching.

Changed files not searched: `Distribution/src/skills/dough-execute-plan/scripts/codex-rpc.mjs`, `dashboard/src/SidePanelHeader.tsx`, `dashboard/src/pageStorySelection.tsx`, `dashboard/tests/support/codexObservation.ts`.

## Located consumers

Kinds are path hints for inspection; each file appears once. Fill every Disposition with `run`, `reused` or `excluded: <reason the effect does not reach its boundary>`.

### Production

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `dashboard/server/hosts/codex/rpc.ts` | `Distribution/src/skills/dough-execute-plan/scripts/codex-rpc.mjs`, `codex-rpc.mjs` | 8: `import { CodexConnection } from "../../../../Distribution/src/skills/dough-execute-plan/scripts/codex-rpc.mjs";` |reused: wrapper and extracted RPC contract unchanged; accepted transport/native/CI2537 proof remains applicable |
| `dashboard/src/Board.tsx` | `pageStorySelection.tsx` | 7: `import { useStorySelection } from "./pageStorySelection.tsx";` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/ciFollowUpNavigation.tsx` | `pageStorySelection.tsx` | 13: `} from "./pageStorySelection.tsx";` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/Columns.tsx` | `pageStorySelection.tsx` | 12: `import { useStorySelection } from "./pageStorySelection.tsx";` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/DoneStoryCard.tsx` | `pageStorySelection.tsx`, `toggleOnEmptyArea` | 18: `` // (`./pageStorySelection.tsx`); nested controls keep their own behavior. `` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/FinalReport.tsx` | `SidePanelHeader.tsx` | 3: `import { SidePanelHeader } from "./SidePanelHeader.tsx";` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/intentCiTarget.ts` | `pageStorySelection.tsx` | 3: `` // selected story (`./pageStorySelection.tsx`), the branch the story-branch `` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/IntentPage.tsx` | `pageStorySelection.tsx` | 33: `import type { SelectedStory } from "./pageStorySelection.tsx";` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/IntentPerspective.tsx` | `pageStorySelection.tsx` | 49: `} from "./pageStorySelection.tsx";` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/intentStoryTabs.tsx` | `pageStorySelection.tsx` | 7: `` // (`./pageStorySelection.tsx`), so every new selection, even of a story `` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/PageFrame.tsx` | `pageStorySelection.tsx` | 37: `} from "./pageStorySelection.tsx";` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/pageIntentMode.tsx` | `pageStorySelection.tsx` | 22: `} from "./pageStorySelection.tsx";` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/pageSidePanel.ts` | `pageStorySelection.tsx` | 31: `import type { PageStorySelection } from "./pageStorySelection.tsx";` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/pageStoryInspection.tsx` | `pageStorySelection.tsx` | 5: `` // never changes the page's selected story (`./pageStorySelection.tsx`). `` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/RecentlyDone.tsx` | `pageStorySelection.tsx` | 21: `import { useStorySelection } from "./pageStorySelection.tsx";` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/recentlyDoneSelection.ts` | `pageStorySelection.tsx` | 44: `} from "./pageStorySelection.tsx";` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/RetainedFollowUpPerspective.tsx` | `pageStorySelection.tsx` | 21: `import { useStorySelection } from "./pageStorySelection.tsx";` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/SessionsSidebar.tsx` | `shownSessionsButton` | 55: `shownSessionsButton,` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/sessionsSidebarElements.ts` | `shownSessionsButton` | 7: `export const shownSessionsButton = () =>` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/sidePanelContent.ts` | `pageStorySelection.tsx` | 12: `import type { SelectedStory } from "./pageStorySelection.tsx";` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/StoryCard.tsx` | `pageStorySelection.tsx`, `toggleOnEmptyArea` | 10: `` // the card toggles the page's selected story (`./pageStorySelection.tsx`). `` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/StoryReview.tsx` | `SidePanelHeader.tsx` | 3: `import { SidePanelHeader } from "./SidePanelHeader.tsx";` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `dashboard/src/Terminal.tsx` | `SidePanelHeader.tsx` | 16: `import { SidePanelHeader } from "./SidePanelHeader.tsx";` |reused: UI consumer matches published main or is unchanged; selection/header state stays in existing owners and does not alter blocked-thread/RPC authority; root owns renewed merge CI |
| `Distribution/src/install/open-dough-execution-payload.sh` | `codex-rpc.mjs` | 39: `dough-execute-plan/scripts/codex-rpc.mjs` |reused: blocked runtime, RPC, builders and native-example consumers unchanged by this merge; accepted focused/native/CI2537 proof remains applicable |
| `Distribution/src/skills/dough-execute-plan/scripts/blocked-execution-codex.mjs` | `codex-rpc.mjs` | 2: `import { CodexConnection } from "./codex-rpc.mjs";` |reused: blocked runtime, RPC, builders and native-example consumers unchanged by this merge; accepted focused/native/CI2537 proof remains applicable |

### Test

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `dashboard/backend-tests/launches/agent-launch-codex-options.spec.ts` | `codexObservation.ts` | 11: `import { daemonStarts, passive } from "../../tests/support/codexObservation.ts";` |reused: published main fixture/default or unchanged consumer; session identity/protocol assertions preserved, no refactor edit invalidates their proof; root owns renewed merge CI |
| `dashboard/backend-tests/launches/agent-launch-codex-startup.spec.ts` | `codexObservation.ts` | 28: `} from "../../tests/support/codexObservation.ts";` |reused: published main fixture/default or unchanged consumer; session identity/protocol assertions preserved, no refactor edit invalidates their proof; root owns renewed merge CI |
| `dashboard/backend-tests/sessions/agent-launch-codex-observation-alerts.spec.ts` | `codexObservation.ts` | 12: `} from "../../tests/support/codexObservation.ts";` |reused: published main fixture/default or unchanged consumer; session identity/protocol assertions preserved, no refactor edit invalidates their proof; root owns renewed merge CI |
| `dashboard/backend-tests/sessions/agent-launch-codex-observation-concurrency.spec.ts` | `codexObservation.ts` | 8: `} from "../../tests/support/codexObservation.ts";` |reused: published main fixture/default or unchanged consumer; session identity/protocol assertions preserved, no refactor edit invalidates their proof; root owns renewed merge CI |
| `dashboard/backend-tests/sessions/agent-launch-codex-observation-sharing.spec.ts` | `codexObservation.ts` | 17: `} from "../../tests/support/codexObservation.ts";` |reused: published main fixture/default or unchanged consumer; session identity/protocol assertions preserved, no refactor edit invalidates their proof; root owns renewed merge CI |
| `dashboard/backend-tests/sessions/agent-launch-codex-observation-status.spec.ts` | `codexObservation.ts` | 20: `} from "../../tests/support/codexObservation.ts";` |reused: published main fixture/default or unchanged consumer; session identity/protocol assertions preserved, no refactor edit invalidates their proof; root owns renewed merge CI |
| `dashboard/backend-tests/sessions/agent-launch-codex-observation-wait.spec.ts` | `codexObservation.ts` | 17: `} from "../../tests/support/codexObservation.ts";` |reused: published main fixture/default or unchanged consumer; session identity/protocol assertions preserved, no refactor edit invalidates their proof; root owns renewed merge CI |
| `dashboard/backend-tests/sessions/agent-launch-sessions-fresh.spec.ts` | `codexObservation.ts` | 11: `import { sessionsRequest } from "../../tests/support/codexObservation.ts";` |reused: published main fixture/default or unchanged consumer; session identity/protocol assertions preserved, no refactor edit invalidates their proof; root owns renewed merge CI |
| `dashboard/backend-tests/sessions/agent-launch-sessions-unchanged.spec.ts` | `codexObservation.ts` | 15: `} from "../../tests/support/codexObservation.ts";` |reused: published main fixture/default or unchanged consumer; session identity/protocol assertions preserved, no refactor edit invalidates their proof; root owns renewed merge CI |
| `dashboard/backend-tests/sessions/session-alerts-input-continuity.spec.ts` | `codexObservation.ts` | 14: `} from "../../tests/support/codexObservation.ts";` |reused: published main fixture/default or unchanged consumer; session identity/protocol assertions preserved, no refactor edit invalidates their proof; root owns renewed merge CI |
| `dashboard/backend-tests/terminals/agent-terminal-codex.spec.ts` | `codexObservation.ts` | 30: `import { codexEnvironments } from "../../tests/support/codexObservation.ts";` |reused: published main fixture/default or unchanged consumer; session identity/protocol assertions preserved, no refactor edit invalidates their proof; root owns renewed merge CI |
| `dashboard/tests/sessions/agent-launch-sessions-unanswered.spec.ts` | `codexObservation.ts` | 24: `} from "../support/codexObservation.ts";` |reused: published main fixture/default or unchanged consumer; session identity/protocol assertions preserved, no refactor edit invalidates their proof; root owns renewed merge CI |
| `Distribution/src/skills/dough-execute-plan/scripts/blocked-execution-attention.test.mjs` | `continuingInCodex` | 148: `builder.continuingInCodex(` |reused: blocked runtime, RPC, builders and native-example consumers unchanged by this merge; accepted focused/native/CI2537 proof remains applicable |
| `Distribution/src/skills/dough-execute-plan/scripts/codex-rpc.test.mjs` | `codex-rpc.mjs` | 5: `import { CodexConnection, NativeRefusal } from "./codex-rpc.mjs";` |reused: blocked runtime, RPC, builders and native-example consumers unchanged by this merge; accepted focused/native/CI2537 proof remains applicable |
| `Distribution/tests/blocked-execution-invoice-attention.test.mjs` | `continuingInCodex` | 8: `.continuingInCodex("invoice", "unix:///tmp/invoice.sock")` |reused: blocked runtime, RPC, builders and native-example consumers unchanged by this merge; accepted focused/native/CI2537 proof remains applicable |
| `Distribution/tests/blocked-execution-native.mjs` | `codex-rpc.mjs` | 25: `import { CodexConnection } from "../src/skills/dough-execute-plan/scripts/codex-rpc.mjs";` |reused: blocked runtime, RPC, builders and native-example consumers unchanged by this merge; accepted focused/native/CI2537 proof remains applicable |

### Test support or stand-in

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `dashboard/tests/native-host-fixtures.md` | `codexObservation.ts` | 45: `` (`codexEnvironments` in `support/codexObservation.ts`, for the daemon start or `` |reused: published main fixture/default or unchanged consumer; session identity/protocol assertions preserved, no refactor edit invalidates their proof; root owns renewed merge CI |
| `dashboard/tests/support/fakeCodex.ts` | `codexObservation.ts` | 14: `import { passiveCodexFixture } from "./fakeCodexObservation.ts";` |reused: published main fixture/default or unchanged consumer; session identity/protocol assertions preserved, no refactor edit invalidates their proof; root owns renewed merge CI |
| `Distribution/src/skills/dough-execute-plan/scripts/blocked-execution-test-fixtures.mjs` | `continuingInCodex` | 89: `.continuingInCodex(native.threadId, codexEndpoint(native))` |reused: blocked runtime, RPC, builders and native-example consumers unchanged by this merge; accepted focused/native/CI2537 proof remains applicable |
| `Distribution/tests/support/blocked-execution-native-project.mjs` | `continuingInCodex` | 109: `.continuingInCodex(threadId, endpoint)` |reused: blocked runtime, RPC, builders and native-example consumers unchanged by this merge; accepted focused/native/CI2537 proof remains applicable |
| `Distribution/tests/support/blocked-execution-workflow-observation.mjs` | `codex-rpc.mjs` | 7: `import { CodexConnection } from "../../src/skills/dough-execute-plan/scripts/codex-rpc.mjs";` |reused: blocked runtime, RPC, builders and native-example consumers unchanged by this merge; accepted focused/native/CI2537 proof remains applicable |
| `Distribution/tests/support/heldExecutionTestData.mjs` | `continuingInCodex` | 111: `continuingInCodex(threadId, endpoint) {` |reused: blocked runtime, RPC, builders and native-example consumers unchanged by this merge; accepted focused/native/CI2537 proof remains applicable |
| `Distribution/tests/support/native-comparison-run.sh` | `native_comparison_turn` | 79: `native_comparison_turn() {` |reused: runner/case bytes match HEAD and published main; current native pair is separately owned by root |

### Journey or feature

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `e2e/launches/agent-launch-codex.spec.ts` | `dashboard/tests/support/codexObservation.ts`, `codexObservation.ts` | 43: `import { passive } from "../../dashboard/tests/support/codexObservation.ts";` |reused: published main fixture/default or unchanged consumer; session identity/protocol assertions preserved, no refactor edit invalidates their proof; root owns renewed merge CI |
| `e2e/sessions/agent-launch-codex-observation-workspace.spec.ts` | `dashboard/tests/support/codexObservation.ts`, `codexObservation.ts` | 29: `} from "../../dashboard/tests/support/codexObservation.ts";` |reused: published main fixture/default or unchanged consumer; session identity/protocol assertions preserved, no refactor edit invalidates their proof; root owns renewed merge CI |
| `e2e/sessions/agent-launch-codex-observation.spec.ts` | `dashboard/tests/support/codexObservation.ts`, `codexObservation.ts` | 30: `} from "../../dashboard/tests/support/codexObservation.ts";` |reused: published main fixture/default or unchanged consumer; session identity/protocol assertions preserved, no refactor edit invalidates their proof; root owns renewed merge CI |
| `e2e/sessions/project-restored-session.spec.ts` | `dashboard/tests/support/codexObservation.ts`, `codexObservation.ts` | 13: `} from "../../dashboard/tests/support/codexObservation.ts";` |reused: published main fixture/default or unchanged consumer; session identity/protocol assertions preserved, no refactor edit invalidates their proof; root owns renewed merge CI |

### Guidance reader

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `.planning/slice-plans/617-resume-blocked-work/distribution-integration.md` | `Distribution/src/skills/dough-execute-plan/scripts/codex-rpc.mjs`, `codex-rpc.mjs` | 40: `` \| Dashboard `server/hosts/codex/rpc.ts` \| imports/exports `../../../../Distribution/src/skills/dough-execute-plan/scripts/codex-rpc.mjs` \| `` |excluded: nonexecuting retained research/plan evidence; no runtime observation changes |
| `.planning/slice-plans/617-resume-blocked-work/slice2-assessment.md` | `codex-rpc.mjs` | 14: `` `codex-rpc.mjs` / `codex-unix-websocket.mjs` connection is shared by the installed `` |excluded: nonexecuting retained research/plan evidence; no runtime observation changes |
| `.planning/slice-plans/621-close-native-comparison-harness-gaps/PLAN.md` | `native_comparison_turn` | 131: `` - **Per-turn host facts:** the runner's `native_comparison_turn` already `` |excluded: nonexecuting retained research/plan evidence; no runtime observation changes |

## Integration review disposition

All104 staged paths are exact published MERGE_HEAD7e7f72c8 content, including
the deleted builder-only test. The source/case runner and NativeCompare fixture
are unchanged. Imported UI controls/selection and MakeMe defaults add no second
Codex transport, continuation owner or supplier-condition interpretation.
`codexObservation.ts` drops an incidental September launch timestamp and now uses
the builder's valid January default; its workspace/endpoint/session identity and
passive protocol assertions remain unchanged. Native turn metadata and source
`blocked-execution-*` do not consume that fixture timestamp.

The imported UI moves the existing Sessions context to encompass side-panel
headers, reuses one SidePanelHeader, and updates the same selection owner after
removing SelectStory. No old SelectStory or sessionsButton() source caller remains.
No refactor candidate was introduced/exposed by composition; no source edits,
renames, extraction, generation or tests were performed. Staged and unstaged
`git diff --check` passed. Coordinator retains format/hook lint and merge CI.

Three oversized published preservation records remain unchanged: generated done
catalog2172lines, active plan621389lines, ADR0008271lines. They are outside this
assigned integration refactoring concept; no new authored/product source exceeds
250. Own new A/B basis record remains below250lines. No size exception or unrelated rewrite
is introduced by this review.

Expensive-proof decision reused: no paid/native/full-suite work from this pass;
two authorized native A/B arms already run concurrently on the local machine.
The pair's verdict/accounting and final typical-task estimate remain root-owned
future observations, not claims supplied by this review.
