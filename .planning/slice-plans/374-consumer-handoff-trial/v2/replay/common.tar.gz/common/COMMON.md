# Frozen common replay evidence

This is the new version-2 producer reconstruction of fixed candidate
`90ea771039c36761b5973ab728e73ddcbce19935` against base
`2f8cb0e23717e91c6899dc2a26b65dcc9ffd2425`. It is a repeated fixed-case replay
outside the four prospective cases. C includes the entire newly dispatched task,
reading, tools, drafting and return; the parent records native dispatch/return.
The original owner's historical C/I0 and full presentation effort remain unknown.
No tests, formatter, lint, refactor, commits, pushes or product edits were run.
No old A/B/common experimental leads, auditor, calibration or later assessor outputs
were opened. Both presentations must expose this entire identical frozen directory;
there is no B navigator here.

## Source promise and actual change

The selected story promises cheaper repeated full-app production-policy tests
while preserving every removed assertion through an inspected surviving or
replacement observation. It keeps actual no-work skips, published policy precedence,
latest selection, unsupported-policy/build-failure baseline preservation, successful
activation ownership, npm/Vite/pinning/replacement/recovery/shared records/configuration
and process/checkout cleanup. Full source text is `input-00-SEED-171-production-policy-ci-time.md`.
The normal source review's complete C/Q/J/X clauses remain in `ordinary-source-review.md`.
Evaluation and CI obligations are separate from consumer purposes.

Exactly three code contracts changed: `dashboard/tests/boundary/production-qualification.spec.ts`,
`dashboard/tests/support/productionQualificationFixture.ts`, and
`dashboard/tests/support/productionUpdatePolicies.ts`. `source.diff` contains their
complete base-to-candidate diff. All six aggregate changed paths, including the three
ordinary planning records, are in `source-state.json`. No production code changed.
Qualification setup/background-Git support is extracted unchanged into its own
support file. The new real-Git extra/docs/mixed/accumulated case replaces overlapping
F/H policy-rule observations before the watcher predecessor narrows. Published
policy joins E; distinct G precedence/no-work, P/Q policy recovery and R/S build
recovery remain. Q's ignored workflow/docs repair now requires P's retained application
paths. Added page assertions preserve visible content while builds fail and after T skips.

The complete ordinary original-observation→surviving-assertion ledger is
`ordinary-coverage-map.md`; it records each removed title, replacement, prefix,
policy-rule and no-work observation rather than relying on test names/counts.
The real watcher qualifier boolean branch and baseline update are captured in
`inspected-scripts__watch-dashboard.mjs`. Qualification decides from real published
Git trees; boundary results do not observe installation/restart/baseline ownership.
Actual watcher `deploymentWork` compares preparation log count, independent recorded
builds, activation logs and preview PIDs. Replacement checks same URL, changed PID,
old PID stopped and new PID live in `inspected-dashboard__tests__support__productionWatcher.ts`.

## I0/H0 boundary and purposes

I0 was frozen at **2026-10-29T07:27:36.230658+00:00**, SHA-256 **823cb5781d5edc5a3823bfd9828135ee42e31f1305fb3ea1fbbd62edc042cdb9**, before opening any trace,
old PLAN373/coverage/source review or proof. It is this producer's new I0, never the
historical owner's I0. AGENTS and active PLAN374 were read first; immutable seed171
was read in full (goal/scope supply the promise, evaluation remains separate),
then the diff and exactly the three changed code files. The initial incorrect
boundary/support path guesses returned no source; actual support paths were read.
I0 records eight IDs P01–P08 and inspected source hashes. The source worktree was
clean, detached at candidate, tree `1a189b46f84250469e2dc0a8458793011c20af76`.
`source-state.json` rechecks the same HEAD/tree and empty porcelain status.

`H0.json` is the full common purpose inventory with responsibilities, changed or
preserved observables, actual observing assertions, proof references, decisions and
limits. P01–P07 retain real range/policy/errors/cleanup, watcher skip/latest/baseline
purposes already identified in I0. P08 is fixture/proof integrity and is explicitly
a constraint outside the consumer denominator. P09–P14 establish concrete pinning,
replacement, records, configuration, held-build shutdown and distinct recovery
observations under the broad preservation obligations already known from the seed.
P15–P17 preserve specifically identified accepted-start, published-read and runner/
port observations; their relevance to this narrowed support contract is unresolved.
They are not fabricated exclusions or established required omissions.

H0−I0 contains nine deduplicated new concrete purpose IDs P09–P17, of which six
have justified inspected observing proof and three retain an unknown scope decision.
This is a producer discovery inventory, not an independent audited denominator or
an assertion that these broad story obligations were unknown before tracing.
No numerator/quality result can be inferred merely from these counts.

## Fresh trace, original population and dispositions

`fresh-trace-command.json` retains literal argv/cwd/start/end/exit0. The exact command:

```sh
node .agents/skills/dough-execute-plan/scripts/consumer-trace.mjs --checkout /private/tmp/consumer-tracing-v2-source-90ea --path dashboard/tests/boundary/production-qualification.spec.ts --path dashboard/tests/support/productionQualificationFixture.ts --path dashboard/tests/support/productionUpdatePolicies.ts
```

Complete stdout/stderr are `fresh-trace.stdout`/`fresh-trace.stderr`. It searched
4098 nonignored files at candidate, excluded exactly the three changed code inputs,
and found five rows. No trial metadata or generic PLAN term was traced.
The historical raw trace and literal dispositions are preserved unchanged in
`original-consumer-trace.json` and `original-consumer-trace-dispositions.md`, with
identical copies among `raw-proof/`. The original command (full literal record in
`raw-proof/implementation-commands.txt`) used --base, a changed coverage map, six
semantic terms and diff-derived symbols/removed text, searched4097files and listed96.
The original trace's checkout HEAD was the base plus then-uncommitted work; it is
historical evidence, not a new candidate run.

Fresh5 ∩ original96 =4; union=97. The sole fresh-only path is the ordinary
coverage map, which the old invocation treated as a changed input. All92original-only
paths remain retained and individually enumerated in `population-delta.json`.
The fresh invocation's path/basename-only search is narrower than the old semantic/
diff search; disappearance from the fresh trace does not prove exclusion.
The trace population is not the consumer-purpose denominator.

`union-index.json` preserves every union path, both memberships, each original/fresh
group, match terms, first matching line and actual disposition/reason/provenance.
All original96 retain11run and85excluded owner dispositions verbatim. None of those
85exclusions is upgraded to independent inspection merely by copying it. The fresh
coverage-map row is reused as the inspected ordinary assertion/proof ledger; this is
evidence use, not a runtime execution claim. Categories alone exclude nothing.
Some broader executed semantic consumers (for example production-watcher.spec.ts)
are not literal trace rows; H0 explicitly names their proof without silently changing
the preserved97-path union. New unknown required semantic scope remains an honest gap.

A draft parser initially split the escaped `\|` inside dashboard/COMMANDS.md's
matching-line cell, briefly reporting84excluded/11run/one invalid value. It was
corrected before common freeze to split only unescaped separators and read the final
disposition cell. Raw bytes never changed. Parent independently raised the same
issue after the correction and will account for its concurrent checking interval.

## Literal normal proof and full retained facts

`raw-proof/` copies all31 supplied immutable proof files byte-for-byte; each original
absolute input path, output copy, size and SHA-256 is in `proof-input-index.json`.
`proof-facts.json` retains literal native runner argv/cwd/IDs/times, every case,
execution outcome, retry and attempt from all nine run records. Complete log,
timing, selection, comparison, discriminator and quiescence records remain alongside
it; no facts require trusting this short prose or an omitted stdout excerpt.
The logs/records are historic reused proof, not tests executed by this producer.

The normal family used identical two filters/default worker capacity/relevant
Node24.21/dependencies and env -u NO_COLOR; replacement case/fixture/global build
cost is included. Configured capacity8 does not mean8active workers. Full literal
/usr/bin/time, proof/times environment paths and redirections are preserved in
`raw-proof/implementation-commands.txt`. Principal commands:

```sh
env -u NO_COLOR npm run test:dashboard -- production-watcher-updates.spec.ts production-qualification.spec.ts
env -u NO_COLOR npm run test:dashboard -- production-qualification.spec.ts
env -u NO_COLOR npm run test:dashboard -- production-watcher production-deployment production-qualification
```

- `application-range-mutant`: 1 selected, strict `failed`, reporter 3.358s, wall Nones; 1 attempts, retries 0. Full argv, per-case expectations/outcomes/attempts and timestamps: `raw-proof/application-range-mutant.json`.
- `candidate-policy-mutant`: 1 selected, strict `failed`, reporter 3.150s, wall Nones; 1 attempts, retries 0. Full argv, per-case expectations/outcomes/attempts and timestamps: `raw-proof/candidate-policy-mutant.json`.
- `consumers`: 27 selected, strict `passed`, reporter 84.448s, wall 84.83s; 27 attempts, retries 0. Full argv, per-case expectations/outcomes/attempts and timestamps: `raw-proof/consumers.json`.
- `family-after-1`: 11 selected, strict `passed`, reporter 67.091s, wall 67.53s; 11 attempts, retries 0. Full argv, per-case expectations/outcomes/attempts and timestamps: `raw-proof/family-after-1.json`.
- `family-after-2`: 11 selected, strict `passed`, reporter 67.356s, wall 67.75s; 11 attempts, retries 0. Full argv, per-case expectations/outcomes/attempts and timestamps: `raw-proof/family-after-2.json`.
- `family-after-3`: 11 selected, strict `passed`, reporter 66.895s, wall 67.3s; 11 attempts, retries 0. Full argv, per-case expectations/outcomes/attempts and timestamps: `raw-proof/family-after-3.json`.
- `family-before`: 10 selected, strict `passed`, reporter 74.315s, wall 74.68s; 10 attempts, retries 0. Full argv, per-case expectations/outcomes/attempts and timestamps: `raw-proof/family-before.json`.
- `qualification-replacement`: 4 selected, strict `passed`, reporter 5.672s, wall 6.12s; 4 attempts, retries 0. Full argv, per-case expectations/outcomes/attempts and timestamps: `raw-proof/qualification-replacement.json`.
- `qualification-restored`: 3 selected, strict `passed`, reporter 4.408s, wall Nones; 3 attempts, retries 0. Full argv, per-case expectations/outcomes/attempts and timestamps: `raw-proof/qualification-restored.json`.

The original ten family case identities remain, with one added real-Git case;
three consecutive candidate passes selected11each, no removals/skips/retries.
Replacement qualification proof selected4 and passed before narrowing. Mutant
candidate-policy and application-range records each selected1 and failed the actual
assertion, exit1, followed by restored3-case strictpass: diagnostic failures are
not passing retries. Broader ordinary proof selected27 in8registration sources/
6owning specs and passed strict/exit0, wall84.83s/reporter84.448s. The two normal
family filters yield wall74.68s before versus67.53/67.75/67.30after, reporter
74.315s versus67.091/67.356/66.895s. Exact old/new names and expected verdicts are
retained in the raw JSON, not inferred from counts.

Independent gate-prefix assertions observe successful watcher builds A/B/C/E/Q/S=6
versus A/B/C/E/F/H/Q/S=8; policy activations5→3; one held shutdown gate and unchanged
global Vite build remain. R/S failure attempts occur before counting/Vite gate;
preparation/install attempts are at least2with no exact retry count claimed.
Owning-spec concurrent aggregate times are not whole-CI savings. Single baseline,
different load and unknown other-chat work limit causal/runner-variance inference.
Quiescence records all five owned completed successful command IDs with no processes
or retained output directories; ordinary strict teardown passed.

## Evaluation obligations and provenance limits

Frozen ordinary PLAN373/source review retain G1: fresh complete candidate hosted CI,
named candidate revision, unchanged verdict/move/platform skip/retry accounting,
build/fixture costs, queue/job/suite times and runner variance remain unfinished and
coordinator-owned. Baseline hosted run40825747965 at80678d4a(runtimeb8ad020a) is an
ordinary owner claim:16jobs passed,1740selected/1736expected/4skips/noextraattempts,
580owning files/12shards/4workers, longestjob217s/maxsuite191.422s/fullCI221s,
queue3s/startspread1s. Its raw hosted reports are absent from the supplied31-file
snapshot, so these values are not independently re-observed here. Do not infer
hosted CI gain from local speed or claim the source story done.

Historical proof records do not contain tested-source content hashes. Current
candidate bytes/hashes and recorded run identities are preserved, but exact historical
byte identity cannot be independently established from them. The ordinary owner
claims accepted local proof survived a one-EOF-blank-line refactor; that is retained
as an owner provenance claim, not newly measured identity. Historical baseline run
at80678d4a/runtimeb8ad020a and the comparison base2f8cb0e2are distinct identities.
No duplicate tests, fresh hosted checks, delivery, source cleanup or authority change
is authorized or claimed by this replay. Original costs and unobserved later effects
remain unknown. Specific P15–P17 scope uncertainty, uninspected owner exclusions,
narrow fresh search and hosted G1 remain open for the later independent auditor/reviewers.

`manifest.json` hashes every common file except itself (no self-hash loop), all
immutable source captures, every raw input, and guidance/script inputs. A parent
receipt may hash the manifest itself after this stage. H0 freeze time is in H0.json;
C end is the native FINAL_ANSWER receipt, not this file-write interval.
