# CI retrospective evidence

Start with RETROSPECTIVE.md. The report freezes the requested creation window at 2026-10-31 23:43:09 UTC, then identifies the later resolution of run #3406 separately.

- runs.csv / runs-final.json: every in-window workflow run and final outcome.
- jobs-final.json: every job, including old attempts.
- failed-jobs.csv / failure-inventory.json: all 150 failed jobs and failing steps.
- failure-cases.csv / failure-cases.json: all 202 printed failed-test entries; JSON keeps full failure blocks.
- failed-job-logs/: complete provider logs, named by job ID.
- commits.json / commit-patches/: 157 in-window reachable commits, full messages, parents, changed paths and patches. Merge ownership is distinct from original authorship.
- execution-profiles.json / stories/: claim provenance and original/last retained plans, including removed plans recovered from Git.
- cursor-process-calls.json, claude-process-calls.json, codex-process-excerpts.json: relevant native tool calls, proof/completion observations and exact human directions. Cursor exports do not include every tool result; provider logs and observer evidence supplement them.
- transcripts/: readable text extracts with original native line numbers.
- process-extracts/: selected original delegation/repair briefs.
- observer-evidence/: read-only snapshots of retained registration/coverage/completion and event records; no observers were acknowledged or stopped by this review.

The original collection scripts are included for reproducibility. No product repair, CI rerun or branch publication was performed by the retrospective.
