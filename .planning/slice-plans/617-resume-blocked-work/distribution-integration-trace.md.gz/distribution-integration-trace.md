# Distribution integration focused consumer trace

Pinned main: 91f32d39061d16793a190c5d9d9f2a6b26534fc7; accepted branch HEAD: 071122f6bd04602427934d3d526e317062b15ef4.
Source scope: path-only merge adaptations; existing held/RPC runtime bytes remain identical.

## Own path adaptations, separate from published main moves

- PLAN conflict: preserve HEAD execution record; adopt Distribution local resource link. Root later settled source-freshness paragraph.
- Distribution/src/skills/dough-execute-plan/scripts/blocked-execution-test-fixtures.mjs: fakeCodex import adds one parent level to leave Distribution.
- Distribution/tests/support/blocked-execution-native-project.mjs: repository source root ../../..; closure reader and moduleRoot include Distribution.
- Distribution/tests/blocked-execution-native.mjs: usage string names relocated entry.
- dashboard/server/hosts/codex/rpc.ts: shared CodexConnection import and NativeRefusal export point to Distribution/src.
- All other 23 file-location resolutions and the broad Distribution migration are the pinned upstream layout; no unrelated upstream implementation edits.

## Direct spec imports at current paths

### dashboard/backend-tests: 14 direct import references
- dashboard/backend-tests/launches/agent-launch-codex-creation-boundary.spec.ts:11: import type { FakeCodex } from "../../tests/support/fakeCodex.ts";
- dashboard/backend-tests/launches/agent-launch-codex-startup.spec.ts:18: } from "../../tests/support/fakeCodex.ts";
- dashboard/backend-tests/launches/agent-launch-duplicate.spec.ts:13: import type { FakeCodex } from "../../tests/support/fakeCodex.ts";
- dashboard/backend-tests/launches/agent-launch-follow-up-codex.spec.ts:19: import type { FakeCodex } from "../../tests/support/fakeCodex.ts";
- dashboard/backend-tests/launches/agent-launch-start-session-identity.spec.ts:16: import type { FakeCodex } from "../../tests/support/fakeCodex.ts";
- dashboard/backend-tests/sessions/agent-launch-codex-observation-sharing.spec.ts:7: import type { FakeCodex } from "../../tests/support/fakeCodex.ts";
- dashboard/backend-tests/sessions/agent-launch-codex-observation-status.spec.ts:8: import { installFakeCodex } from "../../tests/support/fakeCodex.ts";
- dashboard/backend-tests/sessions/agent-launch-codex-observation-wait.spec.ts:7: import type { FakeCodex } from "../../tests/support/fakeCodex.ts";
- dashboard/backend-tests/sessions/agent-launch-session-options.spec.ts:21: } from "../../tests/support/fakeCodex.ts";
- dashboard/backend-tests/sessions/agent-launch-sessions-listing.spec.ts:21: import { installFakeCodex } from "../../tests/support/fakeCodex.ts";
- dashboard/backend-tests/sessions/final-report-codex.spec.ts:13: } from "../../tests/support/fakeCodex.ts";
- dashboard/backend-tests/sessions/sessions-replay.spec.ts:11: import { installFakeCodex } from "../../tests/support/fakeCodex.ts";
- dashboard/backend-tests/terminals/agent-terminal-codex-close.spec.ts:18: import { installFakeCodex } from "../../tests/support/fakeCodex.ts";
- dashboard/backend-tests/terminals/agent-terminal-codex.spec.ts:31: import { fakeCodexHost } from "../../tests/support/fakeCodex.ts";

### dashboard/tests: 1 direct import references
- dashboard/tests/launches/agent-launch-codex-model.spec.ts:12: import type { FakeCodex } from "../support/fakeCodex.ts";

### e2e: 3 direct import references
- e2e/intent/intent-story-changes-landed-run.spec.ts:34: import type { FakeCodex } from "../../dashboard/tests/support/fakeCodex.ts";
- e2e/launches/agent-launch-codex-creation.spec.ts:14: import type { FakeCodex } from "../../dashboard/tests/support/fakeCodex.ts";
- e2e/sessions/project-restored-session.spec.ts:7: import { installFakeCodex } from "../../dashboard/tests/support/fakeCodex.ts";

### dashboard/frontend-tests: 0 direct import references

## Runtime production callers

CodexConnection -> dashboard CodexRpc -> options, launch/conversation, sessions, recovery, startupSettings, done, blank, finalReport and codexHost.
Selected backend cases independently observe launch/input ordering and identity; overlap suppression/retry; startup recovery; status/provenance/missing target; sharing/wait cancellation; final reports; listing/replay; terminal resume/detach/teardown.
Selected integrated case observes discovered model selection through native creation.
Selected e2e cases observe landed review/Intent round trip; creation identity loss/reconciliation; passive restored project preparation.
Frontend group has no import or changed source boundary and is not selected.

## Runtime closure with source mapping

- src/skills/dough-execute-plan/scripts/blocked-execution-attention.mjs -> Distribution/src/skills/dough-execute-plan/scripts/blocked-execution-attention.mjs: bytes unchanged
- src/skills/dough-execute-plan/scripts/blocked-execution-codex.mjs -> Distribution/src/skills/dough-execute-plan/scripts/blocked-execution-codex.mjs: bytes unchanged
- src/skills/dough-execute-plan/scripts/blocked-execution-delivery.mjs -> Distribution/src/skills/dough-execute-plan/scripts/blocked-execution-delivery.mjs: bytes unchanged
- src/skills/dough-execute-plan/scripts/blocked-execution-rearm.mjs -> Distribution/src/skills/dough-execute-plan/scripts/blocked-execution-rearm.mjs: bytes unchanged
- src/skills/dough-execute-plan/scripts/blocked-execution-recovery.mjs -> Distribution/src/skills/dough-execute-plan/scripts/blocked-execution-recovery.mjs: bytes unchanged
- src/skills/dough-execute-plan/scripts/blocked-execution-store.mjs -> Distribution/src/skills/dough-execute-plan/scripts/blocked-execution-store.mjs: bytes unchanged
- src/skills/dough-execute-plan/scripts/blocked-execution-worker.mjs -> Distribution/src/skills/dough-execute-plan/scripts/blocked-execution-worker.mjs: bytes unchanged
- src/skills/dough-execute-plan/scripts/blocked-execution.mjs -> Distribution/src/skills/dough-execute-plan/scripts/blocked-execution.mjs: bytes unchanged
- src/skills/dough-execute-plan/scripts/ci-direct-entry.mjs -> Distribution/src/skills/dough-execute-plan/scripts/ci-direct-entry.mjs: bytes unchanged
- src/skills/dough-execute-plan/scripts/codex-rpc.mjs -> Distribution/src/skills/dough-execute-plan/scripts/codex-rpc.mjs: bytes unchanged
- src/skills/dough-execute-plan/scripts/codex-unix-websocket.mjs -> Distribution/src/skills/dough-execute-plan/scripts/codex-unix-websocket.mjs: bytes unchanged

Installed copies remain .agents/skills/dough-execute-plan/scripts and .claude/skills/dough-execute-plan/scripts. No installed copy was hand-synchronized.
Historical full consumer dispositions remain in slice2-consumer-trace.md.gz and are not rewritten.

## E2E terminal proof

Raw proof record: /tmp/seed345-distribution-e2e-proof.json. Phase completed; 5 selected, 5 passed, no retries.
- e2e/intent/intent-story-changes-landed-run.spec.ts: Intent's Review changes link returns a review showing a chosen landed run to Intent's comparison — passed, retry 0, 21835 ms.
- e2e/intent/intent-story-changes-landed-run.spec.ts: a review whose workspace is gone shows its own landed run, which Intent shows too, and Intent's link returns to it from another landed run — passed, retry 0, 18994 ms.
- e2e/launches/agent-launch-codex-creation.spec.ts: lost creation identity persists reconciliation requirement across server restart — passed, retry 0, 5232 ms.
- e2e/launches/agent-launch-codex-creation.spec.ts: confirmation clears pending evidence; legacy reload is truthful and connection loss retains continuation context — passed, retry 0, 5194 ms.
- e2e/sessions/project-restored-session.spec.ts: adding an initially unconfigured retained Codex project prepares its passive service once without starting a conversation — passed, retry 0, 2896 ms.
