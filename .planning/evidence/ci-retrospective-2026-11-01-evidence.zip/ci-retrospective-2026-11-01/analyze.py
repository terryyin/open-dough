import pathlib,json,re,collections,csv,datetime
p=pathlib.Path('/tmp/open-dough-ci-retro-20261101');jobs=json.loads((p/'jobs-all.json').read_text());entries=[]
for j in sorted(jobs,key=lambda j:(j['run_number'],j['run_attempt'],j['name'])):
 if j['conclusion']!='failure':continue
 f=p/f"log-{j['id']}.txt"
 if not f.exists():continue
 raw=f.read_text(errors='replace');lines=[re.sub(r'^\d{4}-\d\d-\d\dT\S+\s','',l) for l in raw.splitlines()]
 flags=[(n+1,l) for n,l in enumerate(lines) if re.search(r'(^FAIL:|^FAIL |^not ok |^ERROR:|OVER BUDGET|^Infrastructure setup:|^Error:|^\s+Error:|ERR_ASSERTION|npm ERR|^  ✘|^  [0-9]+\))',l)]
 fails=[l for n,l in flags if l.startswith(('FAIL:','not ok ','FAIL ','ERROR:','Infrastructure setup:')) or 'OVER BUDGET' in l]
 entries.append({'run':j['run_number'],'attempt':j['run_attempt'],'job':j['name'],'jobId':j['id'],'sha':j['run_sha'],'branch':j['run_branch'],'steps':[s['name'] for s in j['steps'] if s['conclusion']=='failure'],'signals':flags,'tests':fails,'url':j['html_url']})
(p/'failure-inventory.json').write_text(json.dumps(entries,indent=2));
for e in entries:
 print(f"#{e['run']} a{e['attempt']} {e['job']} {e['jobId']} {'; '.join(e['tests'])}")
print('LOGS',len(entries),'of',sum(j['conclusion']=='failure' for j in jobs))
