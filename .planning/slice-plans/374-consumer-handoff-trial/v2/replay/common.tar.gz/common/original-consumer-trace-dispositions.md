# Consumer trace

## Effect terms searched

| Term | Origin |
| --- | --- |
| `.planning/slice-plans/373-production-policy-ci-time/coverage-map.md` | changed path |
| `coverage-map.md` | basename of `.planning/slice-plans/373-production-policy-ci-time/coverage-map.md` |
| `dashboard/tests/boundary/production-qualification.spec.ts` | changed path |
| `production-qualification.spec.ts` | basename of `dashboard/tests/boundary/production-qualification.spec.ts` |
| `dashboard/tests/support/productionQualificationFixture.ts` | changed path |
| `productionQualificationFixture.ts` | basename of `dashboard/tests/support/productionQualificationFixture.ts` |
| `dashboard/tests/support/productionUpdatePolicies.ts` | changed path |
| `productionUpdatePolicies.ts` | basename of `dashboard/tests/support/productionUpdatePolicies.ts` |
| `productionUpdatePolicies` | supplied |
| `qualifyPublishedRange` | supplied |
| `policy coverage` | supplied |
| `qualificationFixture` | supplied |
| `backgroundPackWriterGit` | supplied |
| `productionUpdateJourney` | supplied |
| `dashboard/tests/boundary/production-qualification.spec` | import path of `dashboard/tests/boundary/production-qualification.spec.ts` |
| `production-qualification.spec` | import path of `dashboard/tests/boundary/production-qualification.spec.ts` |
| `dashboard/tests/support/productionUpdatePolicies` | import path of `dashboard/tests/support/productionUpdatePolicies.ts` |
| `.planning/slice-plans/373-production-policy-ci-time/coverage-map` | import path of `.planning/slice-plans/373-production-policy-ci-time/coverage-map.md` |
| `coverage-map` | import path of `.planning/slice-plans/373-production-policy-ci-time/coverage-map.md` |
| `dashboard/tests/support/productionQualificationFixture` | import path of `dashboard/tests/support/productionQualificationFixture.ts` |
| `productionQualificationFixture` | import path of `dashboard/tests/support/productionQualificationFixture.ts` |
| `pushExclusions` | declared in `dashboard/tests/boundary/production-qualification.spec.ts` |
| `developmentRoot` | declared in `dashboard/tests/boundary/production-qualification.spec.ts` |
| `baseline` | declared in `dashboard/tests/boundary/production-qualification.spec.ts`; in 227 files, too broad to list consumers by itself; supply it as a `--term` to list them |
| `selected` | declared in `dashboard/tests/boundary/production-qualification.spec.ts`; in 783 files, too broad to list consumers by itself; supply it as a `--term` to list them |
| `env` | declared in `dashboard/tests/boundary/production-qualification.spec.ts`; in 934 files, too broad to list consumers by itself; supply it as a `--term` to list them |
| `encoding` | declared in `dashboard/tests/boundary/production-qualification.spec.ts`; in 142 files, too broad to list consumers by itself; supply it as a `--term` to list them |
| `qualifies` | declared in `dashboard/tests/boundary/production-qualification.spec.ts` |
| `changed` | declared in `dashboard/tests/boundary/production-qualification.spec.ts`; in 1067 files, too broad to list consumers by itself; supply it as a `--term` to list them |
| `qualifying` | declared in `dashboard/tests/boundary/production-qualification.spec.ts` |
| `node:child_process` | removed from `dashboard/tests/boundary/production-qualification.spec.ts`:5; in 260 files, too broad to list consumers by itself; supply it as a `--term` to list them |
| `../support/publishedMainFixture.ts` | removed from `dashboard/tests/boundary/production-qualification.spec.ts`:19 |
| `../support/repositoryRoot.ts` | removed from `dashboard/tests/boundary/production-qualification.spec.ts`:20 |
| `paths-ignore:\n      - ".planning/**"\n      - "docs/**"\n` | removed from `dashboard/tests/boundary/production-qualification.spec.ts`:23 |
| `utf8` | removed from `dashboard/tests/boundary/production-qualification.spec.ts`:27; in 673 files, too broad to list consumers by itself; supply it as a `--term` to list them |
| `inspections` | removed from `dashboard/tests/boundary/production-qualification.spec.ts`:29 |
| `git` | removed from `dashboard/tests/boundary/production-qualification.spec.ts`:127; in 1960 files, too broad to list consumers by itself; supply it as a `--term` to list them |
| `--exec-path` | removed from `dashboard/tests/boundary/production-qualification.spec.ts`:132 |
| `git-exec-path` | removed from `dashboard/tests/boundary/production-qualification.spec.ts`:135 |
| `rev-parse --absolute-git-dir)/objects/pack` | removed from `dashboard/tests/boundary/production-qualification.spec.ts`:147 |
| `$pack` | removed from `dashboard/tests/boundary/production-qualification.spec.ts`:150 |
| `$pack/racing-$((n % 20))` | removed from `dashboard/tests/boundary/production-qualification.spec.ts`:151 |
| `${real}/git` | removed from `dashboard/tests/boundary/production-qualification.spec.ts`:157 |
| `publishedPolicy` | declared in `dashboard/tests/support/productionUpdatePolicies.ts` |
| `paths-ignore:\n      - ".planning/**"\n      - "extra/**"\n` | removed from `dashboard/tests/support/productionUpdatePolicies.ts`:60 |
| `docs/policy.md` | removed from `dashboard/tests/support/productionUpdatePolicies.ts`:65 |
| `# Policy\n` | removed from `dashboard/tests/support/productionUpdatePolicies.ts`:65 |
| `MAIN F` | removed from `dashboard/tests/support/productionUpdatePolicies.ts`:66 |
| `Policy F` | removed from `dashboard/tests/support/productionUpdatePolicies.ts`:68 |
| `docs/h.md` | removed from `dashboard/tests/support/productionUpdatePolicies.ts`:89 |
| `# H\n` | removed from `dashboard/tests/support/productionUpdatePolicies.ts`:89 |
| `Document H` | removed from `dashboard/tests/support/productionUpdatePolicies.ts`:89 |

## Scope

Whole checkout at `2f8cb0e23717`, including uncommitted and untracked files: 4097 tracked and untracked non-ignored files searched with fixed-string, case-insensitive matching.

Changed files not searched: `.planning/slice-plans/373-production-policy-ci-time/coverage-map.md`, `dashboard/tests/boundary/production-qualification.spec.ts`, `dashboard/tests/support/productionQualificationFixture.ts`, `dashboard/tests/support/productionUpdatePolicies.ts`.

## Located consumers

Kinds are path hints for inspection; each file appears once. Fill every Disposition with `run`, `reused` or `excluded: <reason the effect does not reach its boundary>`.

### Production

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `.agents/skills/dough-execute-plan/scripts/ci-integrated-state.mjs` | `qualifies` | 24: `` // waiting). An ignored-only (`not_required`) B qualifies only while its `` |excluded: common-word/retired-marker substring match; separate CI/backlog logic has no dependency on changed dashboard test support |
| `.agents/skills/dough-product-backlog/scripts/product-backlog-add.mjs` | `Document H` | 52: `// A whole-document home (no anchor, such as a plan-homed correction's own` |excluded: common-word/retired-marker substring match; separate CI/backlog logic has no dependency on changed dashboard test support |
| `.agents/skills/dough-product-backlog/scripts/product-backlog-home-reader.mjs` | `Document H` | 77: `// reader must report. Identity wins for whole-document homes; otherwise keep` |excluded: common-word/retired-marker substring match; separate CI/backlog logic has no dependency on changed dashboard test support |
| `.claude/skills/dough-execute-plan/scripts/ci-integrated-state.mjs` | `qualifies` | 24: `` // waiting). An ignored-only (`not_required`) B qualifies only while its `` |excluded: common-word/retired-marker substring match; separate CI/backlog logic has no dependency on changed dashboard test support |
| `.claude/skills/dough-product-backlog/scripts/product-backlog-add.mjs` | `Document H` | 52: `// A whole-document home (no anchor, such as a plan-homed correction's own` |excluded: common-word/retired-marker substring match; separate CI/backlog logic has no dependency on changed dashboard test support |
| `.claude/skills/dough-product-backlog/scripts/product-backlog-home-reader.mjs` | `Document H` | 77: `// reader must report. Identity wins for whole-document homes; otherwise keep` |excluded: common-word/retired-marker substring match; separate CI/backlog logic has no dependency on changed dashboard test support |
| `dashboard/server/launchRecordDocument.ts` | `Document H` | 4: `` // `./projectFolders.ts`. One JSON document holds each catalog project's `` |excluded: retired marker text matches unrelated comment/policy prose; no import or invocation of the changed test support |
| `dashboard/server/productionDeployment.mjs` | `developmentRoot` | 15: `* @param {string} developmentRoot` |run: real npm/Vite watcher/deployment suite; published selection, staging, serving and cleanup unchanged |
| `dashboard/server/productionQualification.mjs` | `qualifyPublishedRange`, `pushExclusions`, `developmentRoot`, `qualifies`, `qualifying`, `inspections` | 29: `function pushExclusions(workflow, commit) {` |run: all four real-Git qualification cases plus actual watcher qualification; implementation unchanged |
| `dashboard/src/LaunchSessionPolicy.tsx` | `Policy F` | 127: `` `One-shot is not offered: the installed skills in this project do not start ${workflowName} with a session policy for this host.`, `` |excluded: retired marker text matches unrelated comment/policy prose; no import or invocation of the changed test support |
| `scripts/watch-dashboard.mjs` | `qualifyPublishedRange`, `developmentRoot`, `qualifies` | 15: `import { qualifyPublishedRange } from "../dashboard/server/productionQualification.mjs";` |run: actual normal update journey and ordinary watcher/failure/refusal consumers; implementation unchanged |
| `src/install/open-dough-register-hooks-merge.mjs` | `Policy F` | 1: `// Host-hook merge policy for Open Dough CI registration.` |excluded: retired marker text matches unrelated comment/policy prose; no import or invocation of the changed test support |
| `src/skills/dough-execute-plan/scripts/ci-integrated-state.mjs` | `qualifies` | 24: `` // waiting). An ignored-only (`not_required`) B qualifies only while its `` |excluded: common-word/retired-marker substring match; separate CI/backlog logic has no dependency on changed dashboard test support |
| `src/skills/dough-product-backlog/scripts/product-backlog-add.mjs` | `Document H` | 52: `// A whole-document home (no anchor, such as a plan-homed correction's own` |excluded: common-word/retired-marker substring match; separate CI/backlog logic has no dependency on changed dashboard test support |
| `src/skills/dough-product-backlog/scripts/product-backlog-home-reader.mjs` | `Document H` | 77: `// reader must report. Identity wins for whole-document homes; otherwise keep` |excluded: common-word/retired-marker substring match; separate CI/backlog logic has no dependency on changed dashboard test support |

### Test

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `dashboard/tests/agent-launch-session-choices.spec.ts` | `Policy F` | 44: `"One-shot is not offered: the installed skills in this project do not start refinement with a session policy for this host.",` |excluded: common-word/retired-marker substring or unchanged helper import; no changed qualification fixture/policy journey contract reaches this scenario |
| `dashboard/tests/auto-refresh-branches.spec.ts` | `qualifies` | 61: `// The card qualifies its count briefly; the exact branch head is in the` |excluded: common-word/retired-marker substring or unchanged helper import; no changed qualification fixture/policy journey contract reaches this scenario |
| `dashboard/tests/boundary/accepted-attempt-settlement.spec.ts` | `../support/repositoryRoot.ts` | 13: `import { repoRoot } from "../support/repositoryRoot.ts";` |excluded: only same unchanged repositoryRoot/publishedMainFixture import; extracted qualification support is not imported by this scenario |
| `dashboard/tests/boundary/agent-launch-acceptance-kept-first-cleanup.spec.ts` | `../support/repositoryRoot.ts` | 15: `import { repoRoot } from "../support/repositoryRoot.ts";` |excluded: only same unchanged repositoryRoot/publishedMainFixture import; extracted qualification support is not imported by this scenario |
| `dashboard/tests/boundary/agent-launch-done-codex-races.spec.ts` | `../support/repositoryRoot.ts` | 7: `import { repoRoot } from "../support/repositoryRoot.ts";` |excluded: only same unchanged repositoryRoot/publishedMainFixture import; extracted qualification support is not imported by this scenario |
| `dashboard/tests/boundary/agent-launch-options-boundary.spec.ts` | `../support/repositoryRoot.ts` | 23: `import { repoRoot } from "../support/repositoryRoot.ts";` |excluded: only same unchanged repositoryRoot/publishedMainFixture import; extracted qualification support is not imported by this scenario |
| `dashboard/tests/boundary/agent-launch-options-groups.spec.ts` | `../support/repositoryRoot.ts` | 21: `import { repoRoot } from "../support/repositoryRoot.ts";` |excluded: only same unchanged repositoryRoot/publishedMainFixture import; extracted qualification support is not imported by this scenario |
| `dashboard/tests/boundary/agent-launch-update-worktree-retry.spec.ts` | `../support/repositoryRoot.ts` | 36: `import { repoRoot } from "../support/repositoryRoot.ts";` |excluded: only same unchanged repositoryRoot/publishedMainFixture import; extracted qualification support is not imported by this scenario |
| `dashboard/tests/boundary/agent-launch-workspace-reporting-support.spec.ts` | `../support/repositoryRoot.ts` | 13: `import { repoRoot } from "../support/repositoryRoot.ts";` |excluded: only same unchanged repositoryRoot/publishedMainFixture import; extracted qualification support is not imported by this scenario |
| `dashboard/tests/boundary/cursor-runner-build-proof.spec.ts` | `../support/repositoryRoot.ts` | 29: `import { repoRoot } from "../support/repositoryRoot.ts";` |excluded: only same unchanged repositoryRoot/publishedMainFixture import; extracted qualification support is not imported by this scenario |
| `dashboard/tests/boundary/cursor-runner-discarded-start.spec.ts` | `../support/repositoryRoot.ts` | 20: `import { repoRoot } from "../support/repositoryRoot.ts";` |excluded: only same unchanged repositoryRoot/publishedMainFixture import; extracted qualification support is not imported by this scenario |
| `dashboard/tests/boundary/cursor-runner-environment.spec.ts` | `../support/repositoryRoot.ts` | 24: `import { repoRoot } from "../support/repositoryRoot.ts";` |excluded: only same unchanged repositoryRoot/publishedMainFixture import; extracted qualification support is not imported by this scenario |
| `dashboard/tests/boundary/dashboard-scheduling.spec.ts` | `../support/repositoryRoot.ts` | 6: `import { repoRoot } from "../support/repositoryRoot.ts";` |excluded: only same unchanged repositoryRoot/publishedMainFixture import; extracted qualification support is not imported by this scenario |
| `dashboard/tests/boundary/production-publication-fixture.spec.ts` | `../support/publishedMainFixture.ts`, `../support/repositoryRoot.ts` | 7: `import { publishedMainFixture } from "../support/publishedMainFixture.ts";` |excluded: only same unchanged repositoryRoot/publishedMainFixture import; extracted qualification support is not imported by this scenario |
| `dashboard/tests/boundary/production-watcher-refusals.spec.ts` | `../support/publishedMainFixture.ts` | 5: `import { publishedMainFixture } from "../support/publishedMainFixture.ts";` |run: ordinary production consumer command; setup/refusal behavior unchanged |
| `dashboard/tests/boundary/proof-record-entry.spec.ts` | `../support/repositoryRoot.ts` | 4: `import { repoRoot } from "../support/repositoryRoot.ts";` |excluded: only same unchanged repositoryRoot/publishedMainFixture import; extracted qualification support is not imported by this scenario |
| `dashboard/tests/boundary/proof-record.spec.ts` | `../support/repositoryRoot.ts` | 4: `import { repoRoot } from "../support/repositoryRoot.ts";` |excluded: only same unchanged repositoryRoot/publishedMainFixture import; extracted qualification support is not imported by this scenario |
| `dashboard/tests/boundary/run-processes.spec.ts` | `../support/repositoryRoot.ts` | 23: `import { repoRoot } from "../support/repositoryRoot.ts";` |excluded: only same unchanged repositoryRoot/publishedMainFixture import; extracted qualification support is not imported by this scenario |
| `dashboard/tests/boundary/serving-modes.spec.ts` | `../support/repositoryRoot.ts` | 34: `import { repoRoot } from "../support/repositoryRoot.ts";` |excluded: only same unchanged repositoryRoot/publishedMainFixture import; extracted qualification support is not imported by this scenario |
| `dashboard/tests/boundary/session-alerts-activation-command.spec.ts` | `../support/repositoryRoot.ts` | 8: `import { repoRoot } from "../support/repositoryRoot.ts";` |excluded: only same unchanged repositoryRoot/publishedMainFixture import; extracted qualification support is not imported by this scenario |
| `dashboard/tests/boundary/start-origin-isolation.spec.ts` | `../support/repositoryRoot.ts` | 18: `import { repoRoot } from "../support/repositoryRoot.ts";` |excluded: only same unchanged repositoryRoot/publishedMainFixture import; extracted qualification support is not imported by this scenario |
| `dashboard/tests/boundary/worktree-release-apply.spec.ts` | `../support/repositoryRoot.ts` | 8: `import { repoRoot } from "../support/repositoryRoot.ts";` |excluded: only same unchanged repositoryRoot/publishedMainFixture import; extracted qualification support is not imported by this scenario |
| `dashboard/tests/branch-slice-progress.spec.ts` | `qualifies` | 62: `// The scan view qualifies the count briefly; the exact branch and` |excluded: common-word/retired-marker substring or unchanged helper import; no changed qualification fixture/policy journey contract reaches this scenario |
| `dashboard/tests/longest-first-boundary` | `production-qualification.spec.ts`, `production-qualification.spec` | 129: `2.7	boundary/production-qualification.spec.ts` |excluded: historical shard weight names unchanged owning spec; weight refresh is explicitly out of scope |
| `dashboard/tests/production-deployment.spec.ts` | `developmentRoot` | 88: `developmentRoot: fixture.development,` |run: ordinary production consumer command; pinned installation/build/preview unchanged |
| `dashboard/tests/production-watcher-failures.spec.ts` | `MAIN F` | 8: `// current main for the next.` |run: ordinary production consumer command; distinct real failure/restoration paths unchanged |
| `dashboard/tests/production-watcher-updates.spec.ts` | `productionUpdatePolicies.ts`, `productionUpdatePolicies`, `productionUpdateJourney` | 17: `productionUpdateJourney,` |run: owning serial spec registers both changed policy steps and unchanged lifecycle cases |
| `dashboard/tests/story-readiness-gaps.spec.ts` | `qualifies` | 169: `test("queued plan navigation follows changed associations and qualifies unsupported, invalid and conflicting source records", async ({` |excluded: common-word/retired-marker substring or unchanged helper import; no changed qualification fixture/policy journey contract reaches this scenario |
| `dashboard/tests/story-review-nothing.spec.ts` | `MAIN F` | 200: `"Trunk could not be fetched (target main from remote origin), so there is no baseline to compare with:",` |excluded: common-word/retired-marker substring or unchanged helper import; no changed qualification fixture/policy journey contract reaches this scenario |
| `dashboard/tests/storyReadinessGaps.ts` | `qualifies` | 72: `// The badge is the scan view's warning; the judgment it qualifies is` |excluded: qualifies describes UI badge text; no production-update fixture dependency |
| `src/skills/dough-execute-plan/scripts/ci-integrated-state-judge.test.mjs` | `Policy F` | 179: `test("integrated evidence is judged only under a policy for an eligible own state, and replaces any recorded one", async () => {` |excluded: common-word/retired-marker substring match; separate CI/backlog logic has no dependency on changed dashboard test support |
| `src/skills/dough-execute-plan/scripts/ci-workflow-path-policy.test.mjs` | `Policy F` | 26: `test("readCiPathIgnorePolicy fails closed for unsupported YAML forms", () => {` |excluded: common-word/retired-marker substring match; separate CI/backlog logic has no dependency on changed dashboard test support |
| `src/skills/dough-execute-plan/scripts/watch-ci-execution-hold.test.mjs` | `inspections` | 82: `let jobInspections = 0;` |excluded: common-word/retired-marker substring match; separate CI/backlog logic has no dependency on changed dashboard test support |
| `src/skills/dough-execute-plan/scripts/watch-ci-execution-startup.test.mjs` | `inspections` | 171: `let jobInspections = 0;` |excluded: common-word/retired-marker substring match; separate CI/backlog logic has no dependency on changed dashboard test support |
| `src/skills/dough-execute-plan/scripts/workspace-publication-admission-refusal.test.mjs` | `Document H` | 133: `// drafted as a whole-document home of its own.` |excluded: common-word/retired-marker substring match; separate CI/backlog logic has no dependency on changed dashboard test support |
| `tests/support/git-publication-native-stream-fields.test.mjs` | `Policy F` | 3: `// on every host, so are a one-shot start's policy flags, a preparation` |excluded: common-word/retired-marker substring or unchanged helper import; no changed qualification fixture/policy journey contract reaches this scenario |
| `tests/support/product-backlog-plan-home.test.mjs` | `Document H` | 112: `test("plan home: a section link to another entry's whole-document home is refused", async (t) => {` |excluded: common-word/retired-marker substring or unchanged helper import; no changed qualification fixture/policy journey contract reaches this scenario |

### Test support or stand-in

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `dashboard/tests/support/productionUpdateJourney.ts` | `productionUpdateJourney`, `pushExclusions`, `paths-ignore:\n      - ".planning/**"\n      - "docs/**"\n`, `inspections` | 20: `productionInspections,` |run: unchanged setup, real replacement observations, shared records and held-build shutdown through owning update spec |
| `dashboard/tests/support/productionWatcher.ts` | `inspections` | 36: `export function productionInspections(home: string) {` |run: unchanged settled skips, independent work counters and same-URL/PID replacement through owning update spec |
| `dashboard/tests/support/publishedMainFixture.ts` | `MAIN F` | 77: `await git("config", "user.name", "Published main fixture");` |run: isolated real-Git fixtures through qualification, update, watcher, failure, refusal and deployment specs |
| `dashboard/tests/support/publishedMainHosts.ts` | `MAIN F` | 1: `// The hosts a production dashboard of a published-main fixture reaches: a` |run: owning update/watcher scenarios use real servers plus unchanged external host stand-ins |
| `tests/fixtures/delivery-evidence/readiness-original-story.md` | `MAIN F` | 110: `dependency agreement, stay distinct domain facts under` |excluded: common-word/retired-marker substring or unchanged helper import; no changed qualification fixture/policy journey contract reaches this scenario |
| `tests/helpers/installed-ci-reuse-fixture.bash` | `Policy F` | 45: `// every installed runtime dependency, even when unreadable policy falls back.` |excluded: common-word/retired-marker substring or unchanged helper import; no changed qualification fixture/policy journey contract reaches this scenario |
| `tests/support/git-publication-native-stream-one-shot.mjs` | `Policy F` | 101: `// The policy fields plus CI coverage, for automatic landing.` |excluded: common-word/retired-marker substring or unchanged helper import; no changed qualification fixture/policy journey contract reaches this scenario |
| `tests/support/product-backlog-fixture.mjs` | `Document H` | 174: `` // How many times a document holds `needle`, for the tests that establish an `` |excluded: common-word/retired-marker substring or unchanged helper import; no changed qualification fixture/policy journey contract reaches this scenario |
| `tests/support/product-backlog-refresh-fixture.mjs` | `Document H` | 21: `// Where each document has already been renamed or moved to, before any run.` |excluded: common-word/retired-marker substring or unchanged helper import; no changed qualification fixture/policy journey contract reaches this scenario |

### Journey or feature

none found

### Guidance reader

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `.agents/skills/collect-client-feedback/SKILL.md` | `qualifying` | 130: `qualifying use. For each execution, select only requests whose stated project` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `.agents/skills/dough-execute-plan/manuals/custom-ci-queue.md` | `MAIN F` | 37: `Actual failures remain failures, and a current real pending retry supersedes an` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `.agents/skills/dough-execute-plan/manuals/reuse-ci.md` | `qualifies`, `qualifying` | 13: `validation when those inputs change. No tree/parent equivalence qualifies.` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `.agents/skills/dough-execute-plan/references/execution-decisions.md` | `MAIN F` | 47: `responsibility, or evidence invalidating the selected candidate or domain fit;` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `.claude/skills/dough-execute-plan/manuals/custom-ci-queue.md` | `MAIN F` | 37: `Actual failures remain failures, and a current real pending retry supersedes an` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `.claude/skills/dough-execute-plan/manuals/reuse-ci.md` | `qualifies`, `qualifying` | 13: `validation when those inputs change. No tree/parent equivalence qualifies.` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `.claude/skills/dough-execute-plan/references/execution-decisions.md` | `MAIN F` | 47: `responsibility, or evidence invalidating the selected candidate or domain fit;` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `.planning/seeds/SEED-171-production-policy-ci-time.md` | `policy coverage` | 5: `# Cheaper production-watcher policy coverage` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `.planning/slice-plans/373-production-policy-ci-time/PLAN.md` | `coverage-map.md`, `production-qualification.spec.ts`, `productionUpdatePolicies.ts`, `productionUpdatePolicies`, `policy coverage`, `productionUpdateJourney`, `production-qualification.spec`, `coverage-map`, `qualifying`, `Policy F` | 1: `# Cheaper production-watcher policy coverage` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `CHANGELOG.md` | `qualifying`, `MAIN F` | 13: `Under ADR 0005, unchanged Codex, Cursor and Claude Code discovery, installation, hook registration and host ownership mechanisms reuse their existing integrati…` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `dashboard/COMMANDS.md` | `qualifying`, `inspections` | 8: `` \| `npm run watch:dashboard`     \| Build and serve origin's published `main` commit at `http://127.0.0.1:4173/`, and follow later qualifying commits. \| `` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `dashboard/README.md` | `qualifying` | 144: `` separate checkout from qualifying commits published on origin's `main`. `` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `dashboard/STORY-PREPARATION.md` | `qualifies` | 19: `qualifies the count "From story branch; not in trunk." and the detail names it` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `docs/adrs/0002-software-development-lifecycle-principles-accepted.md` | `MAIN F` | 159: `are distinct domain facts, each with one authoritative repository record.` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `docs/adrs/0008-project-dashboard-domain-and-architecture-accepted.md` | `MAIN F` | 190: `Feature and structural perspectives remain future possibilities, not` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `docs/adrs/0009-git-branching-and-integration.md` | `MAIN F` | 86: `branch may remain for the duration of execution; it need not be recreated for` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `docs/dashboard-repository-state.md` | `MAIN F` | 95: `and close multi-agent collaboration remain future scope.` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `docs/maintainer/empirical-process-control-research.md` | `qualifies`, `qualifying` | 708: `- It qualifies "evaluation rules fixed before scoring": the rules were fixed` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `docs/maintainer/execution-publication-design.md` | `MAIN F` | 47: `The startup command imports backlog domain functions rather than parsing CLI` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `docs/maintainer/finding-names.md` | `qualifying` | 35: `ordinary qualifying use, not duplicate implementation stories. Observation` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `docs/maintainer/findings/ODF-121.md` | `Policy F` | 67: `- Observed effect: A reported GitHub request failure ended the worker without a CI verdict; subsequent accepted revisions had no notification coverage. Install…` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `docs/maintainer/findings/ODF-142.md` | `qualifying` | 54: `**Response-observation gap (2026-10-25):** No encountered post-response execution reports the qualifying abbreviated-base comparison; ordinary full-SHA publica…` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `docs/maintainer/findings/ODF-228.md` | `Policy F` | 44: `- Inference: qualified. Neither the execution guidance nor the delegation briefs stated a local-proof policy for a shared host; the coordinator set one only af…` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `docs/maintainer/findings/ODF-244.md` | `qualifies` | 8: `- **References / identity:** distinct; relationship to nearby identities qualified Source explicitly qualifies relationship with ODF-190. Retired ODF-165 invol…` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `docs/maintainer/findings/ODF-264.md` | `MAIN F` | 23: `` - **Correction:** SEED-010#name-required-passages-in-boundary-rows (story-branch commit `0a944675`) made each row also name the passages its own passages requi… `` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `docs/maintainer/findings/ODF-281.md` | `MAIN F` | 5: `**Meaning:** Per-slice estimates omit the complete implementation, refactoring, proof or resource-investigation journey and repeatedly remain five-minute hypot…` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `docs/maintainer/findings/ODF-323.md` | `qualifying` | 74: `open; no qualifying observation or successful retry is invented.` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `docs/maintainer/findings/ODF-354.md` | `qualifying` | 7: `` **Follow-up:** Response integrated and first released in `v0.3.73`; first ordinary qualifying amendment after adoption remains unobserved, not resolved. Dated … `` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `docs/maintainer/findings/ODF-369.md` | `inspections` | 80: `- Effort vs no-check baseline: 2 useful liveness inspections; diagnosis inside` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `docs/maintainer/near-term-watch-list.md` | `qualifying` | 42: `effectiveness or qualifying use.` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `docs/maintainer/project-test-findings.md` | `productionUpdatePolicies.ts`, `productionUpdatePolicies` | 46: `` **Measured allocation:** Branch CI run 40185201080 (`61d16b66`): Node shares under the duration deal, predicted 498.5 job-seconds each, measured 643.6 / 399.1 … `` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `ProjectFindings.md` | `qualifying` | 18: `` **Maintenance assessment (2026-10-25):** Select one new project response: SEED-151#balance-test-shares (since implemented and closed; story recoverable at `8dd… `` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `src/skills/dough-execute-plan/manuals/custom-ci-queue.md` | `MAIN F` | 37: `Actual failures remain failures, and a current real pending retry supersedes an` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `src/skills/dough-execute-plan/manuals/reuse-ci.md` | `qualifies`, `qualifying` | 13: `validation when those inputs change. No tree/parent equivalence qualifies.` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
| `src/skills/dough-execute-plan/references/execution-decisions.md` | `MAIN F` | 47: `responsibility, or evidence invalidating the selected candidate or domain fit;` |excluded: guidance/history/planning prose is not a runtime consumer of changed tests; no skill, product contract or documented command changed |
