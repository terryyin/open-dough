# Consumer trace

## Effect terms searched

| Term | Origin |
| --- | --- |
| `Distribution/tests/native-comparison/paused-supplier/case.bash` | changed path |
| `case.bash` | basename of `Distribution/tests/native-comparison/paused-supplier/case.bash` |
| `Distribution/tests/native-comparison/paused-supplier/owned-proof.mjs` | changed path |
| `owned-proof.mjs` | basename of `Distribution/tests/native-comparison/paused-supplier/owned-proof.mjs` |
| `Distribution/tests/support/native-codex-owned-proof.test.mjs` | changed path |
| `native-codex-owned-proof.test.mjs` | basename of `Distribution/tests/support/native-codex-owned-proof.test.mjs` |
| `Distribution/tests/support/native-comparison-retain.sh` | changed path |
| `native-comparison-retain.sh` | basename of `Distribution/tests/support/native-comparison-retain.sh` |
| `case_agent_proof` | supplied |
| `ownedWorkerProof` | supplied |
| `turn-4-agent-proof` | supplied |
| `native_comparison_sessions_root` | supplied |
| `native_comparison_retain_sessions` | supplied |
| `native_comparison_run_case` | supplied |
| `native_comparison_pair_observe_arm` | supplied |
| `native_comparison_case_files` | supplied |
| `native_comparison_pair` | supplied |
| `native_comparison_basis_commit` | supplied |
| `native_comparison_basis_observe` | supplied |
| `native_codex_isolate` | supplied |
| `native_comparison_thread` | supplied |

## Scope

Whole checkout at `2517383f7226`, including uncommitted and untracked files: 6522 tracked and untracked non-ignored files searched with fixed-string, case-insensitive matching.

Changed files not searched: `Distribution/tests/native-comparison/paused-supplier/case.bash`, `Distribution/tests/native-comparison/paused-supplier/owned-proof.mjs`, `Distribution/tests/support/native-codex-owned-proof.test.mjs`, `Distribution/tests/support/native-comparison-retain.sh`.

## Located consumers

Kinds are path hints for inspection; each file appears once. Fill every Disposition with `run`, `reused` or `excluded: <reason the effect does not reach its boundary>`.

### Production

none found

### Test

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `Distribution/tests/native-comparison-doughnut-title-precedence.sh` | `case.bash` | 15: `source "${case_path}/case.bash"` |excluded: directly observes the other case; it never invokes paused-supplier proof or retention |
| `Distribution/tests/native-comparison-incomplete.sh` | `Distribution/tests/native-comparison/paused-supplier/case.bash`, `case.bash`, `native_comparison_pair` | 79: `native_comparison_pair_fixture "${source_dir}" "${work}"` |run: current focused 6-check command, terminal 16312; stopped/refused arms and source prerequisites |
| `Distribution/tests/native-comparison-pairs.sh` | `native_comparison_pair` | 23: `native_comparison_pair_fixture "${source_dir}" "${work}"` |run: current focused 6-check command, terminal 16312; substitute pairs, assessment and retained sessions |
| `Distribution/tests/native-comparison-paused-supplier.sh` | `turn-4-agent-proof`, `native_comparison_run_case` | 36: `if ! NATIVE_AGENT_PAUSED_SUPPLIER_RULE=completion native_comparison_run_case \` |run: current focused 6-check command, terminal 16312; observe/retain/assess journey and rejected proof |
| `Distribution/tests/native-comparison-refresh.sh` | `native_comparison_pair` | 24: `native_comparison_pair_fixture "${source_dir}" "${work}"` |run: current focused 6-check command, terminal 16312; complete case input identity, immutable records and recovered basis |
| `Distribution/tests/native-comparison.md` | `case.bash` | 14: `` fixture and observer `case.bash`, and the separate assessor `assess.bash`, `` |excluded: describes the same case/observer separation; no changed callable contract or assessment criterion |
| `Distribution/tests/native-comparison.sh` | `native_comparison_run_case`, `native_comparison_pair`, `native_comparison_basis_observe` | 75: `where=() native_comparison_pair_baseline='' native_comparison_pair_candidate=''` |run: current focused 6-check command, terminal 16312; catalog entry plus substitute pair/incomplete/refresh invocations |
| `Distribution/tests/native-comparison/doughnut-title-precedence/assess.bash` | `case.bash` | 4: `# and thread, and case.bash's fields from the recorded test runs and the final` |excluded: judges the other case and never consumes paused-supplier proof |
| `Distribution/tests/native-comparison/doughnut-title-precedence/case.md` | `case.bash` | 74: `` `case.bash` fetches the revision into the arm's `workspace`, a fresh `` |excluded: documents the other case |
| `Distribution/tests/native-comparison/doughnut-title-precedence/comparisons/20261114T045440-26b0.txt` | `case.bash` | 16: `case-input-hash: d19754c834249cda4677bf3f2a2b3daff87fce3157d13e8d7d7177b5766ab8f9 tests/native-comparison/doughnut-title-precedence/case.bash` |excluded: immutable historical record of the other case basis |
| `Distribution/tests/native-comparison/paused-supplier/assess.bash` | `case.bash`, `turn-4-agent-proof` | 4: `# thread, and case.bash's turn-N fields. Turns 1–3 follow the supplier's` |run: unchanged criterion exercised by current focused journey and proof counterexamples; reused saved-record reassessment for native delegated evidence |
| `Distribution/tests/native-comparison/paused-supplier/case.md` | `case.bash` | 53: `` `case.bash` materializes `remote.git` and the execution checkout `` |excluded: documentation only; coordinator owns current comparison/evidence wording curation |
| `Distribution/tests/native-comparison/paused-supplier/comparisons/20261114T045440-40bf.txt` | `case.bash` | 27: `case-input-hash: 48229315c6fa3762cd0f876555ad8068c50c99b7f638234433386985552d8668 tests/native-comparison/paused-supplier/case.bash` |excluded: immutable historical record of its own earlier case basis |
| `Distribution/tests/native-comparison/paused-supplier/comparisons/20261114T102744-1921.txt` | `Distribution/tests/native-comparison/paused-supplier/case.bash`, `case.bash`, `Distribution/tests/support/native-comparison-retain.sh`, `native-comparison-retain.sh` | 26: `case-input-hash: 4aee26c648f88dab7fdd692d1f1e3f5f4fea60c46b03e621887b6d8a7dafe055 Distribution/tests/native-comparison/paused-supplier/case.bash` |reused: immutable original pair record; separate saved-record reassessment corrects observation without rewriting record or claiming token savings |
| `Distribution/tests/native-family-layers.md` | `case.bash` | 70: `` and observer in `case.bash` and its assessor in `assess.bash`, with rejected `` |excluded: documents unchanged comparison layer responsibilities |

### Test support or stand-in

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `Distribution/tests/support/native-codex.sh` | `native_codex_isolate` | 29: `native_codex_isolate=1` |excluded: supplies the unchanged native/substitute route flag; root-selection policy consumes it with identical semantics |
| `Distribution/tests/support/native-comparison-basis.sh` | `native_comparison_case_files`, `native_comparison_basis_commit`, `native_comparison_basis_observe` | 11: `#   native_comparison_basis_commit SOURCE_DIR CASE_DIR PATH...` |run: current pair/refresh checks; new case module automatically belongs to identity and original records keep their basis |
| `Distribution/tests/support/native-comparison-pair-fixture.sh` | `native_comparison_pair` | 10: `#   native_comparison_pair_fixture SOURCE_DIR WORK` |run: current pair/refresh/incomplete checks; explicit substitute CODEX_HOME remains authoritative |
| `Distribution/tests/support/native-comparison-pair-observe.sh` | `native_comparison_pair_observe_arm`, `native_comparison_pair` | 12: `#   native_comparison_pair_observe_arm WORK ARM TURNS EMPTY_EVENTS` |run: current pair checks; observes unchanged assessment status/identity fields |
| `Distribution/tests/support/native-comparison-pair.sh` | `case.bash`, `native_comparison_run_case`, `native_comparison_pair_observe_arm`, `native_comparison_case_files`, `native_comparison_pair`, `native_comparison_basis_commit` | 14: `#   native_comparison_pair CASE SOURCE_DIR WORK RESULTS_DIR` |run: current pair/refresh/incomplete checks; observer and retention both use runner-provided seam |
| `Distribution/tests/support/native-comparison-preflight.sh` | `case.bash`, `native_comparison_pair` | 11: `# (native_comparison_pair_commit, native-comparison-pair.sh, sourced first).` |excluded: sources only case definitions and optional preflight; it never calls case_observe or session-root selection; current incomplete checks still exercise this source path |
| `Distribution/tests/support/native-comparison-run.sh` | `case.bash`, `Distribution/tests/support/native-comparison-retain.sh`, `native-comparison-retain.sh`, `native_comparison_run_case`, `native_comparison_thread` | 10: `# (native-comparison-retain.sh). The assessor and every controller file stay` |run: current paused/pair/refresh/incomplete checks; sources retention before any case observer and records unchanged turn contract |

### Journey or feature

none found

### Guidance reader

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `.planning/slice-plans/621-close-native-comparison-harness-gaps/PLAN.md` | `case.bash`, `native_comparison_pair` | 26: `` server (`case_database_start`, `case.bash` 110) before `migrateTestDB` `` |excluded: independent planning record for the other case, preserved unchanged |

## Inspection and focused proof

The read-only pass covered the incoming proof fallback, both session-root callers, the saved-session reader, the literal ordered command decoder, terminal receipt matching, the unchanged assessor, and all listed consumer purposes. The only refactor candidate was the duplicated native/substitute session-root authority rule. It now has one home in native-comparison-retain.sh; all actual observer callers already source it through native-comparison-run.sh. Standalone case sources use only definitions/events/preflight and acquire no new resource precondition.

Changed during refactoring: case.bash calls the shared root selector; native-comparison-retain.sh owns and uses it; owned-proof.mjs uses the matched quoted substring in its replacement callback (whole equals quoted on that branch). The parser and assessment behavior are unchanged. Native current-turn/current-workspace ownership, coordinator failure precedence, no-stdout-receipt rule, and failed/unknown rejection remain covered by the 4-case Node suite.

Literal current focused command: PATH=/opt/homebrew/bin:$PATH OPEN_DOUGH_TEST_JOBS=1 npm test -- Distribution/tests/support/native-codex-owned-proof.test.mjs Distribution/tests/native-comparison-paused-supplier.sh Distribution/tests/native-comparison.sh Distribution/tests/native-comparison-pairs.sh Distribution/tests/native-comparison-refresh.sh Distribution/tests/native-comparison-incomplete.sh. Terminal session: 16312; completed EXIT 0. The first attempted launch resolved /bin/bash 3.2 and failed before checks; the corrected maintained Bash 5 PATH wrapper above passed all selected checks.

Accepted earlier focused proofs (terminal 40600 and 77842) keep their test setup and asserted boundaries; source wrapper extraction and equivalent parser callback adjustment prompted the focused renewal above. Reused native reassessment locator: /tmp/seed345-owned-proof-reassessment-location.json. It remains evidence of the native wire/ownership path and unchanged assessor, with the refactor checked by current deterministic proof; no new native/API run is required for equivalent wrapper logic.

Expensive proof decision: no paid/native/API/full-suite launch; deterministic named checks only, one job, on the coordinator-confirmed AC machine without competing owned heavy work. Project failure policy applies as written at AGENTS.md#failing-and-flaky-tests. No uncovered code consumer found. Coordinator retains documentation curation, formatting/hook lint, Git/index/publication and final CI.
