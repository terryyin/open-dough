// PRIVATE ONE-OFF PROPOSAL. Do not execute before root's explicit native release.
import assert from "node:assert/strict";
import { existsSync, mkdirSync, readFileSync, realpathSync, renameSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
const source = "/Users/terryyin/git/open-dough/.worktrees/resume-blocked-work-when-it-can-advance";
const support = join(source, "Distribution/tests/support");
const { InvoiceNativeObservation } = await import(join(support, "blocked-execution-workflow-observation.mjs"));
const { completedInvoiceAttention, retainFinalInvoiceSessions } = await import(join(support, "blocked-execution-invoice-history.mjs"));
const { invoiceEvidence, assertPreservedInvoiceWork, assertInvoiceResult } = await import(join(support, "blocked-execution-workflow-project.mjs"));
const { execute, digestFile } = await import(join(source, "Distribution/src/skills/dough-execute-plan/scripts/blocked-execution-store.mjs"));
const original = "/private/tmp/seed345-functional-attention-20261114-1716";
const run = join(original, "run");
const read = (path) => JSON.parse(readFileSync(path, "utf8"));
const initial = read(join(run, "native-start.json"));
const context = read(join(run, "native-context.json"));
const proof = read(join(run, "accepted-local-proof.json"));
const basis = read(join(run, "payload-basis.json"));
const beforeHold = read(join(run, "held-execution/hold.json"));
const threadId = "01a1d958-171d-7403-a976-1562e57a16c2";
const expectedTurns = ["01a1d958-174a-7ac3-9cfa-9c0b8c584c62", "01a1d959-c473-7eb1-a3a5-c9d5c25691b7"];
const insufficientSha = "9a17cb9bc26e1b65245d9dcad00e5e9df34d34852feec6219a25054840e7820d";
const approvedDeadline = Date.parse(process.argv[2] ?? "");
assert.ok(Number.isFinite(approvedDeadline) && approvedDeadline > Date.now(), "Root must supply the prospectively approved absolute deadline");
assert.ok(approvedDeadline - Date.now() <= 15 * 60_000, "At most fifteen minutes of remaining observation");
const results = join(original, "retained-recovery-diagnostic");
assert.equal(existsSync(results), false, "One fresh diagnostic, no automatic retry");
mkdirSync(results, { mode: 0o700 });
const save = (name, value) => writeFileSync(join(results, name), `${JSON.stringify(value, null, 2)}\n`, { mode: 0o600 });
const project = { workspace: realpathSync(join(run, "project")), directory: join(run, "held-execution"), installed: join(run, "project/.agents/skills/dough-execute-plan"), revision: proof.revision, preserved: proof.preserved, acceptedProofArtifact: read(join(run, "accepted-proof-origin.json")) };
const limits = { minutes: (approvedDeadline - Date.now()) / 60_000, tokens: 5_000_000, output: 40_000 };
const observation = new InvoiceNativeObservation(results, context.endpoint, limits);
observation.workspace = project.workspace;
const hold = () => observation.hold(project.directory);
const modulePaths = ["blocked-execution-workflow-observation.mjs", "blocked-execution-invoice-history.mjs", "blocked-execution-invoice-accounting.mjs", "blocked-execution-workflow-ownership.mjs", "blocked-execution-workflow-project.mjs", "native-codex-session.mjs"].map((name) => join(support, name));
modulePaths.push(...["blocked-execution-store.mjs", "codex-rpc.mjs", "codex-unix-websocket.mjs"].map((name) => join(source, "Distribution/src/skills/dough-execute-plan/scripts", name)));
const moduleHashes = Object.fromEntries(modulePaths.map((path) => [path, digestFile(path)]));
const commandAbort = new AbortController();
observation.on("change", () => { if (observation.failure) commandAbort.abort(); });
const ownedCommands = [];
async function command(argv, cleanup = false) {
  const pending = execute(argv[0], argv.slice(1), { cwd: project.workspace, signal: cleanup ? undefined : commandAbort.signal });
  const owned = { pid: pending.child.pid, argv, terminal: false };
  ownedCommands.push(owned); save("owned-controller-commands.json", ownedCommands);
  const closed = new Promise((resolve) => pending.child.once("close", (code, signal) => { Object.assign(owned, { terminal: true, code, signal }); save("owned-controller-commands.json", ownedCommands); resolve(); }));
  try { return await pending; } finally { await closed; }
}
function preserved() {
  assertPreservedInvoiceWork(project);
  assert.equal(basis.sourceRevision, "0bc39b172c9a99bf8b627c0a1d527e3c8983ee61");
  for (const [name, hash] of Object.entries(basis.hashes)) assert.equal(digestFile(join(project.workspace, ".agents/skills", name)), hash, name);
  for (const [path, hash] of Object.entries(moduleHashes)) assert.equal(digestFile(path), hash, "diagnostic dependency unchanged");
  for (const field of ["identity", "owner", "workspace", "branch", "revision", "authority"]) assert.deepEqual(hold().input.execution[field], beforeHold.input.execution[field]);
}
function checkSettings(settings) {
  for (const key of ["model", "modelProvider", "approvalPolicy", "sandbox", "reasoningEffort", "serviceTier"]) assert.deepEqual(settings[key], initial[key], `unchanged native ${key}`);
}
function signal(label, evidence) {
  preserved();
  const next = join(project.workspace, "supplier-next.json");
  writeFileSync(next, `${JSON.stringify(evidence)}\n`);
  renameSync(next, join(project.workspace, "supplier-evidence.json"));
  const digest = digestFile(join(project.workspace, "supplier-evidence.json"));
  save(`event-${label}.json`, { at: new Date().toISOString(), digest, evidence });
  return digest;
}
async function inspect(label) {
  const history = await observation.history(threadId, `${label}-history`);
  await observation.discoverWorkers(threadId);
  const accounting = await observation.accounting(); save(`${label}-accounting.json`, accounting);
  if (observation.failure) throw observation.failure;
  assert.equal(history.historyUnavailable, undefined);
  return { history, accounting };
}
let ownerRecoveryCommands = 0;
try {
  save("protocol.json", { purpose: "one-off same retained execution after valid native attention/rearm; old frozen assay remains incomplete", originalAssayCutoff: "2026-11-14T09:46:29Z conservative admission+30min; original constructor milliseconds not retained", approvedRemainingDeadline: new Date(approvedDeadline).toISOString(), aggregateLimits: { totalTokens: 5_000_000, outputTokens: 40_000 }, priorRequests: 14, priorTokens: 759653, reusedTurns: expectedTurns, subjectRevision: basis.sourceRevision, sourceSha256: digestFile(fileURLToPath(import.meta.url)), moduleHashes, acceptedProofArtifact: project.acceptedProofArtifact });
  assert.equal(context.threadId, threadId); assert.equal(initial.thread.id, threadId);
  assert.equal(beforeHold.generation, "437516ce-61d8-4a59-8e90-9844071f3191");
  assert.equal(beforeHold.worker.ended, true);
  assert.equal(digestFile(join(project.workspace, "supplier-unavailable.json")), insufficientSha);
  assert.equal(existsSync(join(project.workspace, "supplier-evidence.json")), false);
  preserved();
  await observation.connection.initialize({ name: "open_dough_retained_invoice_diagnostic", version: "1" });
  observation.admitThread(threadId, null); observation.trackRollout(initial.thread);
  const settings = await observation.connection.request("thread/resume", { threadId });
  save("native-before-settings.json", settings); checkSettings(settings);
  const before = await inspect("before-recovery");
  assert.deepEqual(before.history.turns.map(({ id, status }) => ({ id, status })), expectedTurns.map((id) => ({ id, status: "completed" })));
  assert.equal(observation.ancestry.size, 1);
  assert.equal(before.accounting.complete, true); assert.equal(before.accounting.requests, 14); assert.equal(before.accounting.observedTotalTokens, 759653);
  const attention = completedInvoiceAttention(observation, hold(), threadId);
  assert.ok(attention); save("reused-native-attention.json", attention);
  const recovery = [...attention.attention.recoveryCommand];
  assert.deepEqual(recovery, ["/opt/homebrew/Cellar/node@24/24.21.0_1/bin/node", join(project.installed, "scripts/blocked-execution.mjs"), "recover", "--directory", project.directory]);
  renameSync(join(project.workspace, "supplier-unavailable.json"), join(project.workspace, "supplier-evidence.json"));
  save("event-restored-insufficient.json", { at: new Date().toISOString(), digest: digestFile(join(project.workspace, "supplier-evidence.json")) });
  assert.equal(digestFile(join(project.workspace, "supplier-evidence.json")), insufficientSha);
  ownerRecoveryCommands++; save("owner-recovery-attempt.json", { argv: recovery, ownerRecoveryCommands });
  save("owner-recovery-result.json", await command(recovery));
  await observation.until(() => { const retained = hold(); if (retained.worker?.ended) throw new Error("Recovered observer ended before qualification"); return retained.phase === "held" && retained; });
  const recovered = await inspect("recovered"); assert.equal(recovered.history.turns.length, 2);
  assert.equal(existsSync(join(project.workspace, "final-report.json")), false);
  signal("qualifying", invoiceEvidence.qualified);
  const accepted = await observation.until(() => { const retained = hold(); if (retained.worker?.ended && retained.phase !== "continued") throw new Error("Qualification ended without successful continuation"); return ["accepted", "continued"].includes(retained.phase) && retained; });
  assert.equal(accepted.pending.purpose, "continuation");
  observation.ownership.accepted(threadId, accepted.accepted, "retained post-attention qualification");
  save("native-accepted.json", accepted);
  const replayDigest = signal("replay", { ...invoiceEvidence.qualified, notice: "same qualifying evidence delivered again" });
  await observation.until(() => hold().signalEvents > accepted.signalEvents || hold().worker?.ended);
  save("replay-observation.json", { digest: replayDigest, processedSignalEvent: hold().signalEvents > accepted.signalEvents, processedFingerprint: hold().observed === replayDigest, signalEventsBefore: accepted.signalEvents, signalEventsAfter: hold().signalEvents, workerEnded: hold().worker?.ended });
  const completed = await observation.until(() => { const retained = hold(); if (retained.worker?.ended && retained.phase !== "continued") throw new Error("Native continuation failed or handed back instead of completing"); return retained.phase === "continued" && retained.worker?.ended && retained; });
  assert.equal(completed.accepted.id, accepted.accepted.id); assert.equal(completed.accepted.status, "completed");
  save("native-completed.json", completed);
  const final = await inspect("final");
  assert.deepEqual(final.history.turns.map(({ id, status }) => ({ id, status })), [...expectedTurns, accepted.accepted.id].map((id) => ({ id, status: "completed" })));
  for (const history of observation.histories.values()) { assert.equal(history.historyUnavailable, undefined); assert.ok(history.turns.every((turn) => turn.status === "completed")); assert.ok(history.turns.every((turn) => (turn.items ?? []).every((item) => item.type !== "commandExecution" || item.status !== "inProgress"))); }
  assert.equal(final.accounting.complete, true);
  preserved(); const report = assertInvoiceResult(project);
  save("proof-results.json", { partial: await command([process.execPath, "verify-local.mjs"]), report: await command([process.execPath, "verify-report.mjs"]) });
  assert.equal((await command(["git", "rev-parse", "HEAD"])).stdout.trim(), project.revision);
  save("git-status.json", await command(["git", "status", "--short"]));
  const after = await observation.connection.request("thread/resume", { threadId }); checkSettings(after); save("native-after-settings.json", after);
  const savedSessions = retainFinalInvoiceSessions(observation, threadId, results); save("native-session-settings.json", savedSessions);
  save("result.json", { result: "pass-pending-root-final-proof-semantic-QA", threadId, continuationId: accepted.accepted.id, ownerRecoveryCommands, report, accounting: await observation.accounting(), savedSessions, acceptedProofArtifact: project.acceptedProofArtifact, retainedAcceptedProof: hold().input.execution.acceptedProof, noPublication: "HEAD unchanged, no commit/publish/CI receipt authorized", oldFrozenAssay: "incomplete; initial and attention facts reused" });
} catch (error) {
  commandAbort.abort();
  save("failure.json", { error: String(error), ownerRecoveryCommands, retained: hold() });
  await observation.discoverWorkers(threadId).catch((error) => save("cleanup-history-limitation.json", { error: String(error) }));
  await observation.ownership.interruptKnown(observation.ancestry.keys());
  if (hold()?.worker && !hold().worker.ended) save("observer-stop.json", await command([process.execPath, join(project.installed, "scripts/blocked-execution.mjs"), "stop", "--directory", project.directory], true));
  save("failed-accounting.json", await observation.accounting());
  save("result.json", { result: "incomplete", error: String(error), ownerRecoveryCommands, ownedCommands, retained: hold(), recovery: "Preserve exact project/thread/turns; reconcile native-cleanup-status.json before any further action; no automatic retry" });
  throw error;
} finally { observation.close(); }
