// Exact persisted-session readiness and native history for the invoice execution.
import assert from "node:assert/strict";
import { writeFileSync } from "node:fs";
import { join } from "node:path";
import { invoiceSessionReady } from "./blocked-execution-workflow-ownership.mjs";

export async function readInvoiceHistory(observation, threadId, name) {
  assert.ok(
    observation.ancestry.has(threadId),
    "Only the exact native execution tree is read",
  );
  if (!observation.threads.has(threadId)) {
    try {
      const metadata = await observation.connection.request("thread/read", {
        threadId,
        includeTurns: false,
      });
      assert.equal(metadata.thread.id, threadId);
      observation.trackRollout(metadata.thread);
    } catch (error) {
      if (
        error.code !== -32603 ||
        !/^failed to read thread: thread-store internal error: failed to read session metadata .* is empty$/.test(
          error.message,
        )
      )
        throw error;
    }
  }
  if (!invoiceSessionReady(observation.threads.get(threadId), threadId)) {
    const reason = "Exact native session metadata is not persisted yet";
    observation.historyLimits.set(threadId, reason);
    return {
      id: threadId,
      cwd: observation.workspace,
      turns: [],
      historyUnavailable: reason,
    };
  }
  let value;
  try {
    value = await observation.connection.request("thread/read", {
      threadId,
      includeTurns: true,
    });
    observation.historyLimits.delete(threadId);
  } catch (error) {
    if (
      error.code !== -32601 ||
      error.message !== "list_turns is not supported yet"
    )
      throw error;
    value = await observation.connection.request("thread/read", {
      threadId,
      includeTurns: false,
    });
    observation.historyLimits.set(threadId, error.message);
    value.thread.historyUnavailable = error.message;
  }
  assert.equal(value.thread.id, threadId);
  assert.equal(value.thread.cwd, observation.workspace);
  observation.histories.set(threadId, value.thread);
  for (const turn of value.thread.turns)
    observation.ownership.observed(threadId, turn);
  observation.trackRollout(value.thread);
  if (name)
    writeFileSync(
      join(observation.root, `${name}.json`),
      `${JSON.stringify(value, null, 2)}\n`,
    );
  return value.thread;
}
