# Consumer trace

## Effect terms searched

| Term | Origin |
| --- | --- |
| `Distribution/tests/blocked-execution-invoice-session.test.mjs` | changed path |
| `blocked-execution-invoice-session.test.mjs` | basename of `Distribution/tests/blocked-execution-invoice-session.test.mjs` |
| `Distribution/tests/blocked-execution-native.md` | changed path |
| `blocked-execution-native.md` | basename of `Distribution/tests/blocked-execution-native.md` |
| `Distribution/tests/blocked-execution-workflow-native.mjs` | changed path |
| `blocked-execution-workflow-native.mjs` | basename of `Distribution/tests/blocked-execution-workflow-native.mjs` |
| `Distribution/tests/support/blocked-execution-invoice-history.mjs` | changed path |
| `blocked-execution-invoice-history.mjs` | basename of `Distribution/tests/support/blocked-execution-invoice-history.mjs` |
| `Distribution/tests/support/blocked-execution-invoice-journey.mjs` | changed path |
| `blocked-execution-invoice-journey.mjs` | basename of `Distribution/tests/support/blocked-execution-invoice-journey.mjs` |
| `retainFinalInvoiceSessions` | supplied |
| `codexSessionSettings` | supplied |
| `runInvoiceJourney` | supplied |
| `acceptedProofReview` | supplied |
| `workerAncestryMatches` | supplied |

## Scope

Whole checkout at `0bc39b172c9a`, including uncommitted and untracked files: 6483 tracked and untracked non-ignored files searched with fixed-string, case-insensitive matching.

Changed files not searched: `Distribution/tests/blocked-execution-invoice-session.test.mjs`, `Distribution/tests/blocked-execution-native.md`, `Distribution/tests/blocked-execution-workflow-native.mjs`, `Distribution/tests/support/blocked-execution-invoice-history.mjs`, `Distribution/tests/support/blocked-execution-invoice-journey.mjs`.

## Located consumers

Kinds are path hints for inspection; each file appears once. Fill every Disposition with `run`, `reused` or `excluded: <reason the effect does not reach its boundary>`.

### Production

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `.planning/slice-plans/617-resume-blocked-work/slice4-after-yield-baseline/record.json` | `Distribution/tests/blocked-execution-workflow-native.mjs`, `blocked-execution-workflow-native.mjs`, `Distribution/tests/support/blocked-execution-invoice-history.mjs`, `blocked-execution-invoice-history.mjs`, `Distribution/tests/support/blocked-execution-invoice-journey.mjs`, `blocked-execution-invoice-journey.mjs` | 155: `"Distribution/tests/blocked-execution-workflow-native.mjs": "9ca27076c8bd5cbba485b7cf7fd6c326c538014b6223a8a7eb9a982aed9eeb2c",` | excluded: immutable historical source/hash index, no executable consumer |

### Test

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `Distribution/tests/support/native-codex-session.test.mjs` | `codexSessionSettings` | 9: `import { codexSessionSettings } from "./native-codex-session.mjs";` | reused: actor ten-case proof; shared reader and its case are unchanged |

### Test support or stand-in

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `Distribution/tests/support/blocked-execution-workflow-observation.mjs` | `blocked-execution-invoice-history.mjs` | 6: `import { readInvoiceHistory } from "./blocked-execution-invoice-history.mjs";` | reused: live readiness/history call and observer setup remain unchanged; actor eight-case proof retained |
| `Distribution/tests/support/native-codex-session.mjs` | `codexSessionSettings` | 72: `export function codexSessionSettings(thread, root) {` | reused: final-only explicit-root reader unchanged; actor consumer/shared-reader cases retained |

### Journey or feature

none found

### Guidance reader

| File | Terms matched | First matching line | Disposition |
| --- | --- | --- | --- |
| `.planning/slice-plans/617-resume-blocked-work/slice4-assessment.md` | `Distribution/tests/blocked-execution-workflow-native.mjs`, `blocked-execution-workflow-native.mjs`, `codexSessionSettings` | 12: `` `Distribution/tests/blocked-execution-workflow-native.mjs`, with focused invoice `` | excluded: nonexecuting native outcome/limits record |
| `.planning/slice-plans/617-resume-blocked-work/slice4-consumer-trace.md` | `Distribution/tests/blocked-execution-invoice-session.test.mjs`, `blocked-execution-invoice-session.test.mjs`, `Distribution/tests/blocked-execution-workflow-native.mjs`, `blocked-execution-workflow-native.mjs`, `Distribution/tests/support/blocked-execution-invoice-history.mjs`, `blocked-execution-invoice-history.mjs`, `Distribution/tests/support/blocked-execution-invoice-journey.mjs`, `blocked-execution-invoice-journey.mjs`, `retainFinalInvoiceSessions`, `codexSessionSettings`, `runInvoiceJourney`, `acceptedProofReview` | 15: `--path Distribution/tests/support/blocked-execution-invoice-history.mjs \` | excluded: nonexecuting consumer/proof record |
| `.planning/slice-plans/617-resume-blocked-work/slice4-refactor.md` | `retainFinalInvoiceSessions`, `codexSessionSettings`, `runInvoiceJourney` | 102: `` `runInvoiceJourney` requires actual first false judgment and normal initial native `` | excluded: nonexecuting review/disposition record |

## Directly inspected changed consumers

Invoice journey asserts actual accepted.status=completed at both completed attention and qualifier continuation, preserving IDs, same-thread delivery, owner recovery and final proof. Entry is its sole executable caller; no maintained test invokes runInvoiceJourney. Syntax and workspace/index whitespace checks passed. Planned native observation must execute these assertions; no unit/native rerun was performed here.

Entry attention admission is prospectively 30min/5M total/40k output per coordinator decision; resume admission is unchanged. Assignment, fixture, native settings and product runtime are unchanged. Final-only saved-session use and generic accepted-proof review remain intact. Semantic proof QA, native attention/automatic continuation and comparative commitments remain open.

Guide origin correction: the invoice is a reduced projection of SEED324; NativeCompare retains the distinct repeat-check/fake-gh fixture. Shared origin/condition principle is not case equivalence. No assignment, fixture or native settings changed, so existing nonpaid proof remains applicable. Native runtime callers already require completed status before settling those phases; the two added assessor assertions independently observe that existing fact, not a reproduced product defect.
