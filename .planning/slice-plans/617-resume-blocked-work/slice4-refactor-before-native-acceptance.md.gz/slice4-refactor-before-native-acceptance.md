# Slice 4 independent invoice-example refactor

Structural reorganization complete; native workflow/comparison/attention proof
remains pending with `slice4_native` after root release. No paid/native work,
formatter, hook-owned lint, staging, commit, publication or observer mutation ran
in this pass. Root retains PLAN/source-review and delivery ownership.

## Decision and coherent responsibilities

Prior independent passes checked raw unformatted sizes. Root's formatter exposed
349-line native entry, 450-line test and 394-line observer files; the earlier
size conclusion was insufficient. This authorized reorganization corrects that
with cohesive invoice-example responsibilities, without a generic comparison
framework, production refactor or subject/payload substitution.

The read-only pass reused the active plan, installed refactor checks, project
navigation and ADR context. PFE searched the whole product for response accounting,
invoice sequencing and native observation. No separate existing solution owns
this concrete example's per-response usage or invoice workflow. Existing native
CLI-stream adapters parse different event shapes; installed runtime continues
to own delivery. Reuse the current transport, repository builder and ownership
helper; keep the evaluator's independent observations outside subject code.

- Native entry keeps opt-in CLI, pinned installation, host settings, immediate
  acceptance persistence, independent final history/settings/report/proof/revision
  judgments and error cleanup.
- New `blocked-execution-invoice-journey.mjs` owns this invoice's fixed supplier
  events, negative checkpoints, optional attention recovery, qualifying replay
  and manual baseline notification. It keeps both preservation milestones.
  Invoice-specific command/output predicates moved here from the observer.
- New `blocked-execution-invoice-accounting.mjs` owns direct-response parsing,
  deduplication and admitted-tree aggregate snapshots. The observer retains token
  ceilings and failure ownership; unknown counts remain unknown with lower bounds.
- New `blocked-execution-invoice-history.mjs` owns exact persisted-session readiness,
  native identity/workspace checks, known startup deferral and full-history reads.
  Existing `observation.history` remains the caller boundary.
- Observer owns live events, admitted ancestry, rollout watchers and lifecycle.
  `observeOwnedEvent` interprets both live and retained evidence;
  `spawnedThreads` gives live/replayed/history paths one exact-sender rule.
  Replay retains recursive descendants and forbids reparenting.
- Existing native test now owns startup and cleanup proof. New invoice-accounting
  and invoice-admission tests own cost evidence and retained-tree evidence.
  Every original test body, including both stronger interrupt-method assertions,
  was retained byte-for-byte; no proof was deleted, merged or weakened.

Existing ownership/project modules remain unchanged. No file was renamed or
removed; three source helpers and two test files were added. No generator or
manifest edit is needed: maintained test globs already discover the new files.
Only this invoice-example test-support boundary changed.

Accepted ADR 0002 supports cohesive single ownership; 0005 preserves native and
matched-comparison requirements; 0010 preserves useful outcome/total-cost judgment.
Accepted 0003/0006/0008 retain release/audience/local-evidence boundaries.
The index and relevant records have no conflict/supersession; Proposed 0007/0009
are nonbinding. No architectural choice or exception is introduced.

## Accepted behavior and historical repairs

The first structural pass consolidated accepted-file hash validation into
`assertPreservedInvoiceWork`; both intermediate and final checkpoints remain.
Its real-file pass/mutation-rejection observation remains applicable because the
helper and hash rule were not changed.

The evaluator's earlier defects and controlled attribution are retained:

- Missing admitted descendant path produced complete=true; repaired aggregation
  stays unknown through missing path/usage and completes after exact child usage.
- Terminal event followed by interrupt refusal threw `turn already terminal`;
  repaired cleanup preserves exact terminal evidence and visits remaining turns.
- Disconnect left accepted-interrupt completion pending; repaired cleanup settles
  unconfirmed, preserves remaining identities and names exact-history recovery.
- Earlier child terminal event produced undefined instead of completed; replay
  restores exact turns and keeps admitted but unobserved ownership unknown.
- Retained child spawn omitted its grandchild (undefined instead of child);
  exact event-thread/sender replay closes descendants recursively and excludes
  foreign/copied-ancestor evidence; repeated admission is idempotent.

The original two-case startup/accounting pass, six-case repair red/green passes,
then seven-case descendant-closure passes are historical evidence in the
assessment. Their old single-file command no longer covers all seven after this
move; the replacement below renews the complete deterministic boundary.
`native-cleanup-status.json` remains derived evaluator output: exact event or
uncertainty results, known remaining turns, unknown admitted threads and recovery.
It creates no installed ownership authority.

## Proof and consumer dispositions

Installed test-entry selection resolved all three test paths to MakeMe=true and
PageObjects=false. Helpers follow their consuming tests. Exact native wire
counterexamples stay explicit; project setup uses the shared repository builder.
The installed consumer trace and old-reference search cover the whole checkout;
[every consumer disposition](slice4-consumer-trace.md) is recorded. No production
or uncovered structural consumer was found. Actual native caller outcome remains
an explicitly uncovered required observation, not deterministic proof.

Renewed after source edits:

```sh
PATH=/opt/homebrew/bin:$PATH OPEN_DOUGH_TEST_JOBS=1 npm test -- \
  Distribution/tests/blocked-execution-workflow-native.test.mjs \
  Distribution/tests/blocked-execution-invoice-accounting.test.mjs \
  Distribution/tests/blocked-execution-invoice-admission.test.mjs
```

Passed all seven cases. Startup observes missing/partial/complete actual session
files, no early RPC, persisted acceptance and exact terminal cleanup. Accounting
observes own-response dedup/foreign/cumulative exclusion, partial/malformed input
and admitted-child missing-path/usage recovery. Cleanup/admission observe refusal,
disconnect, unknown ownership and recursive exact descendant closure. Setup and
assertion locations are in the trace. No sleeps or timeout overrides were added.

`PATH=/opt/homebrew/bin:$PATH node --check <path>` passed for the entry, observer
and three new source helpers. A separate source comparison established all seven
original test bodies survive unchanged, including the stronger wire assertions.
Tracked and untracked whitespace checks passed. No full suite or expensive proof
was launched; lightweight deterministic work needed no machine admission.

Unchanged/reused evidence: installer smoke and complete 365/376 managed inventories,
project setup/assignment and pins, preservation helper, ownership implementation
and its accepted wire behavior. Moved boundaries invalidated prior single-file
suite/syntax locations and were renewed above. No completed native full-workflow
proof exists; none is invalidated or silently promoted by this reorganization.

## Delivered size and remaining native obligations

Read-only `prettier.resolveConfig` + `prettier.format` preview used each filepath;
no formatter wrote files. Counts exclude only the terminating newline:

| Path under Distribution/tests | Raw | Formatted |
| --- | ---: | ---: |
| blocked-execution-workflow-native.mjs | 203 | 207 |
| support/blocked-execution-workflow-observation.mjs | 207 | 209 |
| support/blocked-execution-invoice-accounting.mjs | 83 | 88 |
| support/blocked-execution-invoice-history.mjs | 72 | 72 |
| support/blocked-execution-invoice-journey.mjs | 159 | 188 |
| blocked-execution-workflow-native.test.mjs | 195 | 198 |
| blocked-execution-invoice-accounting.test.mjs | 86 | 86 |
| blocked-execution-invoice-admission.test.mjs | 178 | 178 |
| support/blocked-execution-workflow-ownership.mjs | 175 | 175 |
| support/blocked-execution-workflow-project.mjs | 182 | 182 |

All implicated source/test and maintainer records are <=250 raw and formatted.
PLAN's unchanged root-owned metadata remains 250 actual lines and is outside
this reorganization. The project's formatter does not write Markdown; hypothetical
Markdown reflow adds no project gate. Root retains later PLAN condensation.
Root will run its formatter/lint gates and freeze hashes before any paid retry.
The native owner must reconsider actual AC/load/memory and the maintained macOS
sleep guard before expensive work. The [failure policy](../../../AGENTS.md#failing-and-flaky-tests)
applies as written; exact active repair ownership is the coordination boundary.

Native G3/G6/C65/C68, final history and actual baseline/candidate/attention outcomes
remain pending with `slice4_native` after root release. No baseline with zero idle
requests can satisfy C65 on a tie. Failed baseline cost remains 13 requests,
555,383 total tokens (553,984 input, 502,400 cached; 1,399 output), not comparison
or improvement evidence. Caps and source pins remain unchanged. The conditional
Cursor/Claude fallback clarification does not change the Codex contract; future
pinned Codex evidence needs correspondence review and never proves manual hosts.

Approximate active elapsed: 15 minutes for this reorganization, following earlier
15-minute structural and 6-minute follow-up passes. Total implementation and
coordinator model effort remains unknown; no new native model spend occurred here.

## Subsequent nonpaid protocol/notice correction

After the failed matched retry, root selected a new prospective after-yield
protocol, without changing assignment, fixture, payload pins or model/settings.
`runInvoiceJourney` requires actual first false judgment and normal initial native
completion before any producer event; candidate additionally requires its own
held receipt. It records `initial-yield-boundary.json` for actual timestamp proof.
Baseline is already ended during negative events; candidate acknowledges its held
fingerprints. No history/discovery calls remain in any journey wait predicate.
Complete native history and descendant accounting remain milestone/final gates.

The constructor uses one shared notification handler. Non-thread notices are
counted in memory before append/wake, retained thread-scoped child evidence stays
available for verified admission, and admitted progress wakes the current wait.
Global errors/disconnect are not swallowed. Scalar notice audit is written only
with actual result records. Original generic filesystem observation is retained.

The new accounting-file case reproduced three history queries versus one before
the fix. It now observes no notice-driven requery/raw growth, preserved earlier
child evidence and a real own terminal wake; global errors remain actionable.
The original startup case exposed an overly specific transient filename filter;
that runtime change was removed. Two old direct test processes remained pending
and were explicitly terminated (135.7s/177.5s), never reported as passes. Partial
metadata/no-early-RPC is now inspected directly, with one primed real filesystem
listener before atomic complete-header replacement. No per-write event, sleep,
clock wait, timeout override or filesystem fallback framework is required.

Renewed direct and maintained focused three-file commands pass eight cases;
syntax passes for all five changed entry/helper/test paths. Read-only formatter
preview raw/formatted counts: observation 218/230, journey 183/197, entry 209/209,
accounting test 126/157, startup/cleanup test 199/208. No formatter wrote files.
The renewed [consumer trace](slice4-consumer-trace.md) preserves pending native
caller proof. Failed-run artifacts, 40 responses / 2,648,123 observed tokens,
source pins and G6 deferral are unchanged. No new paid release or cap is inferred.

## Independent correction closure

Targeted read-only review confirmed the new normally-completed-initial-turn
protocol is distinct from the failed live-checker protocol. Fixed events, one
baseline notification, candidate held fingerprints and final proof retain their
owners. Notice counts are derived diagnostic state; retained thread evidence
still supports exact admission and global error/disconnect remains actionable.
The startup fixture proves complete metadata after one primed filesystem event
without imposing one event per partial write. No new framework is justified.

One redundant contract was exposed: `observeOwnedEvent` returned child arrays
for the retired live-history caller. Both current callers ignore that result;
the independent cleanup removes its unused return only. The renewed installed
consumer trace has the same three test consumers and three nonexecuting records;
their complete dispositions remain in `slice4-consumer-trace.md`. No uncovered
structural consumer or production boundary change was found.

The maintained focused three-file command passed all eight cases again after
this edit; observer `node --check` passed. Original test setup/assertions and
the four other accepted syntax observations are unchanged. No direct duplicate
run, full suite, formatter/lint, native/API/model call or cap change was needed.
Observer raw/formatted preview is now 217/229; all other accepted size observations
remain applicable. Native timestamp correspondence, G3/G6, candidate/comparison
and worthwhile improvement remain pending with `slice4_native` after root release.
The failed-run total remains 40 responses / 2,648,123 observed tokens. Approximate
active elapsed for this closure: 6 minutes.

## Accepted-proof representation correction

The public store's `acceptedProof: unknown[]` contract does not require inline
objects. The invoice-only assertion now requires a nonempty retained array;
original caller proof path/hash and captured held proof remain pending root
semantic review before accepting a functional result. Project metadata captures
the original artifact before native work; existing preservation checks protect
its exact bytes at initial/attention/final milestones. No generic resolver or
new maintained mirror test was introduced. A real installed-project countercheck
accepted original bytes, rejected an altered accepted result and accepted exact
restoration. Maintained eight-case proof and three syntax checks passed; read-only
raw/formatted counts are project 193/193, journey 201/201 and entry 215/215.
The native assignment/core fixture compare byte-identical to the frozen archive.
The original ten-source tar and all member hashes were verified and added to the
existing baseline bundle. Consumer dispositions are renewed in the trace. No
native/model call, product runtime, pin, setting or cap changed; functional native
retention semantics and G3/comparative acceptance remain unobserved.

Independent closure: none — already clean. Original proof bytes and retained
meaning have separate, coherent owners. All four nonexecuting consumers remain
excluded; the three callers reuse current mutation/eight-case/syntax proof.
Tests skipped: no source edits. Root semantic QA and functional/native/comparative
acceptance remain pending; approximate active elapsed: 4 minutes.

## REFACTOR COMPLETE
